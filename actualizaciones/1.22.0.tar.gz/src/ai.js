// IA local (sin internet): mejorar calidad (Real-ESRGAN general x4v3) y detectar caras (UltraFace RFB-640).
const path = require('path');
const ort = require('onnxruntime-node');

const MODELS = path.join(__dirname, '..', 'models');
const sessions = {};

async function session(file) {
  if (sessions[file]) return sessions[file];
  const p = path.join(MODELS, file);
  // las caras van siempre por procesador (modelo chiquito: rápido y sin sorpresas de la placa de video)
  if (file.startsWith('faces')) {
    sessions[file] = await ort.InferenceSession.create(p, { executionProviders: ['cpu'], graphOptimizationLevel: 'all', logSeverityLevel: 3 });
    sessions[file].provider = 'cpu';
  } else {
    if (file.startsWith('upscale')) {
      // elegir la placa más rápida (la primera vez): una imagen de prueba de 256×256
      const n = 3 * 256 * 256, x = new Float32Array(n);
      for (let i = 0; i < n; i++) x[i] = ((i * 2654435761) >>> 0) / 4294967296;
      await require('./gpu').pickDml(p, { input: new ort.Tensor('float32', x, [1, 3, 256, 256]) }).catch(() => {});
    }
    sessions[file] = await require('./gpu').createSession(p);
  }
  return sessions[file];
}

// ---------- mejorar calidad ----------
// rgb: Buffer RGB (3 canales) de w*h. Devuelve Buffer RGB de (4w)*(4h).
// onProgress(0..1) opcional.
// style: 'detail' (conserva textura, por defecto) | 'smooth' (limpia más ruido)
// opts.tile: pedazo más grande en la placa (video: un cuadro chico entra entero, menos vueltas)
async function upscale4x(rgb, w, h, onProgress, style = 'detail', opts = {}) {
  const s = await session(style === 'smooth' ? 'upscale-x4.onnx' : 'upscale-x4-detail.onnx');
  return runTiles(s, 4, rgb, w, h, onProgress, opts.tile);
}

// ---------- video (1.21.3) ----------
// En la placa (DirectML) el video usa copias del modelo en media precisión (fp16: en las RTX va mucho más rápido)
// y, cuando alcanza con ×2, una versión que achica el ×4 adentro de la placa (promedio 2×2): viaja y se copia
// 4 veces menos. Están en src/models-video, así llegan con las actualizaciones chicas. Cada una se verifica
// contra el procesador como las demás; si no da bien (o no hay placa) se usa el modelo de siempre (×4, fp32).
const VMODELS = path.join(__dirname, 'models-video');
const vsessions = {};
async function videoSession(style, factor) {
  const k = `${style}-${factor}`;
  if (vsessions[k]) return vsessions[k];
  const base = await session(style === 'smooth' ? 'upscale-x4.onnx' : 'upscale-x4-detail.onnx');
  let pick = { s: base, f: 4 };
  if (base.provider === 'dml') {
    try {
      const s = await require('./gpu').createSession(path.join(VMODELS, `up-${style}-x${factor}-fp16.onnx`));
      // la primera corrida verifica contra el procesador: se hace acá con algo chico
      const n = 3 * 64 * 64, x = new Float32Array(n);
      for (let i = 0; i < n; i++) x[i] = ((i * 2654435761) >>> 0) / 4294967296;
      await s.run({ input: new ort.Tensor('float32', x, [1, 3, 64, 64]) });
      if (s.provider === 'dml') pick = { s, f: factor, fp16: true };
      else await s.release?.();
    } catch (e) { console.error('[ia] video fp16:', e.message); }
  }
  vsessions[k] = pick;
  return pick;
}
// factor pedido 2 o 4 → { data, w, h } (con el modelo de siempre sale ×4 aunque se pida ×2: se achica afuera)
async function upscaleVideoFrame(rgb, w, h, factor = 4, style = 'detail', onProgress) {
  const { s, f } = await videoSession(style === 'smooth' ? 'smooth' : 'detail', factor === 2 ? 2 : 4);
  return { data: await runTiles(s, f, rgb, w, h, onProgress, 1024), w: w * f, h: h * f };
}
async function videoProvider(style = 'detail', factor = 2) {
  const v = await videoSession(style === 'smooth' ? 'smooth' : 'detail', factor === 2 ? 2 : 4);
  return v.fp16 ? 'dml-fp16' : v.s.provider;
}

// corre el modelo por pedazos; F = cuánto agranda el modelo (4, o 2 en la versión que achica adentro)
async function runTiles(s, F, rgb, w, h, onProgress, tile) {
  const TILE = s.provider !== 'cpu' && tile ? tile : s.provider === 'dml' ? 320 : 192;
  // margen alrededor de cada pedazo: la red "ve" ~34 px alrededor, con menos se notan las uniones
  const PAD = 40;
  const out = Buffer.allocUnsafe(w * F * h * F * 3); // los pedazos cubren toda la imagen
  const tilesX = Math.ceil(w / TILE), tilesY = Math.ceil(h / TILE);
  let done = 0;
  for (let ty = 0; ty < tilesY; ty++) {
    for (let tx = 0; tx < tilesX; tx++) {
      // zona útil del tile y zona con margen (para que no se noten las uniones)
      const x0 = tx * TILE, y0 = ty * TILE;
      const x1 = Math.min(w, x0 + TILE), y1 = Math.min(h, y0 + TILE);
      const px0 = Math.max(0, x0 - PAD), py0 = Math.max(0, y0 - PAD);
      const px1 = Math.min(w, x1 + PAD), py1 = Math.min(h, y1 + PAD);
      const tw = px1 - px0, th = py1 - py0;
      const input = new Float32Array(3 * tw * th);
      const plane = tw * th;
      for (let y = 0; y < th; y++) {
        for (let x = 0; x < tw; x++) {
          const si = ((py0 + y) * w + (px0 + x)) * 3;
          const di = y * tw + x;
          input[di] = rgb[si] / 255;
          input[plane + di] = rgb[si + 1] / 255;
          input[2 * plane + di] = rgb[si + 2] / 255;
        }
      }
      const res = await s.run({ input: new ort.Tensor('float32', input, [1, 3, th, tw]) });
      const o = res.output.data;
      const ow = tw * F, oplane = ow * th * F;
      // copiar solo la zona útil
      for (let y = (y0 - py0) * F; y < (y1 - py0) * F; y++) {
        const gy = py0 * F + y;
        for (let x = (x0 - px0) * F; x < (x1 - px0) * F; x++) {
          const gx = px0 * F + x;
          const si = y * ow + x;
          const di = (gy * w * F + gx) * 3;
          out[di] = clamp(o[si]);
          out[di + 1] = clamp(o[oplane + si]);
          out[di + 2] = clamp(o[2 * oplane + si]);
        }
      }
      done++;
      onProgress?.(done / (tilesX * tilesY));
    }
  }
  return out;
}
const clamp = (v) => (v <= 0 ? 0 : v >= 1 ? 255 : Math.round(v * 255));

// ---------- caras ----------
const FW = 640, FH = 480;

function iou(a, b) {
  const ix = Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x));
  const iy = Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
  const inter = ix * iy;
  return inter / (a.w * a.h + b.w * b.h - inter);
}

function nms(boxes, thr = 0.35) {
  boxes.sort((a, b) => b.score - a.score);
  const keep = [];
  for (const b of boxes) {
    if (keep.every((k) => iou(k, b) < thr && !contains(k, b))) keep.push(b);
  }
  return keep;
}
// descarta una caja chica casi entera adentro de otra (pasa al juntar tiles)
function contains(a, b) {
  const ix = Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x));
  const iy = Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
  return (ix * iy) / Math.min(a.w * a.h, b.w * b.h) > 0.7;
}

// rgb640: Buffer RGB ya redimensionado a 640x480. Devuelve cajas normalizadas 0..1
async function detectOnce(rgb640, threshold) {
  const s = await session('faces-rfb640.onnx');
  const plane = FW * FH;
  const input = new Float32Array(3 * plane);
  for (let i = 0; i < plane; i++) {
    input[i] = (rgb640[i * 3] - 127) / 128;
    input[plane + i] = (rgb640[i * 3 + 1] - 127) / 128;
    input[2 * plane + i] = (rgb640[i * 3 + 2] - 127) / 128;
  }
  const res = await s.run({ input: new ort.Tensor('float32', input, [1, 3, FH, FW]) });
  const scores = res.scores.data, boxes = res.boxes.data;
  const out = [];
  for (let i = 0; i < scores.length / 2; i++) {
    const sc = scores[i * 2 + 1];
    if (!(sc >= threshold) || sc > 1.0001) continue; // descarta NaN y valores raros
    const x1 = boxes[i * 4], y1 = boxes[i * 4 + 1], x2 = boxes[i * 4 + 2], y2 = boxes[i * 4 + 3];
    if (![x1, y1, x2, y2].every(Number.isFinite) || x2 <= x1 || y2 <= y1) continue;
    if (x2 < 0 || y2 < 0 || x1 > 1 || y1 > 1) continue;
    out.push({ x: x1, y: y1, w: x2 - x1, h: y2 - y1, score: sc });
  }
  return out;
}

// getRegion(x, y, w, h) => Promise<Buffer RGB 640x480> de esa zona del original
async function detectFaces(W, H, getRegion, { threshold = 0.8 } = {}) {
  const regions = [{ x: 0, y: 0, w: W, h: H }];
  // en imágenes grandes también se mira por partes para encontrar caras chicas
  const big = Math.max(W, H);
  if (big > 1100) {
    const n = big > 3000 ? 3 : 2;
    const tw = W / n, th = H / n, ov = 0.2;
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
      const x = Math.max(0, i * tw - tw * ov), y = Math.max(0, j * th - th * ov);
      regions.push({ x, y, w: Math.min(W - x, tw * (1 + 2 * ov)), h: Math.min(H - y, th * (1 + 2 * ov)) });
    }
  }
  const all = [];
  for (const r of regions) {
    const rgb = await getRegion(Math.round(r.x), Math.round(r.y), Math.round(r.w), Math.round(r.h));
    for (const b of await detectOnce(rgb, threshold)) {
      all.push({ x: r.x + b.x * r.w, y: r.y + b.y * r.h, w: b.w * r.w, h: b.h * r.h, score: b.score });
    }
  }
  return nms(all.filter((b) => b.w > 4 && b.h > 4));
}

// Carga el detector de caras de antemano (la primera vez, sobre todo con placa de video, tarda unos segundos)
function warmUp() { session('faces-rfb640.onnx').catch(() => {}); }

// 'dml' / 'coreml' (placa de video) o 'cpu' (procesador)
async function upscaleProvider(style = 'detail') { return (await session(style === 'smooth' ? 'upscale-x4.onnx' : 'upscale-x4-detail.onnx')).provider; }

module.exports = { upscale4x, upscaleProvider, upscaleVideoFrame, videoProvider, detectFaces, warmUp };
