// Separador de stems offline (modelos MDX-Net de UVR, corren con onnxruntime en tu compu).
//  - Voz: UVR-MDX-NET-Voc_FT
//  - Batería / Bajo: kuielab_a (MDX challenge)
//  - Otros = instrumental - batería - bajo (así los stems siempre suman la mezcla original)
const fs = require('fs');
const path = require('path');
const ort = require('onnxruntime-node');
const { stftStereo, istftStereo } = require('./dsp');
const av = require('./av');

const MODELS = path.join(__dirname, '..', 'models');
const SR = 44100;
const HOP = 1024;

const SPECS = {
  vocals: { file: 'stems-vocals.onnx', nfft: 7680, dimF: 3072, dimT: 256, compensate: 1.021 },
  demucs: { file: 'stems-demucs6.onnx' },
};
// orden de salida de Demucs 6 stems
const DEMUCS_SOURCES = ['drums', 'bass', 'other', 'vocals', 'guitar', 'piano'];

const { createSession, markBroken } = require('./gpu');
const sessions = {};
// si la placa de video falla una vez (poca memoria, driver), el resto se hace con el procesador
let gpuBroken = false;
// corre fn(); si falla usando la placa de video, la desactiva y reintenta con el procesador
async function withGpuFallback(label, fn) {
  try { return await fn(); } catch (e) {
    if (gpuBroken || process.platform !== 'win32') throw e;
    console.error(`[${label}] falló con placa de video, reintento con procesador:`, e);
    gpuBroken = true; markBroken(e.message);
    for (const k of Object.keys(sessions)) { try { await sessions[k].release(); } catch {} delete sessions[k]; }
    return fn();
  }
}

async function session(name) {
  if (sessions[name]) return sessions[name];
  sessions[name] = await createSession(path.join(MODELS, SPECS[name].file));
  return sessions[name];
}

// Corre un modelo sobre la señal estéreo completa. Devuelve [L, R] del stem.
async function runModelRaw(name, L, R, onProgress) {
  const spec = SPECS[name];
  const s = await session(name);
  const { nfft, dimF, dimT, compensate } = spec;
  const chunk = HOP * (dimT - 1);
  const trim = nfft / 2;
  const gen = chunk - 2 * trim;
  const n = L.length;
  const pad = gen - (n % gen);
  const total = trim + n + pad + trim;
  // señal con ceros a los costados
  const pl = new Float32Array(total), pr = new Float32Array(total);
  pl.set(L, trim); pr.set(R, trim);
  const outL = new Float32Array(n + pad), outR = new Float32Array(n + pad);
  const input = new Float32Array(4 * dimF * dimT);
  const steps = (n + pad) / gen;
  for (let c = 0, i = 0; i < n + pad; i += gen, c++) {
    const cl = pl.subarray(i, i + chunk), cr = pr.subarray(i, i + chunk);
    stftStereo(cl, cr, nfft, HOP, dimF, dimT, input);
    let res = await s.run({ input: new ort.Tensor('float32', input, [1, 4, dimF, dimT]) });
    const out = res.output.data;
    const [yl, yr] = istftStereo(out, nfft, HOP, dimF, dimT);
    outL.set(yl.subarray(trim, trim + gen), i);
    outR.set(yr.subarray(trim, trim + gen), i);
    res = null;
    onProgress?.((c + 1) / steps);
  }
  // libera el modelo (son pesados en memoria)
  try { await s.release(); } catch {}
  delete sessions[name];
  const rl = outL.subarray(0, n), rr = outR.subarray(0, n);
  for (let k = 0; k < n; k++) { rl[k] *= compensate; rr[k] *= compensate; }
  return [rl, rr];
}

// ---------- Demucs (htdemucs_6s) ----------
// El modelo exportado recibe el audio + su espectrograma y devuelve las dos ramas;
// la STFT/iSTFT y el armado por segmentos (como apply_model de Demucs) se hacen acá.
const DM = { nfft: 4096, hop: 1024, seg: 343980, bins: 2048 };

function reflectPad(x, left, right) {
  const n = x.length, out = new Float32Array(n + left + right);
  const at = (i) => { // reflexión (sin repetir el borde)
    while (i < 0 || i >= n) { if (i < 0) i = -i; if (i >= n) i = 2 * (n - 1) - i; }
    return x[i];
  };
  for (let i = 0; i < out.length; i++) out[i] = at(i - left);
  return out;
}

async function demucsSegment(s, cl, cr) {
  const L = cl.length; // == DM.seg
  const { nfft, hop, bins } = DM;
  const le = Math.ceil(L / hop);
  const pad = (hop / 2) * 3;
  const pl = reflectPad(cl, pad, pad + le * hop - L), pr = reflectPad(cr, pad, pad + le * hop - L);
  const mag = new Float32Array(4 * bins * le);
  stftStereo(pl, pr, nfft, hop, bins, le, mag, 2, 1 / Math.sqrt(nfft));
  const mix = new Float32Array(2 * L); mix.set(cl, 0); mix.set(cr, L);
  const res = await s.run({ mix: new ort.Tensor('float32', mix, [1, 2, L]), mag: new ort.Tensor('float32', mag, [1, 4, bins, le]) });
  const spec = res.spec.data, wave = res.wave.data;
  const S = DEMUCS_SOURCES.length, P = bins * le, T2 = le + 4, P2 = bins * T2;
  const outs = [];
  const z = new Float32Array(4 * P2);
  const k = Math.sqrt(nfft);
  for (let si = 0; si < S; si++) {
    z.fill(0);
    for (let c = 0; c < 4; c++) {
      const src = (si * 4 + c) * P;
      for (let f = 0; f < bins; f++) {
        const so = src + f * le, dO = c * P2 + f * T2 + 2;
        for (let t = 0; t < le; t++) z[dO + t] = spec[so + t] * k;
      }
    }
    const [yl, yr] = istftStereo(z, nfft, hop, bins, T2);
    const ol = new Float32Array(L), or = new Float32Array(L);
    const wl = si * 2 * L, wr = wl + L;
    for (let i = 0; i < L; i++) { ol[i] = yl[pad + i] + wave[wl + i]; or[i] = yr[pad + i] + wave[wr + i]; }
    outs.push([ol, or]);
  }
  return outs;
}

async function runDemucsRaw(L, R, onProgress) {
  const s = await session('demucs');
  const n = L.length, seg = DM.seg;
  // normalización global como hace Demucs
  let mean = 0; for (let i = 0; i < n; i++) mean += (L[i] + R[i]) / 2; mean /= n;
  let sd = 0; for (let i = 0; i < n; i++) { const m = (L[i] + R[i]) / 2 - mean; sd += m * m; } sd = Math.sqrt(sd / n) || 1;
  const nl = new Float32Array(n), nr = new Float32Array(n);
  for (let i = 0; i < n; i++) { nl[i] = (L[i] - mean) / sd; nr[i] = (R[i] - mean) / sd; }
  // ventana triangular y 25% de solapamiento
  const stride = Math.floor(seg * 0.75);
  const w = new Float32Array(seg);
  const half = Math.floor(seg / 2);
  for (let i = 0; i < half; i++) w[i] = i + 1;
  for (let i = half; i < seg; i++) w[i] = seg - i;
  const wmax = Math.max(...[w[half - 1], w[half]]);
  for (let i = 0; i < seg; i++) w[i] /= wmax;
  const S = DEMUCS_SOURCES.length;
  const acc = Array.from({ length: S }, () => [new Float32Array(n), new Float32Array(n)]);
  const sumw = new Float32Array(n);
  const offsets = []; for (let o = 0; o < n; o += stride) offsets.push(o);
  for (let oi = 0; oi < offsets.length; oi++) {
    const off = offsets[oi];
    const len = Math.min(seg, n - off);
    // ventana de largo `seg` centrada en el pedazo (con audio real alrededor si hay)
    const start = off - Math.floor((seg - len) / 2);
    const cl = new Float32Array(seg), cr = new Float32Array(seg);
    for (let i = 0; i < seg; i++) { const j = start + i; if (j >= 0 && j < n) { cl[i] = nl[j]; cr[i] = nr[j]; } }
    const outs = await demucsSegment(s, cl, cr);
    const trim = off - start;
    for (let si = 0; si < S; si++) {
      const [ol, or] = outs[si], [al, ar] = acc[si];
      for (let i = 0; i < len; i++) { al[off + i] += ol[trim + i] * w[i]; ar[off + i] += or[trim + i] * w[i]; }
    }
    for (let i = 0; i < len; i++) sumw[off + i] += w[i];
    onProgress?.((oi + 1) / offsets.length);
  }
  try { await s.release(); } catch {}
  delete sessions.demucs;
  const result = {};
  DEMUCS_SOURCES.forEach((name, si) => {
    const [al, ar] = acc[si];
    for (let i = 0; i < n; i++) { const d = sumw[i] || 1; al[i] = (al[i] / d) * sd + mean; ar[i] = (ar[i] / d) * sd + mean; }
    result[name] = [al, ar];
  });
  return result;
}

// ---------- Orquesta (MVSep Mega 53 stems, BS-Roformer; separado en tronco + cabezas) ----------
// Se busca la carpeta "orquesta" al lado de MIXTAPE.exe o adentro de models/
const ORQ_NAMES = { bowed_strings: 'Cuerdas', brass: 'Metales', woodwind: 'Vientos madera', percussion: 'Percusión', piano: 'Piano (orquesta)', harp: 'Arpa' };
function orqDir() {
  const cands = [path.join(MODELS, 'orquesta'), ...require('./bins').packDirs('orquesta')];
  return cands.find((d) => fs.existsSync(path.join(d, 'trunk.onnx'))) || null;
}
function orqAvailable() {
  const d = orqDir();
  if (!d) return [];
  return Object.keys(ORQ_NAMES).filter((k) => fs.existsSync(path.join(d, `${k}.onnx`)));
}

const RF = { nfft: 2048, hop: 512, bins: 1025 };

async function orqSession(file) { return createSession(file); }

// Procesa un pedazo: devuelve { [stem]: [L, R] } de largo cl.length (múltiplo de hop)
async function roformerChunk(trunk, heads, cl, cr) {
  const { nfft, hop, bins } = RF;
  const T = Math.floor(cl.length / hop) + 1;
  const P = bins * T;
  const spec = new Float32Array(4 * P); // [Lre, Lim, Rre, Rim][f][t]
  stftStereo(cl, cr, nfft, hop, bins, T, spec);
  // entrada del modelo: [1, T, (f s c)]
  const x = new Float32Array(T * bins * 4);
  for (let t = 0; t < T; t++) {
    const row = t * bins * 4;
    for (let f = 0; f < bins; f++) {
      const o = f * T + t, d = row + f * 4;
      x[d] = spec[o]; x[d + 1] = spec[P + o]; x[d + 2] = spec[2 * P + o]; x[d + 3] = spec[3 * P + o];
    }
  }
  const feat = (await trunk.run({ x: new ort.Tensor('float32', x, [1, T, bins * 4]) })).feat;
  const out = {};
  const z = new Float32Array(4 * P);
  for (const [name, h] of Object.entries(heads)) {
    const mask = (await h.run({ feat })).mask.data; // [1, T, (f s c)]
    for (let t = 0; t < T; t++) {
      const row = t * bins * 4;
      for (let f = 0; f < bins; f++) {
        const o = f * T + t, d = row + f * 4;
        const lr = spec[o], li = spec[P + o], rr = spec[2 * P + o], ri = spec[3 * P + o];
        const mlr = mask[d], mli = mask[d + 1], mrr = mask[d + 2], mri = mask[d + 3];
        if (f === 0) { z[o] = z[P + o] = z[2 * P + o] = z[3 * P + o] = 0; continue; } // sin DC, como el original
        z[o] = lr * mlr - li * mli; z[P + o] = lr * mli + li * mlr;
        z[2 * P + o] = rr * mrr - ri * mri; z[3 * P + o] = rr * mri + ri * mrr;
      }
    }
    out[name] = istftStereo(z, nfft, hop, bins, T);
  }
  return out;
}

async function runOrchestraRaw(L, R, names, onProgress) {
  const dir = orqDir();
  if (!dir) throw new Error(process.platform === 'darwin' ? 'Falta el paquete Orquesta (menú de MIXTAPE → Instalar paquete…)' : 'Falta el paquete Orquesta (carpeta "orquesta" al lado de MIXTAPE.exe)');
  const trunk = await orqSession(path.join(dir, 'trunk.onnx'));
  const heads = {};
  const all = [trunk];
  try {
    for (const n of names) { heads[n] = await orqSession(path.join(dir, `${n}.onnx`)); all.push(heads[n]); }
    return await orchestraLoop(trunk, heads, L, R, names, onProgress);
  } finally {
    for (const x of all) { try { await x.release(); } catch {} }
  }
}

async function orchestraLoop(trunk, heads, L, R, names, onProgress) {
  const n = L.length;
  // pedazos de ~10 s (o ~6 s con placa de video, para no quedarse sin memoria), 50% de solapamiento
  const C = RF.hop * (trunk.provider === 'dml' ? 345 : 861); // ~3,5 s en placa de video (4 GB alcanzan), ~10 s en procesador
  // 20% de solapamiento con fundidos (antes 50%: el doble de trabajo sin diferencia audible)
  const step = RF.hop * Math.round((C / RF.hop) * 0.8), border = C - step, fade = border;
  const pl = reflectPad(L, border, border), pr = reflectPad(R, border, border);
  const N = pl.length;
  const acc = {}; for (const k of names) acc[k] = [new Float32Array(N), new Float32Array(N)];
  const cnt = new Float32Array(N);
  const starts = []; for (let i = 0; i < N; i += step) starts.push(i);
  for (let si = 0; si < starts.length; si++) {
    const i = starts[si];
    const part = Math.min(C, N - i);
    const cl = new Float32Array(C), cr = new Float32Array(C);
    cl.set(pl.subarray(i, i + part)); cr.set(pr.subarray(i, i + part));
    const res = await roformerChunk(trunk, heads, cl, cr);
    const first = si === 0, last = i + step >= N;
    for (let k = 0; k < part; k++) {
      let w = 1;
      if (!first && k < fade) w = k / fade;
      if (!last && k >= C - fade) w = Math.min(w, (C - k) / fade);
      cnt[i + k] += w;
      for (const nm of names) { acc[nm][0][i + k] += res[nm][0][k] * w; acc[nm][1][i + k] += res[nm][1][k] * w; }
    }
    onProgress?.((si + 1) / starts.length);
  }
  const result = {};
  for (const nm of names) {
    const ol = new Float32Array(n), or = new Float32Array(n);
    for (let k = 0; k < n; k++) { const c = cnt[border + k] || 1; ol[k] = acc[nm][0][border + k] / c; or[k] = acc[nm][1][border + k] / c; }
    result[nm] = [ol, or];
  }
  return result;
}

const runModel = (name, L, R, p) => withGpuFallback(`modelo ${name}`, () => runModelRaw(name, L, R, p));
const runDemucs = (L, R, p) => withGpuFallback('demucs', () => runDemucsRaw(L, R, p));
const runOrchestra = (L, R, names, p) => withGpuFallback('orquesta', () => runOrchestraRaw(L, R, names, p));

function writeWav24(file, L, R) {
  const n = L.length;
  const dataSize = n * 2 * 3;
  const b = Buffer.alloc(44 + dataSize);
  b.write('RIFF', 0); b.writeUInt32LE(36 + dataSize, 4); b.write('WAVE', 8);
  b.write('fmt ', 12); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(2, 22);
  b.writeUInt32LE(SR, 24); b.writeUInt32LE(SR * 6, 28); b.writeUInt16LE(6, 32); b.writeUInt16LE(24, 34);
  b.write('data', 36); b.writeUInt32LE(dataSize, 40);
  let o = 44;
  for (let i = 0; i < n; i++) {
    for (const v of [L[i], R[i]]) {
      let s = Math.round(Math.max(-1, Math.min(1, v)) * 8388607);
      if (s < 0) s += 16777216;
      b[o++] = s & 255; b[o++] = (s >> 8) & 255; b[o++] = (s >> 16) & 255;
    }
  }
  fs.writeFileSync(file, b);
}

const sub = (a, b) => { const o = new Float32Array(a.length); for (let i = 0; i < a.length; i++) o[i] = a[i] - b[i]; return o; };

const add = (a, b) => { const o = new Float32Array(a.length); for (let i = 0; i < a.length; i++) o[i] = a[i] + b[i]; return o; };

const NAMES = { vocals: 'Voz', drums: 'Batería', bass: 'Bajo', guitar: 'Guitarra', piano: 'Piano', other: 'Otros', instrumental: 'Instrumental' };

// Separa en memoria (sin escribir archivos). want: Set de 'vocals','drums','bass','guitar','piano','other','instrumental'
async function separateRaw(L, R, want, { quality = 'best', onProgress, extraWeight = 0 } = {}) {
  const needRest = ['drums', 'bass', 'guitar', 'piano', 'other'].some((k) => want.has(k));
  const needVocals = (want.has('vocals') || want.has('instrumental')) && (quality === 'best' || !needRest);
  // reparto del progreso
  const parts = [];
  if (needVocals) parts.push(['voc', 1]);
  if (needRest) parts.push(['rest', 1.4]);
  if (extraWeight) parts.push(['extra', extraWeight]);
  const totalW = parts.reduce((a, p) => a + p[1], 0);
  let doneW = 0;
  const prog = (w) => (p) => onProgress?.(Math.min(0.99, (doneW + w * p) / totalW));

  const out = {};
  let inst = null;
  if (needVocals) {
    const [vl, vr] = await runModel('vocals', L, R, prog(1));
    doneW += 1;
    out.vocals = [vl, vr];
    inst = [sub(L, vl), sub(R, vr)];
    out.instrumental = inst;
  }
  if (needRest) {
    const w = parts.find((p) => p[0] === 'rest')[1];
    const srcL = inst ? inst[0] : L, srcR = inst ? inst[1] : R;
    // Demucs 6 stems. "Mejor": la voz sale de UVR y Demucs separa el instrumental.
    // "Rápida": una sola pasada de Demucs sobre la mezcla.
    const d = await runDemucs(srcL, srcR, prog(w));
    doneW += w;
    Object.assign(out, { drums: d.drums, bass: d.bass, guitar: d.guitar, piano: d.piano });
    if (!inst) {
      out.vocals = d.vocals;
      out.instrumental = [sub(L, d.vocals[0]), sub(R, d.vocals[1])];
    }
    // "Otros" = todo lo que queda, así la suma de los stems da exactamente la mezcla original
    let ol = srcL, or = srcR;
    for (const k of ['drums', 'bass', 'guitar', 'piano'].concat(inst ? [] : ['vocals'])) { ol = sub(ol, d[k][0]); or = sub(or, d[k][1]); }
    out.other = [ol, or];
  }

  // control de seguridad: un stem nunca puede ser mucho más fuerte que la mezcla original
  checkLoud(L, out);
  return { out, doneW, totalW };
}

function checkLoud(L, stems) {
  const rms = (a) => { let t = 0; for (let i = 0; i < a.length; i += 7) t += a[i] * a[i]; return Math.sqrt(t / Math.ceil(a.length / 7)); };
  const mixRms = rms(L) + 1e-6;
  for (const [k, v] of Object.entries(stems)) {
    if (!v) continue;
    const r = rms(v[0]);
    if (!Number.isFinite(r) || r > mixRms * 3) {
      markBroken(`stem ${k} salió con ruido`);
      throw new Error('El resultado salió con ruido. Desactivé la placa de video: probá de nuevo.');
    }
  }
}

// opts: { stems: ['vocals','drums',...,'instrumental'], quality: 'best'|'fast' }
// (compatibilidad: mode 'two' | 'four')
async function separate(file, mode, { onProgress, stems: picked, quality = 'best' } = {}) {
  if (!picked) picked = mode === 'four' ? ['vocals', 'drums', 'bass', 'other'] : ['vocals', 'instrumental'];
  if (mode === 'two') quality = 'fast';
  const want = new Set(picked);
  if (!want.size) throw new Error('No elegiste ningún stem');
  // stems de orquesta (prefijo "orq:")
  const orqWant = [...want].filter((k) => k.startsWith('orq:')).map((k) => k.slice(4));
  orqWant.forEach((k) => want.delete(`orq:${k}`));
  const orqRest = orqWant.includes('rest');
  const orqNames = orqWant.filter((k) => k !== 'rest');

  const [L, R] = await av.decodeStereo(file, SR);
  const base = path.basename(file, path.extname(file));
  let dir = path.join(path.dirname(file), `${base} (stems)`);
  for (let i = 2; fs.existsSync(dir); i++) dir = path.join(path.dirname(file), `${base} (stems ${i})`);

  const orqW = orqNames.length ? 2 + 0.3 * orqNames.length : 0;
  const { out, doneW: dw, totalW } = await separateRaw(L, R, want, { quality, onProgress, extraWeight: orqW });
  let doneW = dw;
  const prog = (w) => (p) => onProgress?.(Math.min(0.99, (doneW + w * p) / totalW));
  const parts = [['orq', orqW]];
  const orqOut = {};
  if (orqNames.length) {
    const w = parts.find((p) => p[0] === 'orq')[1];
    Object.assign(orqOut, await runOrchestra(L, R, orqNames, prog(w)));
    doneW += w;
    if (orqRest) {
      let rl = L, rr = R;
      for (const k of orqNames) { rl = sub(rl, orqOut[k][0]); rr = sub(rr, orqOut[k][1]); }
      orqOut.rest = [rl, rr];
    }
  }

  checkLoud(L, orqOut);

  fs.mkdirSync(dir, { recursive: true });
  const files = [];
  for (const k of [...orqNames, ...(orqRest ? ['rest'] : [])]) {
    const f = path.join(dir, `${base} - ${k === 'rest' ? 'Resto (orquesta)' : ORQ_NAMES[k]}.wav`);
    writeWav24(f, orqOut[k][0], orqOut[k][1]);
    files.push(f);
  }
  for (const k of ['vocals', 'drums', 'bass', 'guitar', 'piano', 'other', 'instrumental']) {
    if (!want.has(k) || !out[k]) continue;
    const f = path.join(dir, `${base} - ${NAMES[k]}.wav`);
    writeWav24(f, out[k][0], out[k][1]);
    files.push(f);
  }
  onProgress?.(1);
  return files;
}

function warmUp() { session('vocals').catch(() => {}); }

module.exports = { separate, separateRaw, warmUp, orqAvailable, _test: { demucsSegment, session, roformerChunk, orqSession, orqDir } };
