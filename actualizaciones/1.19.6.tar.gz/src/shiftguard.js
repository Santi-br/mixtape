// Windows: proceso aparte (Electron como Node) que no deja que el Explorador reciba el Shift
// mientras tenés un archivo agarrado con el mouse. Si el Explorador lo recibe antes de que el
// archivo empiece a moverse, lo toma como "Shift + clic" y selecciona todo lo que hay en el medio.
// Avisa por stdout "S1" / "S0" cuando el Shift (bloqueado) se aprieta / se suelta, así MIXTAPE igual
// sabe que está apretado. Si este proceso falla, MIXTAPE sigue andando como antes.
// Uso: <electron> shiftguard.js <anyApp 0|1>   (con ELECTRON_RUN_AS_NODE=1)
const fs = require('fs');
const koffi = require('koffi');

const anyApp = process.argv[2] === '1';
const user32 = koffi.load('user32.dll');
const kernel32 = koffi.load('kernel32.dll');

const KBD = koffi.struct('MIXTAPE_KBDLL', { vkCode: 'uint32_t', scanCode: 'uint32_t', flags: 'uint32_t', time: 'uint32_t', extra: 'uintptr_t' });
const MSG = koffi.struct('MIXTAPE_MSG', { hwnd: 'void *', message: 'uint32_t', wParam: 'uintptr_t', lParam: 'intptr_t', time: 'uint32_t', x: 'long', y: 'long', priv: 'uint32_t' });
const HookProc = koffi.proto('intptr_t __stdcall MIXTAPE_HookProc(int nCode, uintptr_t wParam, void *lParam)');

const SetWindowsHookExW = user32.func('void * __stdcall SetWindowsHookExW(int idHook, MIXTAPE_HookProc *lpfn, void *hmod, uint32_t threadId)');
const CallNextHookEx = user32.func('intptr_t __stdcall CallNextHookEx(void *hhk, int nCode, uintptr_t wParam, void *lParam)');
const GetMessageW = user32.func('int __stdcall GetMessageW(_Out_ MIXTAPE_MSG *msg, void *hwnd, uint32_t min, uint32_t max)');
const SetTimer = user32.func('uintptr_t __stdcall SetTimer(void *hwnd, uintptr_t id, uint32_t ms, void *fn)');
const GetAsyncKeyState = user32.func('short __stdcall GetAsyncKeyState(int vKey)');
const GetSystemMetrics = user32.func('int __stdcall GetSystemMetrics(int index)');
const GetForegroundWindow = user32.func('void * __stdcall GetForegroundWindow()');
const GetAncestor = user32.func('void * __stdcall GetAncestor(void *hwnd, uint32_t flags)');
const GetClassNameW = user32.func('int __stdcall GetClassNameW(void *hwnd, void *buf, int max)');
const GetModuleHandleW = kernel32.func('void * __stdcall GetModuleHandleW(void *name)');

// mismas ventanas que el vigía (Explorador, escritorio y navegadores)
const ALLOWED = new Set(['CabinetWClass', 'ExploreWClass', 'Progman', 'WorkerW', 'Chrome_WidgetWin_1', 'MozillaWindowClass']);
const SHIFTS = new Set([0x10, 0xa0, 0xa1]);
const WM_KEYDOWN = 0x100, WM_KEYUP = 0x101, WM_SYSKEYDOWN = 0x104, WM_SYSKEYUP = 0x105;

const say = (t) => { try { fs.writeSync(1, t + '\n'); } catch { process.exit(0); } };
const mouseHeld = () => {
  const vk = GetSystemMetrics(23 /* SM_SWAPBUTTON */) ? 0x02 : 0x01;
  return (GetAsyncKeyState(vk) & 0x8000) !== 0;
};
const foregroundOk = () => {
  if (anyApp) return true;
  try {
    const w = GetForegroundWindow();
    if (!w) return false;
    const root = GetAncestor(w, 2) || w;
    const buf = Buffer.alloc(512);
    const n = GetClassNameW(root, buf, 256);
    return ALLOWED.has(buf.toString('utf16le', 0, n * 2));
  } catch { return false; }
};

const passed = new Set();   // Shift que el Explorador sí vio (apretado antes de agarrar el archivo)
const blocked = new Set();  // Shift que le escondimos
let hook = null;

function proc(nCode, wParam, lParam) {
  try {
    if (nCode >= 0) {
      const k = koffi.decode(lParam, KBD);
      if (SHIFTS.has(k.vkCode)) {
        const down = wParam === WM_KEYDOWN || wParam === WM_SYSKEYDOWN;
        const up = wParam === WM_KEYUP || wParam === WM_SYSKEYUP;
        if (down) {
          if (blocked.has(k.vkCode)) return 1;              // repetición de uno ya escondido
          if (!passed.has(k.vkCode) && mouseHeld() && foregroundOk()) {
            blocked.add(k.vkCode);
            if (blocked.size === 1) say('S1');
            return 1;
          }
          passed.add(k.vkCode);
        } else if (up) {
          if (blocked.delete(k.vkCode)) {
            if (!blocked.size) say('S0');
            return 1;
          }
          passed.delete(k.vkCode);
        }
      }
    }
  } catch {}
  return CallNextHookEx(hook, nCode, wParam, lParam);
}

const cb = koffi.register(proc, koffi.pointer(HookProc));
hook = SetWindowsHookExW(13 /* WH_KEYBOARD_LL */, cb, GetModuleHandleW(null), 0);
if (!hook) { say('ERR'); process.exit(1); }
say('OK');

// cada 2 s se despierta para ver si MIXTAPE sigue abierta
SetTimer(null, 0, 2000, null);
const ppid = process.ppid;
const msg = {};
while (GetMessageW(msg, null, 0, 0) > 0) {
  try { process.kill(ppid, 0); } catch { process.exit(0); }
}
