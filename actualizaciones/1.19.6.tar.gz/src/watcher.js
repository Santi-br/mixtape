// Detecta "arrastrando un archivo + Shift" leyendo el estado del mouse/teclado.
// Windows: user32 (GetAsyncKeyState...). Mac: CoreGraphics (CGEventSource...State).
const { EventEmitter } = require('events');

// Explorador, escritorio y navegadores (para arrastrar links). La rueda igual solo se muestra
// si lo que se arrastra es un archivo o un link.
const ALLOWED_ROOTS = new Set(['CabinetWClass', 'ExploreWClass', 'Progman', 'WorkerW', 'Chrome_WidgetWin_1', 'MozillaWindowClass']);

class DragWatcher extends EventEmitter {
  constructor() {
    super();
    this.enabled = true;
    this.anyApp = false;
    this.timer = null;
    this.state = { down: false, start: null, allowed: false, fired: false };
    this.mac = process.platform === 'darwin';
    if (this.mac) { this.initMac(); return; }
    if (process.platform !== 'win32') return;

    const koffi = require('koffi');
    const user32 = koffi.load('user32.dll');
    const POINT = koffi.struct('RUEDITA_POINT', { x: 'long', y: 'long' });
    this.GetAsyncKeyState = user32.func('short __stdcall GetAsyncKeyState(int vKey)');
    this.GetCursorPos = user32.func('bool __stdcall GetCursorPos(_Out_ RUEDITA_POINT *pt)');
    this.WindowFromPoint = user32.func('void * __stdcall WindowFromPoint(RUEDITA_POINT pt)');
    this.GetAncestor = user32.func('void * __stdcall GetAncestor(void *hwnd, uint32_t flags)');
    this.GetClassNameW = user32.func('int __stdcall GetClassNameW(void *hwnd, void *buf, int max)');
    this.GetSystemMetrics = user32.func('int __stdcall GetSystemMetrics(int index)');
  }

  // ---------- Mac ----------
  initMac() {
    const koffi = require('koffi');
    const cg = koffi.load('/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics');
    // estado combinado de la sesión (0): no hace falta escuchar eventos, solo preguntar
    this.CGEventSourceFlagsState = cg.func('uint64_t CGEventSourceFlagsState(int32_t state)');
    this.CGEventSourceButtonState = cg.func('bool CGEventSourceButtonState(int32_t state, uint32_t button)');
    this.CGEventSourceKeyState = cg.func('bool CGEventSourceKeyState(int32_t state, uint16_t key)');
    try {
      this.CGPreflightListenEventAccess = cg.func('bool CGPreflightListenEventAccess()');
      this.CGRequestListenEventAccess = cg.func('bool CGRequestListenEventAccess()');
    } catch {}
  }

  // pide el permiso de "Monitoreo de entrada" si hace falta (macOS 10.15+); devuelve si ya está dado
  ensureMacAccess() {
    if (!this.mac || !this.CGPreflightListenEventAccess) return true;
    try {
      if (this.CGPreflightListenEventAccess()) return true;
      this.CGRequestListenEventAccess();
    } catch {}
    return false;
  }

  macFlags() { try { return Number(this.CGEventSourceFlagsState(0)); } catch { return 0; } }

  isDown(vk) {
    if (this.mac) {
      if (vk === 0x01) return this.CGEventSourceButtonState(0, 0);
      if (vk === 0x1b) return this.CGEventSourceKeyState(0, 53); // Esc
      const f = this.macFlags();
      if (vk === 0x10) return (f & 0x20000) !== 0;  // Shift
      if (vk === 0x11) return (f & 0x40000) !== 0;  // Control
      if (vk === 0x12) return (f & 0x80000) !== 0;  // Option
      return false;
    }
    if (vk === 0x10 && this.guardShift) return true; // Shift escondido al Explorador (ver shiftguard.js)
    return (this.GetAsyncKeyState(vk) & 0x8000) !== 0;
  }

  // Windows: que el Explorador no reciba el Shift mientras hay un archivo agarrado (si no, selecciona
  // todo lo que hay entre los archivos elegidos). Corre en un proceso aparte: si falla, no rompe nada.
  syncGuard() {
    if (this.mac || process.platform !== 'win32' || this.noGuard) return;
    const want = this.enabled && this.key !== 'alt' ? (this.anyApp ? '1' : '0') : null;
    if (want === this.guardCfg) return;
    this.guardCfg = want;
    this.guardShift = false;
    if (this.guard) { try { this.guard.kill(); } catch {} this.guard = null; }
    if (want === null) return;
    try {
      const { spawn } = require('child_process');
      const path = require('path');
      const g = spawn(process.execPath, [path.join(__dirname, 'shiftguard.js'), want], {
        env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }, stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true,
      });
      this.guard = g; this.guardOk = false;
      let buf = '';
      g.stdout.on('data', (d) => {
        buf += d;
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          if (line === 'S1') this.guardShift = true;
          else if (line === 'S0') this.guardShift = false;
          else if (line === 'OK') this.guardOk = true;
        }
      });
      g.on('exit', (code) => {
        if (this.guard !== g) return;
        this.guard = null; this.guardShift = false;
        // si se cayó apenas arrancó, no se reintenta (queda como antes: el Shift llega al Explorador)
        this.guardRestarts = (this.guardRestarts || 0) + 1;
        if (!this.guardOk || this.guardRestarts > 5) { this.noGuard = true; this.emit('guard-failed', code); } else this.guardCfg = undefined;
      });
    } catch (e) { this.noGuard = true; this.emit('guard-failed', String(e.message || e)); }
  }

  stopGuard() {
    if (this.guard) { try { this.guard.kill(); } catch {} this.guard = null; }
    this.guardShift = false; this.guardCfg = undefined;
  }

  // tecla elegida en el menú: 'shift' | 'alt' | 'ctrlshift'
  keyHeld() {
    const shift = this.isDown(0x10), ctrl = this.isDown(0x11), alt = this.isDown(0x12);
    if (this.key === 'alt') return alt && !ctrl;
    if (this.key === 'ctrlshift') return ctrl && shift;
    return shift && !ctrl && !alt;
  }

  cursor() {
    if (this.mac) { const p = require('electron').screen.getCursorScreenPoint(); return { x: p.x, y: p.y }; }
    const pt = {};
    this.GetCursorPos(pt);
    return pt;
  }

  rootClassAt(pt) {
    if (this.mac) return '';
    try {
      const hwnd = this.WindowFromPoint(pt);
      if (!hwnd) return '';
      const root = this.GetAncestor(hwnd, 2 /* GA_ROOT */) || hwnd;
      const buf = Buffer.alloc(512);
      const n = this.GetClassNameW(root, buf, 256);
      return buf.toString('utf16le', 0, n * 2);
    } catch {
      return '';
    }
  }

  start() {
    if ((process.platform !== 'win32' && !this.mac) || this.timer) return;
    this.timer = setInterval(() => this.tick(), 30);
  }

  stop() {
    clearInterval(this.timer);
    this.timer = null;
    this.stopGuard();
  }

  tick() {
    this.syncGuard();
    if (!this.enabled) return;
    const swapped = !this.mac && this.GetSystemMetrics(23 /* SM_SWAPBUTTON */) !== 0;
    const lDown = this.isDown(swapped ? 0x02 : 0x01);
    const s = this.state;

    if (lDown && !s.down) {
      const pt = this.cursor();
      const cls = this.rootClassAt(pt);
      // en Mac no hay forma barata de saber la app de abajo: se permite siempre y la rueda
      // igual queda invisible si lo que se arrastra no es un archivo o un link
      this.state = { down: true, start: pt, allowed: !this.paused && (this.mac || this.anyApp || ALLOWED_ROOTS.has(cls)), fired: false, cls };
      return;
    }

    if (!lDown && s.down) {
      const fired = s.fired;
      this.state = { down: false, start: null, allowed: false, fired: false };
      if (fired) this.emit('release');
      return;
    }

    if (lDown && s.down && !s.fired && s.allowed) {
      if (!this.keyHeld()) return;
      const pt = this.cursor();
      const dist = Math.hypot(pt.x - s.start.x, pt.y - s.start.y);
      if (dist < 24) return;
      s.fired = true;
      this.emit('trigger', pt);
    }

    if (s.fired && this.isDown(0x1b /* VK_ESCAPE */)) this.emit('cancel');
  }
}

module.exports = { DragWatcher };
