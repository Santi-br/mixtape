// Rutas de los programas incluidos según el sistema.
// Mac: las Apple Silicon con macOS 11 usan el ffmpeg de Intel (por Rosetta), porque el nativo pide macOS 12.
const path = require('path');
const os = require('os');

const BIN = path.join(__dirname, '..', 'bin');
const macOld = process.platform === 'darwin' && parseInt(os.release(), 10) < 21; // Darwin 21 = macOS 12

function ffmpeg() {
  if (process.platform === 'win32') return path.join(BIN, 'ffmpeg.exe');
  if (process.platform === 'darwin') return path.join(BIN, process.arch === 'arm64' && !macOld ? 'ffmpeg-mac-arm64' : 'ffmpeg-mac-x64');
  return path.join(BIN, 'ffmpeg-linux');
}
function ytdlp() {
  if (process.platform === 'win32') return path.join(BIN, 'yt-dlp.exe');
  if (process.platform === 'darwin') return path.join(BIN, 'yt-dlp_macos');
  return path.join(BIN, 'yt-dlp_linux');
}

// Carpetas donde puede estar un paquete aparte ("orquesta", "midi-pro").
// Windows: al lado de MIXTAPE.exe (o en la carpeta "Ruedita" de antes, si está al lado). Mac: en Application Support
// (donde lo copia "Instalar paquete…"; también la carpeta vieja de Ruedita), al lado de MIXTAPE.app, o en Descargas.
const MAC_DATA = path.join(os.homedir(), 'Library', 'Application Support', 'MIXTAPE');
const MAC_DATA_OLD = path.join(os.homedir(), 'Library', 'Application Support', 'Ruedita');
function packDirs(name) {
  const here = path.dirname(process.execPath);
  if (process.platform !== 'darwin') return [path.join(here, name), path.join(here, '..', 'Ruedita', name)];
  return [path.join(MAC_DATA, name), path.join(MAC_DATA_OLD, name), path.join(path.resolve(process.execPath, '../../../..'), name), path.join(os.homedir(), 'Downloads', name)];
}

module.exports = { BIN, FFMPEG: ffmpeg(), YTDLP: ytdlp(), MAC_DATA, packDirs };
