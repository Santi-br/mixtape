// Arranque de MIXTAPE. Si la app ya bajó una actualización chica (solo el código, unos pocos MB) la usa;
// si no, corre la versión que vino instalada. Las actualizaciones viven en <userData>/actualizaciones/<versión>/
// con su propio src/ y package.json, y accesos (junctions en Windows) a node_modules, models, bin y assets de la
// instalación, así no hay que tocar la carpeta de la app (en la Mac tampoco se rompe la firma).
//
// Seguridad: la primera vez que arranca una versión nueva queda "probando"; si ese arranque no llega a
// confirmarse (update.js la marca "ok" apenas arranca) el próximo arranque vuelve a la instalada y la marca "mala".
const { app } = require('electron');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const BUNDLED = require('../package.json').version;
const DIR = path.join(app.getPath('userData'), 'actualizaciones');
const STATE = path.join(DIR, 'actual.json');

function newer(a, b) {
  const pa = String(a).split('.').map((x) => parseInt(x, 10) || 0), pb = String(b).split('.').map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0; }
  return false;
}
const save = (st) => { try { fs.writeFileSync(STATE, JSON.stringify(st)); } catch {} };

function pick() {
  try {
    if (process.env.MX_NO_UPDATES) return null;
    const st = JSON.parse(fs.readFileSync(STATE, 'utf8'));
    if (!st.version || !newer(st.version, BUNDLED) || st.estado === 'mala') return null;
    const root = path.join(DIR, st.version);
    if (!fs.existsSync(path.join(root, 'src', 'main.js'))) return null;
    if (st.estado === 'probando') { save({ ...st, estado: 'mala' }); return null; } // el arranque anterior se cayó
    if (st.estado === 'nueva') save({ ...st, estado: 'probando' });
    return { root, version: st.version };
  } catch { return null; }
}

// una segunda apertura (doble clic con la app ya abierta) no tiene que tocar nada: le avisa a la primera y se va
const LOCKED = app.requestSingleInstanceLock();
if (!LOCKED) { app.quit(); process.exit(0); }
const u = pick();
global.MX = { locked: true, bundled: BUNDLED, bundledRoot: ROOT, version: u ? u.version : BUNDLED, root: u ? u.root : ROOT, updatesDir: DIR, newer };
if (u) {
  try {
    require(path.join(u.root, 'src', 'main.js'));
  } catch (err) {
    try { fs.appendFileSync(path.join(app.getPath('userData'), 'mixtape-errores.txt'), `[${new Date().toISOString()}] actualización ${u.version} no arrancó\n${err && err.stack}\n\n`); } catch {}
    save({ version: u.version, estado: 'mala' });
    app.relaunch();
    app.exit(0);
  }
} else {
  require('./main.js');
}
