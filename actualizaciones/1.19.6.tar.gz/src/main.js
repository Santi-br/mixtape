const { app, BrowserWindow, Tray, Menu, ipcMain, screen, Notification, shell, nativeImage, dialog, desktopCapturer, clipboard, globalShortcut } = require('electron');
const path = require('path');
const fs = require('fs');
const { DragWatcher } = require('./watcher');
const { catalog, kindFromExt, IMAGE_EXTS, PDF_EXTS, AUDIO_EXTS, VIDEO_EXTS } = require('./catalog');
const ops = require('./ops');
const updater = require('./update');

const SIZE = 400; // tamaño de la ventana de la rueda (DIP)
// Diseños de la rueda: tamaño de la ventana y dónde queda el cursor adentro (ax, ay)
const DESIGNS = {
  rueda: { w: 400, h: 400, ax: 200, ay: 200 },
  carrusel: { w: 440, h: 320, ax: 220, ay: 212 },
};
const DESIGN = 'carrusel'; // diseño elegido; la rueda clásica queda de respaldo
const geo = () => DESIGNS[DESIGN];
const designInfo = () => ({ id: DESIGN, ...geo() });
const ASSETS = path.join(__dirname, '..', 'assets');
// Windows 11 22H2+ tiene "acrylic" nativo para las ventanas
const GLASS = process.platform === 'win32' && Number(require('os').release().split('.')[2] || 0) >= 22621;
const MAC = process.platform === 'darwin';

if (!(global.MX && global.MX.locked) && !app.requestSingleInstanceLock()) {
  app.quit();
  process.exit(0);
}
// mismo id que cuando se llamaba Ruedita: así el "iniciar con Windows" y las notificaciones siguen siendo de la misma app
app.setAppUserModelId('com.santibrons.ruedita');
process.env.RUEDITA_USERDATA = app.getPath('userData');
// la primera vez como MIXTAPE trae los ajustes y los recientes de Ruedita (no se borra nada de la carpeta vieja)
const OLD_DATA = path.join(app.getPath('appData'), 'Ruedita');
try {
  const ud = app.getPath('userData');
  if (ud !== OLD_DATA && !fs.existsSync(path.join(ud, 'ajustes.json')) && fs.existsSync(path.join(OLD_DATA, 'ajustes.json'))) {
    fs.mkdirSync(ud, { recursive: true });
    for (const f of ['ajustes.json', 'recientes.json', 'gpu-estado.json']) {
      try { if (fs.existsSync(path.join(OLD_DATA, f))) fs.copyFileSync(path.join(OLD_DATA, f), path.join(ud, f)); } catch {}
    }
  }
} catch {}

let overlay, worker, tray, watcher;
let overlayVisible = false;
let hideTimer = null;
let busy = 0;

// ---------- ajustes ----------
const settingsPath = () => path.join(app.getPath('userData'), 'ajustes.json');
let settings = { firstRun: true, anyApp: false, paused: false, key: 'shift' };
function loadSettings() {
  try { settings = { ...settings, ...JSON.parse(fs.readFileSync(settingsPath(), 'utf8')) }; } catch {}
}
function saveSettings() {
  try { fs.writeFileSync(settingsPath(), JSON.stringify(settings, null, 2)); } catch {}
}

// ---------- ventanas ----------
function createOverlay() {
  overlay = new BrowserWindow({
    width: geo().w, height: geo().h, show: false, frame: false, transparent: true,
    resizable: false, movable: false, minimizable: false, maximizable: false,
    alwaysOnTop: true, skipTaskbar: true, focusable: MAC, hasShadow: false,
    backgroundColor: '#00000000',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), backgroundThrottling: false },
  });
  overlay.setAlwaysOnTop(true, MAC ? 'pop-up-menu' : 'screen-saver');
  overlay.setVisibleOnAllWorkspaces(true);
  // la rueda no aparece en capturas: así podemos capturar lo que hay debajo para el efecto vidrio
  if (process.platform === 'win32' || MAC) overlay.setContentProtection(true);
  overlay.loadFile(path.join(__dirname, 'overlay', 'index.html'));
}

function createWorker() {
  worker = new BrowserWindow({
    show: false, width: 200, height: 200,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), backgroundThrottling: false },
  });
  worker.loadFile(path.join(__dirname, 'worker', 'pdf.html'));
}

function showOverlay() {
  clearTimeout(hideTimer);
  const p = screen.getCursorScreenPoint();
  const g = geo();
  overlay.setBounds({ x: Math.round(p.x - g.ax), y: Math.round(p.y - g.ay), width: g.w, height: g.h });
  overlay.webContents.send('show');
  overlay.showInactive();
  overlay.setAlwaysOnTop(true, MAC ? 'pop-up-menu' : 'screen-saver');
  overlayVisible = true;
  overlayActive = false;
  clearTimeout(armTimer);
  if (MAC) { overlay.setIgnoreMouseEvents(false); overlay.moveTop(); }
  if (diag) { diag.shown++; setTimeout(() => { if (diag && overlay.isVisible()) diag.visible++; }, 150); }
  armTimer = setTimeout(() => { if (!overlayActive) hideOverlay(); }, MAC ? 4000 : 1200);
  captureBackdrop(p).catch(() => {});
}
let armTimer = null, overlayActive = false, watcherError = null, diag = null;
ipcMain.on('diag-ev', (_e, t) => { if (diag) diag.ev[t] = (diag.ev[t] || 0) + 1; });
ipcMain.on('overlay-active', () => { overlayActive = true; clearTimeout(armTimer); if (diag) diag.active++; });

// Captura la zona de la pantalla debajo de la rueda y se la pasa para desenfocarla (vidrio líquido)
let captureSeq = 0;
async function captureBackdrop(p) {
  if (process.platform !== 'win32' && !MAC) return;
  const seq = ++captureSeq;
  const d = screen.getDisplayNearestPoint(p);
  const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: d.size.width, height: d.size.height } });
  if (seq !== captureSeq || !overlayVisible) return;
  const src = sources.find((s) => s.display_id === String(d.id)) || (sources.length === 1 ? sources[0] : null);
  if (!src || src.thumbnail.isEmpty()) return;
  const thumb = src.thumbnail;
  const kx = thumb.getSize().width / d.bounds.width, ky = thumb.getSize().height / d.bounds.height;
  // rectángulo de la rueda en coordenadas del monitor, recortado a sus bordes
  const g = geo();
  const wx = Math.round(p.x - g.ax) - d.bounds.x, wy = Math.round(p.y - g.ay) - d.bounds.y;
  const x0 = Math.max(0, wx), y0 = Math.max(0, wy);
  const x1 = Math.min(d.bounds.width, wx + g.w), y1 = Math.min(d.bounds.height, wy + g.h);
  if (x1 <= x0 || y1 <= y0) return;
  const crop = thumb.crop({ x: Math.round(x0 * kx), y: Math.round(y0 * ky), width: Math.round((x1 - x0) * kx), height: Math.round((y1 - y0) * ky) });
  // luminosidad promedio → texto oscuro o claro
  const tiny = crop.resize({ width: 8, height: 8, quality: 'good' }).toBitmap(); // BGRA
  let lum = 0;
  for (let i = 0; i < tiny.length; i += 4) lum += 0.0722 * tiny[i] + 0.7152 * tiny[i + 1] + 0.2126 * tiny[i + 2];
  lum /= tiny.length / 4;
  const small = crop.resize({ width: Math.round((x1 - x0) / 2), height: Math.round((y1 - y0) / 2), quality: 'good' });
  overlay.webContents.send('backdrop', {
    dataUrl: small.toDataURL(), x: x0 - wx, y: y0 - wy, w: x1 - x0, h: y1 - y0,
    tone: lum < 140 ? 'dark' : 'light',
  });
}

function hideOverlay() {
  clearTimeout(hideTimer);
  if (!overlayVisible) return;
  overlayVisible = false;
  overlay.webContents.send('hide');
  setTimeout(() => { if (!overlayVisible) overlay.hide(); }, 120);
}

// ---------- worker de PDF ----------
let jobSeq = 0;
const pending = new Map();
ipcMain.on('pdf-result', (_e, msg) => {
  const p = pending.get(msg.id);
  if (!p) return;
  pending.delete(msg.id);
  if (msg.error) p.reject(new Error(msg.error));
  else p.resolve(msg);
});
function pdfJob(mode, bytes, scale = 2) {
  return new Promise((resolve, reject) => {
    const id = ++jobSeq;
    pending.set(id, { resolve, reject });
    worker.webContents.send('pdf-job', { id, mode, bytes: new Uint8Array(bytes), scale });
  });
}
const pdfCtx = {
  renderPdf: async (bytes) => (await pdfJob('render', bytes)).pages.map((u) => Buffer.from(u)),
  textPdf: async (bytes) => (await pdfJob('text', bytes)).text,
};

// ---------- diálogos (recortar, tamaño, fondo) ----------
// recortar video/audio: cuadritos, forma de onda y copia liviana para ver formatos que el editor no reproduce
const editorTemps = new Map();
ipcMain.handle('media-thumbs', (_e, file, n) => require('./av').thumbnails(file, n));
ipcMain.handle('media-peaks', (_e, file) => require('./av').peaks(file));
ipcMain.handle('media-proxy', async (e, file) => {
  const tmp = await require('./av').previewProxy(file);
  editorTemps.get(e.sender.id)?.push(tmp);
  return require('url').pathToFileURL(tmp).href;
});
function openEditor(mode, files, extra = {}) {
  return new Promise((resolve) => {
    watcher.paused = true;
    const win = new BrowserWindow({
      width: { vedit: 1240, ocr: 760, rename: 1000, order: 820, transcribe: 600, vtrim: 1040, av_adjust: 560, resize: 480, upscale: 500, blur: 1100, rotate: 900, compress: 560, stems: 680, midi: 640, keybpm: 620 }[mode] || 980,
      height: { vedit: 880, ocr: 720, rename: 700, order: 600, transcribe: 740, vtrim: 780, av_adjust: 560, resize: 440, upscale: 440, blur: 820, rotate: 760, compress: 520, stems: 800, midi: 840, keybpm: 640 }[mode] || 760,
      minWidth: 420, minHeight: 360,
      title: 'MIXTAPE', autoHideMenuBar: true, show: false,
      ...(GLASS ? { backgroundMaterial: 'acrylic', backgroundColor: '#00000000' } : { backgroundColor: '#17161a' }),
      icon: path.join(ASSETS, 'icon.png'),
      webPreferences: { preload: path.join(__dirname, 'preload.js') },
    });
    let done = false;
    const temps = [];
    editorTemps.set(win.webContents.id, temps);
    const finish = (val) => {
      if (done) return;
      done = true;
      for (const t of temps) fs.promises.unlink(t).catch(() => {});
      editorTemps.delete(win.webContents.id);
      watcher.paused = false;
      ipcMain.removeHandler(`editor-init-${win.id}`);
      ipcMain.removeAllListeners(`editor-done-${win.id}`);
      if (!win.isDestroyed()) win.close();
      resolve(val);
    };
    ipcMain.handle(`editor-init-${win.id}`, async () => {
      const kind = kindFromExt(path.extname(files[0]));
      const base = { mode, files, kind, name: path.basename(files[0]), ...extra };
      if (mode === 'rename') {
        const items = [], dirs = new Set();
        for (const f of files) {
          let mtime = 0; try { mtime = fs.statSync(f).mtimeMs; } catch {}
          const k = kindFromExt(path.extname(f));
          const tags = k === 'audio' ? await require('./av').tags(f).catch(() => null) : null;
          items.push({ path: f, dir: path.dirname(f), name: path.basename(f), mtime, tags });
          dirs.add(path.dirname(f));
        }
        const existing = [];
        for (const d of dirs) { try { for (const n of fs.readdirSync(d)) existing.push(`${d}|${n}`); } catch {} }
        return { ...base, items, existing };
      }
      if (mode === 'order') {
        const sharp = require('sharp');
        const items = [];
        for (const f of files) {
          const k = kindFromExt(path.extname(f));
          const it = { path: f, name: path.basename(f), kind: k };
          try {
            if (k === 'pdf') {
              const buf = fs.readFileSync(f);
              try { const { PDFDocument } = require('pdf-lib'); it.pages = (await PDFDocument.load(buf, { ignoreEncryption: true, updateMetadata: false })).getPageCount(); } catch {}
              const [png] = (await pdfJob('render1', buf, 1)).pages;
              const small = await sharp(Buffer.from(png)).resize(220, 220, { fit: 'inside' }).png().toBuffer();
              it.thumb = `data:image/png;base64,${small.toString('base64')}`;
            } else if (k === 'image') {
              it.thumb = (await ops.preview(f, 220)).dataUrl;
            }
          } catch {}
          items.push(it);
        }
        return { ...base, items };
      }
      if (mode === 'av_adjust') {
        const av = require('./av');
        const video = files.find((f) => kindFromExt(path.extname(f)) === 'video');
        const audio = files.find((f) => kindFromExt(path.extname(f)) === 'audio');
        return { ...base, video: { name: path.basename(video), ...(await av.probe(video)) }, audio: { name: path.basename(audio), ...(await av.probe(audio)) } };
      }
      if (kind === 'image') {
        const max = { resize: 400, upscale: 400, compress: 600, blur: 1800 }[mode] || 1400;
        return { ...base, preview: await ops.preview(files[0], max) };
      }
      if (kind === 'pdf') {
        try {
          const [png] = (await pdfJob('render1', fs.readFileSync(files[0]), 1)).pages;
          const b = Buffer.from(png);
          const sharp = require('sharp');
          const m = await sharp(b).metadata();
          return { ...base, preview: { width: m.width, height: m.height, dataUrl: `data:image/png;base64,${b.toString('base64')}` } };
        } catch { return base; }
      }
      if (mode === 'vedit') return { ...base, items: await veditItems(files) };
      if (mode === 'vtrim') {
        const info = await require('./av').probe(files[0]);
        return { ...base, kind: info.hasVideo ? 'video' : 'audio', media: info, url: require('url').pathToFileURL(files[0]).href };
      }
      if (kind === 'audio' || kind === 'video') {
        const info = await require('./av').probe(files[0]);
        const orq = mode === 'stems' ? require('./stems').orqAvailable() : [];
        const pro = mode === 'midi' ? { piano: require('./midi/paths').hasPiano(), voice: require('./midi/paths').hasVoice() } : undefined;
        const tr = mode === 'transcribe' ? trInfo() : undefined;
        return { ...base, orq, pro, tr, media: { ...info, size: fs.statSync(files[0]).size } };
      }
      return base;
    });
    ipcMain.on(`editor-done-${win.id}`, (_e, val) => finish(val));
    win.on('closed', () => finish(null));
    win.once('ready-to-show', () => { win.show(); win.focus(); });
    win.loadFile(path.join(__dirname, 'editor', 'index.html'), { query: { mode, id: String(win.id), glass: GLASS ? '1' : '0' } });
  });
}

// ---------- procesar ----------
function logError(what, err) {
  try {
    const f = path.join(app.getPath('userData'), 'mixtape-errores.txt');
    fs.appendFileSync(f, `[${new Date().toISOString()}] ${what}\n${err && err.stack ? err.stack : err}\n\n`);
  } catch {}
}
function notify(title, body, file) {
  const n = new Notification({ title, body, icon: path.join(ASSETS, 'icon.png'), silent: false });
  if (file) n.on('click', () => shell.showItemInFolder(file));
  n.show();
}

function setBusy(delta) {
  busy += delta;
  tray?.setToolTip(busy > 0 ? 'MIXTAPE — procesando…' : 'MIXTAPE — arrastrá un archivo + Shift');
}

// ---------- ventanita de progreso (abajo a la derecha, arriba de la barra de tareas) ----------
let progWin = null, progReady = null, progSeq = 0;
const jobs = new Map();
const PROG_W = 360;
function ensureProgWin() {
  if (progWin && !progWin.isDestroyed()) return progReady;
  progWin = new BrowserWindow({
    width: PROG_W, height: 110, show: false, frame: false, transparent: true, resizable: false,
    minimizable: false, maximizable: false, alwaysOnTop: true, skipTaskbar: true, focusable: false, hasShadow: false,
    backgroundColor: '#00000000',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), backgroundThrottling: false },
  });
  progWin.setAlwaysOnTop(true, 'floating');
  progWin.on('closed', () => { progWin = null; });
  progReady = progWin.loadFile(path.join(__dirname, 'progress', 'index.html')).catch(() => {});
  return progReady;
}
function pushProg() {
  const list = [...jobs.values()].filter((j) => j.visible && !j.hidden);
  if (!list.length) { if (progWin && !progWin.isDestroyed()) progWin.hide(); return; }
  ensureProgWin().then(() => {
    if (!progWin || progWin.isDestroyed()) return;
    const wa = screen.getPrimaryDisplay().workArea;
    const H = 12 + list.length * 104;
    progWin.setBounds({ x: wa.x + wa.width - PROG_W - 8, y: wa.y + wa.height - H - 8, width: PROG_W, height: H });
    progWin.webContents.send('jobs', list.map(({ id, title, file, p, eta, state, got }) => ({ id, title, file, p, eta, state, indet: !got })));
    if (!progWin.isVisible()) progWin.showInactive();
  });
}
// se muestra solo si tarda más de un segundo
function startJob(title, file) {
  const j = { id: ++progSeq, title, file: file || '', p: 0, eta: null, t0: Date.now(), visible: false, state: 'run' };
  jobs.set(j.id, j);
  j.timer = setTimeout(() => { j.visible = true; pushProg(); }, 1000);
  let last = 0;
  return {
    progress(p) {
      if (!(p >= 0)) return;
      j.got = true;
      j.p = Math.min(1, p);
      const el = (Date.now() - j.t0) / 1000;
      j.eta = j.p > 0.02 && el > 3 ? (el * (1 - j.p)) / j.p : null;
      const now = Date.now();
      if (j.visible && now - last > 250) { last = now; pushProg(); }
    },
    sub(text) { j.file = text; if (j.visible) pushProg(); },
    end(ok) {
      clearTimeout(j.timer);
      if (!j.visible) { jobs.delete(j.id); return; }
      j.state = ok ? 'ok' : 'err';
      pushProg();
      setTimeout(() => { jobs.delete(j.id); pushProg(); }, ok ? 2500 : 4000);
    },
  };
}
ipcMain.on('prog-hide', (_e, id) => { const j = jobs.get(id); if (j) { j.hidden = true; pushProg(); } });

// ---------- descargador ----------
const dlDir = () => settings.dlDir || path.join(app.getPath('downloads'), 'MIXTAPE');
let dlWin = null;
function openDownloader(url) {
  if (dlWin && !dlWin.isDestroyed()) {
    if (url) dlWin.webContents.send('dl-url', url);
    dlWin.show(); dlWin.focus(); return;
  }
  const win = new BrowserWindow({
    width: 640, height: 780, minWidth: 500, minHeight: 560, title: 'MIXTAPE — Descargar', autoHideMenuBar: true, show: false,
    icon: path.join(ASSETS, 'icon.png'),
    ...(GLASS ? { backgroundMaterial: 'acrylic', backgroundColor: '#00000000' } : { backgroundColor: '#17161a' }),
    webPreferences: { preload: path.join(__dirname, 'preload.js') },
  });
  dlWin = win;
  let clip = ''; try { clip = String(clipboard.readText() || '').trim(); } catch {}
  ipcMain.handle(`editor-init-${win.id}`, async () => ({
    mode: 'download', files: [], name: '', url: url || (require('./download').isUrl(clip) ? clip : ''),
    dir: dlDir(), cookies: settings.dlCookies || '',
  }));
  ipcMain.on(`editor-done-${win.id}`, () => { if (!win.isDestroyed()) win.close(); });
  win.on('closed', () => { ipcMain.removeHandler(`editor-init-${win.id}`); ipcMain.removeAllListeners(`editor-done-${win.id}`); dlWin = null; });
  win.once('ready-to-show', () => { win.show(); win.focus(); });
  win.loadFile(path.join(__dirname, 'editor', 'index.html'), { query: { mode: 'download', id: String(win.id), glass: GLASS ? '1' : '0' } });
}
ipcMain.handle('dl-pick-dir', async (e) => {
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { properties: ['openDirectory', 'createDirectory'], defaultPath: dlDir() });
  if (r.canceled || !r.filePaths[0]) return null;
  settings.dlDir = r.filePaths[0]; saveSettings();
  return settings.dlDir;
});
ipcMain.handle('dl-probe', async (e, url, cookies) => {
  try {
    const sp = require('./spotify');
    if (sp.isSpotify(url)) {
      return await sp.probe(url);
    }
    return await require('./download').probe(url, { cookies });
  } catch (err) { logError(`probe ${url}`, err); return { error: String(err.message || err) }; }
});
ipcMain.on('dl-open', (_e, f) => { if (f) shell.showItemInFolder(f); else shell.openPath(dlDir()); });
ipcMain.handle('dl-start', async (e, { url, opts }) => {
  const wc = e.sender;
  settings.dlCookies = opts.cookies || ''; saveSettings();
  setBusy(1);
  try {
    const sp = require('./spotify');
    const engine = sp.isSpotify(url) ? sp : require('./download');
    const files = await engine.download(url, { ...opts, dir: opts.dir || dlDir() }, {
      onProgress: (p) => { if (!wc.isDestroyed()) wc.send('dl-progress', { p }); tray?.setToolTip(`MIXTAPE — descargando ${Math.round(p * 100)}%`); },
      onTitle: (t, n, total) => { if (!wc.isDestroyed()) wc.send('dl-progress', { title: t, n, total }); },
    });
    if (!files.length) throw new Error('No se descargó nada');
    notify('Descarga lista ✓', files.length === 1 ? path.basename(files[0]) : `${files.length} archivos`, files[0]);
    pushRecent({ src: url, out: files[0], n: files.length, label: 'Descarga', kind: 'link' });
    return { files };
  } catch (err) {
    logError(`descargar ${url}`, err);
    return { error: String(err.message || err) };
  } finally { setBusy(-1); }
});

// link soltado en la rueda
async function handleLink(url, id) {
  if (id === 'dl_options') return openDownloader(url);
  const mode = { dl_video: 'mp4', dl_mp3: 'mp3', dl_wav: 'wav' }[id] || 'mp4';
  setBusy(1);
  const job = startJob('Descargando', url.replace(/^https?:\/\/(www\.)?/, ''));
  try {
    const sp = require('./spotify');
    const engine = sp.isSpotify(url) ? sp : require('./download');
    const fmt = sp.isSpotify(url) && mode === 'mp4' ? 'mp3' : mode;
    const files = await engine.download(url, { format: fmt, quality: fmt === 'mp3' ? '320' : 'best', cookies: settings.dlCookies || '', dir: dlDir() }, {
      onProgress: (p) => { job.progress(p); tray?.setToolTip(`MIXTAPE — descargando ${Math.round(p * 100)}%`); },
      onTitle: (t, n, total) => job.sub(total > 1 ? `(${n}/${total}) ${t}` : t),
    });
    if (!files.length) throw new Error('No se descargó nada');
    job.end(true);
    notify('Descarga lista ✓', files.length === 1 ? path.basename(files[0]) : `${files.length} archivos`, files[0]);
    pushRecent({ src: url, out: files[0], n: files.length, label: 'Descarga', kind: 'link' });
  } catch (err) {
    job.end(false);
    logError(`descargar ${url}`, err);
    notify('No se pudo descargar', String(err.message || err).slice(0, 200));
  } finally { setBusy(-1); }
}

// detector de key y BPM: analiza y muestra el resultado en una ventanita
async function keyBpm(paths) {
  const files = paths.filter((f) => ['audio', 'video'].includes(kindFromExt(path.extname(f))));
  if (!files.length) return;
  const kb = require('./keybpm');
  setBusy(1);
  const job = startJob('Detectando key y BPM', files.length === 1 ? path.basename(files[0]) : `${files.length} archivos`);
  const results = [];
  try {
    for (let i = 0; i < files.length; i++) {
      if (files.length > 1) job.sub(`(${i + 1}/${files.length}) ${path.basename(files[i])}`);
      try {
        const r = await kb.analyze(files[i], { onProgress: (p) => job.progress((i + p) / files.length) });
        results.push({ file: files[i], name: path.basename(files[i]), ...r });
      } catch (err) {
        logError(`keybpm ${files[i]}`, err);
        results.push({ file: files[i], name: path.basename(files[i]), error: String(err.message || err) });
      }
    }
    job.end(true);
  } finally { setBusy(-1); }
  const ok = results.filter((r) => !r.error);
  if (ok.length === 1) notify(`${ok[0].key ? `${ok[0].key.name} (${ok[0].key.camelot})` : 'Sin tonalidad clara'} · ${ok[0].bpm ? `${ok[0].bpm} BPM` : 'sin tempo'}`, ok[0].name);
  openEditor('keybpm', files, { results });
}
ipcMain.handle('kb-apply', async (_e, { what, items }) => {
  const kb = require('./keybpm');
  const out = [];
  for (const it of items) {
    try {
      if (what === 'rename') out.push({ ok: true, file: kb.renameWith(it.file, it) });
      else out.push({ ok: await kb.writeTags(it.file, it), file: it.file });
    } catch (err) { logError(`keybpm ${what} ${it.file}`, err); out.push({ ok: false, file: it.file, error: String(err.message || err) }); }
  }
  return out;
});

// quitar fondo: el modelo (170 MB) se baja una sola vez, la primera vez que se usa
let rmbgInstall = null;
async function ensureRmbg() {
  const rm = require('./rmbg');
  if (rm.available()) return true;
  if (!rmbgInstall) {
    const r = await dialog.showMessageBox({
      type: 'question', buttons: ['Bajarlo ahora', 'Cancelar'], defaultId: 0, cancelId: 1, noLink: true,
      title: 'Quitar fondo', message: 'Quitar fondo usa una IA que se baja una sola vez',
      detail: 'Son 170 MB. Después funciona sin internet y las fotos no salen de tu compu.',
    });
    if (r.response !== 0) return false;
    rmbgInstall = (async () => {
      const job = startJob('Bajando el paquete Quitar fondo', '170 MB · una sola vez');
      setBusy(1);
      try {
        await require('./packs').installRmbg(rm.installDir(), { onProgress: (p) => job.progress(p) });
        job.end(true); return true;
      } catch (err) {
        job.end(false); logError('instalar quitar fondo', err);
        notify('No se pudo bajar Quitar fondo', `${err.message || err}. Fijate que haya internet y probá de nuevo.`);
        return false;
      } finally { setBusy(-1); rmbgInstall = null; }
    })();
  }
  return rmbgInstall;
}

// unir y editar video: datos de cada archivo para el editor
async function veditItems(files) {
  const av = require('./av'), sharp = require('sharp');
  const out = [];
  for (const f of files) {
    const k = kindFromExt(path.extname(f));
    const url = require('url').pathToFileURL(f).href;
    try {
      if (k === 'image') {
        const m = await sharp(f).metadata();
        const rot = (m.orientation || 1) >= 5;
        out.push({ file: f, url, kind: 'image', dur: 0, w: rot ? m.height : m.width, h: rot ? m.width : m.height, hasAudio: false });
      } else if (k === 'video' || k === 'audio') {
        const i = await av.probe(f);
        if (!i.duration) continue;
        out.push({ file: f, url, kind: i.hasVideo ? 'video' : 'audio', dur: i.duration, w: i.width, h: i.height, hasAudio: i.hasAudio });
      }
    } catch (err) { logError(`vedit ${f}`, err); }
  }
  return out;
}
ipcMain.handle('vedit-pick', async (e) => {
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), {
    title: 'Agregar al video', properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Videos, audio y fotos', extensions: ['mp4', 'mov', 'm4v', 'mkv', 'webm', 'avi', 'wmv', 'mpg', 'mpeg', 'mts', 'm2ts', 'ts', '3gp', 'mp3', 'wav', 'm4a', 'aac', 'flac', 'ogg', 'opus', 'aif', 'aiff', 'wma', 'jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'tif', 'tiff'] }],
  });
  return r.canceled ? [] : veditItems(r.filePaths);
});
async function videoEditor(paths) {
  const r = await openEditor('vedit', paths);
  if (!r || !r.project) return;
  setBusy(1);
  const job = startJob('Exportando el video', `${r.project.clips.length} clips`);
  try {
    const out = await require('./vedit').exportProject(r.project, { onProgress: (p) => job.progress(p) });
    job.end(true);
    notify('Video listo', path.basename(out), out);
    shell.showItemInFolder(out);
    pushRecent({ src: r.project.clips[0].file, out, n: 1, label: 'Editar video', kind: 'video' });
  } catch (err) {
    job.end(false); logError('exportar video', err);
    notify('No se pudo exportar el video', String(err.message || err).slice(0, 180));
  } finally { setBusy(-1); }
}

// foto a texto (OCR): lee todas las fotos y muestra el texto para copiar o guardar
async function photoToText(paths) {
  const files = paths.filter((f) => kindFromExt(path.extname(f)) === 'image');
  if (!files.length) return;
  const ocr = require('./ocr');
  setBusy(1);
  const job = startJob('Leyendo el texto', files.length === 1 ? path.basename(files[0]) : `${files.length} fotos`);
  const results = [];
  try {
    for (let i = 0; i < files.length; i++) {
      if (files.length > 1) job.sub(`(${i + 1}/${files.length}) ${path.basename(files[i])}`);
      try {
        const r = await ocr.recognize(files[i], { onProgress: (p) => job.progress((i + p) / files.length) });
        let thumb = null; try { thumb = (await ops.preview(files[i], 120)).dataUrl; } catch {}
        results.push({ file: files[i], name: path.basename(files[i]), thumb, ...r });
      } catch (err) {
        logError(`ocr ${files[i]}`, err);
        results.push({ file: files[i], name: path.basename(files[i]), error: String(err.message || err) });
      }
    }
    job.end(true);
  } finally { setBusy(-1); }
  setTimeout(() => ocr.close().catch(() => {}), 60000).unref?.();
  openEditor('ocr', files, { results });
}
ipcMain.handle('ocr-save', async (_e, { items, joined }) => {
  const free = (p) => { const ext = path.extname(p), b = p.slice(0, -ext.length); let q = p, k = 2; while (fs.existsSync(q)) q = `${b} (${k++})${ext}`; return q; };
  const out = [];
  if (joined) {
    const first = items[0].file;
    const dest = free(path.join(path.dirname(first), `${path.basename(first, path.extname(first))} y ${items.length - 1} más - texto.txt`));
    fs.writeFileSync(dest, '\ufeff' + items.map((it) => `── ${path.basename(it.file)} ──\r\n${it.text.replace(/\r?\n/g, '\r\n')}`).join('\r\n\r\n'), 'utf8');
    out.push(dest);
  } else {
    for (const it of items) {
      const dest = free(path.join(path.dirname(it.file), `${path.basename(it.file, path.extname(it.file))}.txt`));
      fs.writeFileSync(dest, '\ufeff' + it.text.replace(/\r?\n/g, '\r\n'), 'utf8');
      out.push(dest);
    }
  }
  if (out[0]) { shell.showItemInFolder(out[0]); pushRecent({ src: items[0].file, out: out[0], n: out.length, label: 'A texto', kind: 'image' }); }
  return out;
});

async function handleDrop({ paths, ring, id, urls, options: preset }) {
  if (urls?.length) return handleLink(urls[0], id);
  if (!paths?.length) return;
  if (id === 'keybpm') return keyBpm(paths);
  if (id === 'ocr') return photoToText(paths);
  if (id === 'vedit') return videoEditor(paths);
  if (id === 'rmbg' && !(await ensureRmbg())) return;
  const kindKey = Object.keys(catalog).find((k) =>
    (ring === 'format' ? catalog[k].formats : catalog[k].actions).some((i) => i.id === id));
  const list = ring === 'format' ? 'formats' : 'actions';
  let def = null;
  for (const k of Object.keys(catalog)) {
    const d = catalog[k][list].find((i) => i.id === id);
    if (d) { def = d; break; }
  }
  if (!kindKey || !def) return;

  let options = {};
  // unir en un PDF (PDFs, imágenes, o mezclados): primero elegís el orden
  const joins = id === 'merge' || id === 'pdf_join' || (ring === 'format' && id === 'pdf' && kindKey === 'image');
  if (joins && paths.length > 1 && !preset?.ordered) {
    const r = await openEditor('order', paths);
    if (!r || !r.order?.length) return; // cancelado
    paths = r.order;
  }
  if (def.dialog) {
    options = await openEditor(id, paths);
    if (!options) return; // cancelado
  }
  if (id === 'rename') return applyRenames(options.renames || []);

  setBusy(1);
  const usesAi = id === 'upscale' || (id === 'resize' && options.ai);
  const isStems = id === 'stems' || id === 'stems4' || id === 'stems2';
  const isOrq = isStems && (options?.stems || []).some((x) => String(x).startsWith('orq:'));
  const title = id === 'transcribe' ? 'Transcribiendo' : id === 'midi' ? 'Pasando a MIDI' : isOrq ? 'Separando orquesta' : id === 'stems2' ? 'Separando voz / instrumental' : isStems ? 'Separando stems'
    : usesAi ? 'Mejorando con IA' : id === 'compress' ? 'Comprimiendo' : id === 'merge' || id === 'pdf_join' ? 'Uniendo' : ring === 'format' ? `Convirtiendo a ${def.label}` : `${def.label}…`;
  const job = startJob(title, paths.length === 1 ? path.basename(paths[0]) : `${paths.length} archivos`);
  try {
    const t0 = Date.now();
    const verb = isStems ? 'separando' : usesAi ? 'mejorando' : 'procesando';
    // con varios archivos, el porcentaje es del total
    let fileIdx = 0, lastP = 0;
    const ctx = { ...pdfCtx, onProgress: (p) => {
      if (paths.length > 1 && p < lastP - 0.3) fileIdx = Math.min(paths.length - 1, fileIdx + 1);
      lastP = p;
      const tot = paths.length > 1 ? (fileIdx + p) / paths.length : p;
      job.progress(tot);
      tray?.setToolTip(`MIXTAPE — ${verb} ${Math.round(tot * 100)}%`);
    } };
    const { outputs, skipped } = await ops.run({ ring, id, files: paths, options }, ctx);
    const first = outputs[0];
    let body = outputs.length === 1 ? path.basename(first) : `${outputs.length} archivos en ${path.basename(path.dirname(first))}`;
    if (id === 'compress' && outputs.length === 1) {
      const before = fs.statSync(paths[0]).size, after = fs.statSync(first).size;
      body += `  ·  ${Math.round((1 - after / before) * 100)}% más liviano`;
    }
    if (skipped) body += `\n(${skipped} archivo/s de otro tipo quedaron afuera)`;
    job.end(true);
    notify('Listo ✓', body, first);
    pushRecent({ src: paths[0], out: first, n: outputs.length, label: ring === 'format' ? `A ${def.label}` : def.label, kind: kindKey });
    console.log(`ok ${ring}:${id} en ${Date.now() - t0}ms`);
  } catch (err) {
    job.end(false);
    console.error(err);
    logError(`${ring}:${id} ${paths.join(' | ')}`, err);
    notify('No se pudo', `${String(err.message || err).slice(0, 180)}\n(detalle en mixtape-errores.txt; tocá para abrir la carpeta)`, path.join(app.getPath('userData'), 'mixtape-errores.txt'));
  } finally {
    setBusy(-1);
  }
}

// ---------- renombrar (con deshacer) ----------
let lastRename = null;
async function renameBatch(pairs) {
  // dos pasos (primero a un nombre temporal) para que A→B y B→A no se pisen
  const done = [], tmp = [];
  try {
    for (const [i, p] of pairs.entries()) {
      const t = path.join(path.dirname(p.from), `.mixtape-ren-${process.pid}-${Date.now()}-${i}${path.extname(p.from)}`);
      await fs.promises.rename(p.from, t); tmp.push({ t, ...p });
    }
    for (const x of tmp) {
      let to = x.to, k = 2;
      const ext = path.extname(x.to), stem = x.to.slice(0, x.to.length - ext.length);
      while (fs.existsSync(to)) to = `${stem} (${k++})${ext}`;
      await fs.promises.rename(x.t, to); done.push({ from: x.from, to });
    }
    return done;
  } catch (err) {
    // vuelve todo a como estaba
    for (const d of done.reverse()) { try { await fs.promises.rename(d.to, d.from); } catch {} }
    for (const x of tmp) { try { if (fs.existsSync(x.t)) await fs.promises.rename(x.t, x.from); } catch {} }
    throw err;
  }
}
async function applyRenames(list) {
  if (!list.length) return;
  const pairs = list.map((r) => ({ from: r.from, to: path.join(path.dirname(r.from), r.to) }));
  try {
    const done = await renameBatch(pairs);
    lastRename = done;
    refreshTray();
    const n = new Notification({ title: 'Listo ✓', body: `Renombré ${done.length} ${done.length === 1 ? 'archivo' : 'archivos'}. Tocá acá para deshacer.`, icon: path.join(ASSETS, 'icon.png') });
    n.on('click', () => undoRename());
    n.show();
    pushRecent({ src: done[0].from, out: done[0].to, n: done.length, label: 'Renombrar', kind: kindFromExt(path.extname(done[0].to)) || 'image' });
  } catch (err) {
    logError('renombrar', err);
    notify('No se pudo renombrar', `${String(err.message || err).slice(0, 160)}\nNo se cambió nada.`);
  }
}
async function undoRename() {
  if (!lastRename) return;
  const back = lastRename.map((d) => ({ from: d.to, to: d.from }));
  lastRename = null; refreshTray();
  try { await renameBatch(back); notify('Deshecho', `Volvieron ${back.length} ${back.length === 1 ? 'archivo' : 'archivos'} a su nombre de antes.`); }
  catch (err) { logError('deshacer renombrar', err); notify('No se pudo deshacer', String(err.message || err).slice(0, 160)); }
}

ipcMain.on('drop', (_e, job) => {
  hideOverlay();
  handleDrop(job);
});
ipcMain.on('overlay-cancel', () => hideOverlay());
ipcMain.handle('catalog', () => catalog);
ipcMain.handle('design', () => designInfo());
// estimación de tamaño para el diálogo de Comprimir
ipcMain.handle('compress-estimate', async (_e, file, opts) => {
  try {
    const kind = kindFromExt(path.extname(file));
    if (kind === 'video') return await require('./av').estimateVideoCompress(file, opts);
    return await ops.estimateCompress(file, opts);
  } catch (err) { return { error: String(err.message || err) }; }
});
ipcMain.handle('detect-faces', async (_e, file) => {
  try { return { faces: await ops.detectFaces(file) }; } catch (err) { console.error(err); return { error: String(err.message || err) }; }
});

// ---------- bandeja ----------
function buildMenu() {
  const login = loginOn();
  return Menu.buildFromTemplate([
    { label: settings.paused ? 'MIXTAPE (pausada)' : 'MIXTAPE — activa', enabled: false },
    { label: 'Abrir MIXTAPE', click: () => openHub() },
    ...(updater.info().ready ? [{ label: `⟳ Reiniciar para usar la ${updater.info().ready}`, click: () => updater.restart() }]
      : updater.available() && !updater.info().installing ? [{ label: `⬇ Bajar MIXTAPE ${updater.available().version} (nueva)`, click: () => updater.open() }] : []),
    ...(lastRename ? [{ label: `Deshacer el último renombrado (${lastRename.length})`, click: () => undoRename() }] : []),
    { type: 'separator' },
    { label: 'Pausar', type: 'checkbox', checked: settings.paused, click: (i) => { settings.paused = i.checked; watcher.enabled = !i.checked; saveSettings(); refreshTray(); } },
    { label: 'Tecla para abrir la rueda', submenu: (MAC ? [['shift', 'Shift'], ['alt', 'Option (⌥)'], ['ctrlshift', 'Control + Shift']] : [['shift', 'Shift'], ['alt', 'Alt'], ['ctrlshift', 'Ctrl + Shift']]).map(([k, l]) => ({
      label: l, type: 'radio', checked: settings.key === k, click: () => { settings.key = k; watcher.key = k; saveSettings(); refreshTray(); },
    })) },
    ...(MAC ? [] : [{ label: 'Funcionar desde cualquier programa', type: 'checkbox', checked: settings.anyApp, click: (i) => { settings.anyApp = i.checked; watcher.anyApp = i.checked; saveSettings(); } }]),
    { label: MAC ? 'Abrir al iniciar la Mac' : 'Iniciar con Windows', type: 'checkbox', checked: login, click: (i) => { setLogin(i.checked); refreshTray(); } },
    { type: 'separator' },
    { label: MAC ? 'Descargar de un link…   (⌘⌥D)' : 'Descargar de un link…   (Ctrl+Alt+D)', click: () => openDownloader() },
    ...(MAC ? [{ label: 'Efecto vidrio (permiso)…', click: () => macPermissions(true) }, { label: 'Instalar paquete (Orquesta / MIDI Pro)…', click: () => installPack() }, { label: 'Diagnóstico…', click: () => macDiagnose() }] : []),
    { type: 'separator' },
    { label: 'Volver a probar la placa de video', click: () => { require('./gpu').resetGpu(); notify('Listo', 'La próxima vez que uses IA se vuelve a probar la placa de video.'); } },
    { label: 'Cómo se usa', click: showHelp },
    ...(updater.info().enabled ? [{ label: `Buscar actualizaciones (tenés la ${updater.current()})`, click: () => updater.check({ manual: true }) }] : []),
    { label: 'Salir', click: () => app.exit(0) },
  ]);
}
function refreshTray() { tray.setContextMenu(buildMenu()); hubSend('hub-settings', hubSettings()); }

function showHelp() {
  dialog.showMessageBox({
    type: 'info', title: 'MIXTAPE', icon: nativeImage.createFromPath(path.join(ASSETS, 'icon.png')),
    message: 'Arrastrá un archivo y apretá Shift',
    detail: [
      `1. Agarrá un archivo desde ${MAC ? 'el Finder' : 'el Explorador'} o el escritorio.`,
      '2. Sin soltarlo, apretá Shift: aparece el carrusel.',
      '3. Arriba están las herramientas: moviendo el mouse a los costados pasás de una a otra.',
      '   Abajo están los formatos para convertir. Soltá sobre lo que quieras.',
      '',
      'El archivo nuevo queda al lado del original. El original no se toca.',
      'Soltar sobre el nombre del archivo (al medio), o apretar Esc, cancela.',
      '',
      'Imágenes: JPG, PNG, WEBP, AVIF, GIF, TIFF, BMP → cualquiera de esos, PDF o ICO.',
      'PDF: a PNG/JPG/WEBP (una imagen por página) o TXT; unir, separar, rotar, quitar metadata.',
      'Si arrastrás varias imágenes juntas al PDF, te arma un solo PDF.',
    ].join('\n'),
  });
}

// ---------- permisos de Mac ----------
// "Monitoreo de entrada": para leer el Shift mientras arrastrás. "Grabación de pantalla": para el vidrio
// (sin ese permiso la rueda funciona igual, con un fondo liso en vez del desenfoque).
// Mac: copia la carpeta "orquesta" o "midi-pro" a ~/Library/Application Support/MIXTAPE
async function installPack() {
  const fs = require('fs'), path = require('path');
  const { MAC_DATA } = require('./bins');
  const r = await dialog.showOpenDialog({ title: 'Elegí la carpeta "orquesta" o "midi-pro"', buttonLabel: 'Instalar', properties: ['openDirectory'] });
  if (r.canceled || !r.filePaths[0]) return;
  const src = r.filePaths[0];
  const kind = fs.existsSync(path.join(src, 'trunk.onnx')) ? 'orquesta'
    : (fs.existsSync(path.join(src, 'piano', 'piano-main.onnx')) || fs.existsSync(path.join(src, 'voz', 'encoder.onnx'))) ? 'midi-pro' : null;
  if (!kind) { dialog.showMessageBox({ type: 'warning', message: 'Esa carpeta no es un paquete de MIXTAPE', detail: 'Elegí la carpeta "orquesta" (o "midi-pro") que sale al descomprimir el .zip.' }); return; }
  const dest = path.join(MAC_DATA, kind);
  try {
    await fs.promises.mkdir(MAC_DATA, { recursive: true });
    await fs.promises.rm(dest + '.tmp', { recursive: true, force: true });
    await fs.promises.cp(src, dest + '.tmp', { recursive: true });
    await fs.promises.rm(dest, { recursive: true, force: true });
    await fs.promises.rename(dest + '.tmp', dest);
    dialog.showMessageBox({ type: 'info', message: kind === 'orquesta' ? 'Paquete Orquesta instalado' : 'Paquete MIDI Pro instalado', detail: 'Ya podés borrar la carpeta que descomprimiste.' });
  } catch (e) { dialog.showMessageBox({ type: 'error', message: 'No se pudo instalar el paquete', detail: String(e.message || e) }); }
}

// Mac: prueba de 8 segundos para ver dónde se corta (mouse, tecla, ventana, arrastre)
async function macDiagnose() {
  const os = require('os');
  const { systemPreferences } = require('electron');
  const d = { ticks: 0, btn: 0, shift: 0, opt: 0, ctrl: 0, both: 0, shown: 0, visible: 0, active: 0, ev: {}, err: '' };
  let input = '?', screenSt = '?';
  try { input = watcher.CGPreflightListenEventAccess ? String(watcher.CGPreflightListenEventAccess()) : 'sin función'; } catch (e) { input = 'error: ' + e.message; }
  try { screenSt = systemPreferences.getMediaAccessStatus('screen'); } catch {}
  const r0 = await dialog.showMessageBox({ type: 'info', message: 'Prueba de MIXTAPE (8 segundos)', detail: 'Tocá "Empezar" y en esos 8 segundos agarrá un archivo del Finder, movelo un poco sin soltar y apretá Shift. Si aparece un recuadro rosa, pasá el archivo por adentro. Al final te muestro el resultado.', buttons: ['Empezar', 'Cancelar'], defaultId: 0, cancelId: 1 });
  if (r0.response !== 0) return;
  diag = d;
  overlay.webContents.send('diag', true);
  const t = setInterval(() => {
    d.ticks++;
    try {
      const b = watcher.isDown(0x01), sh = watcher.isDown(0x10);
      if (b) d.btn++; if (sh) d.shift++; if (watcher.isDown(0x12)) d.opt++; if (watcher.isDown(0x11)) d.ctrl++; if (b && sh) d.both++;
    } catch (e) { d.err = e.message; }
  }, 30);
  await new Promise((res) => setTimeout(res, 8000));
  clearInterval(t); diag = null;
  overlay.webContents.send('diag', false);
  const txt = [
    `macOS ${process.getSystemVersion ? process.getSystemVersion() : os.release()} · ${process.arch}${app.runningUnderARM64Translation ? ' (Rosetta)' : ''} · MIXTAPE ${updater.current()}`,
    `Vigía: ${watcherError ? 'ERROR ' + watcherError.message : watcher.timer ? 'andando' : 'parado'} · pausada: ${!!settings.paused} · tecla: ${settings.key || 'shift'}`,
    `Monitoreo de entrada: ${input} · Grabación de pantalla: ${screenSt}`,
    `Mouse apretado: ${d.btn} · Shift: ${d.shift} · Option: ${d.opt} · Control: ${d.ctrl} · mouse+Shift: ${d.both} (de ${d.ticks})`,
    `Carrusel mostrado: ${d.shown} · visible: ${d.visible} · Arrastre recibido: ${d.active}${d.err ? ' · error: ' + d.err : ''}`,
    `Eventos en la ventana: ${Object.entries(d.ev).map(([k, v]) => k + ' ' + v).join(', ') || 'ninguno'}`,
  ].join('\n');
  try { clipboard.writeText(txt); } catch {}
  dialog.showMessageBox({ type: 'info', message: 'Resultado (ya quedó copiado)', detail: txt + '\n\nMandale una foto o pegá esto en el chat.' });
}

async function macPermissions(explain) {
  if (!MAC) return;
  const { systemPreferences } = require('electron');
  const input = true; // mouse y teclas se leen sin el permiso de Monitoreo de entrada
  let screenOk = true;
  try { screenOk = systemPreferences.getMediaAccessStatus('screen') === 'granted'; } catch {}
  if (input && screenOk) { if (explain) notify('Permisos listos', 'MIXTAPE ya tiene todo lo que necesita.'); return; }
  if (!explain) return;
  const r = await dialog.showMessageBox({
    type: 'info', title: 'MIXTAPE', icon: nativeImage.createFromPath(path.join(ASSETS, 'icon.png')),
    message: 'Un permiso opcional',
    detail: [
      'Grabación de pantalla: solo para el efecto vidrio detrás del carrusel (no se graba ni se guarda nada).',
      'Sin este permiso MIXTAPE funciona igual, con un fondo liso.',
      '',
      'Para activarlo: Configuración del Sistema → Privacidad y seguridad → Grabación de pantalla → MIXTAPE, y volvé a abrirla.',
    ].join('\n'),
    buttons: ['Abrir Configuración', 'Ahora no'], defaultId: 1, cancelId: 1,
  });
  // pedir la captura una vez hace que la Mac agregue a MIXTAPE a la lista de Grabación de pantalla
  if (!screenOk) { try { await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 16, height: 16 } }); } catch {} }
  if (r.response === 0) {
    const pane = !input ? 'Privacy_ListenEvent' : 'Privacy_ScreenCapture';
    shell.openExternal(`x-apple.systempreferences:com.apple.preference.security?${pane}`);
  }
}


// ---------- inicio con la compu ----------
// En Windows el acceso de inicio lleva "--login": así sabemos que no hay que abrir el hub.
const LOGIN_ARGS = MAC ? undefined : { args: ['--login'] };
const loginOn = () => app.getLoginItemSettings(LOGIN_ARGS).openAtLogin;
function setLogin(on) {
  if (!MAC) app.setLoginItemSettings({ openAtLogin: false }); // saca el viejo (sin --login)
  app.setLoginItemSettings({ openAtLogin: on, ...(LOGIN_ARGS || {}) });
}
function migrateLogin() {
  if (MAC || !app.isPackaged) return;
  try { if (app.getLoginItemSettings().openAtLogin && !loginOn()) setLogin(true); } catch {}
  // si el inicio con Windows apuntaba a Ruedita.exe (antes del cambio de nombre), pasarlo a MIXTAPE.exe
  if (settings.loginMoved) return;
  settings.loginMoved = true; saveSettings();
  try {
    require('child_process').execFile('reg', ['query', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run', '/v', 'com.santibrons.ruedita'], { windowsHide: true }, (err, out) => {
      if (!err && /Ruedita\.exe/i.test(String(out)) && !loginOn()) setLogin(true);
    });
  } catch {}
}

// ---------- recientes ----------
const recentsPath = () => path.join(app.getPath('userData'), 'recientes.json');
let recents = null;
function loadRecents() {
  if (recents) return recents;
  try { recents = JSON.parse(fs.readFileSync(recentsPath(), 'utf8')); } catch { recents = []; }
  if (!Array.isArray(recents)) recents = [];
  return recents;
}
function pushRecent(r) {
  loadRecents().unshift({ ...r, at: Date.now() });
  recents = recents.slice(0, 40);
  try { fs.writeFileSync(recentsPath(), JSON.stringify(recents)); } catch {}
  hubSend('hub-recents', recents);
}

// ---------- hub: la ventana que se abre al abrir MIXTAPE ----------
let hubWin = null;
const HUB_BG = '#e6e9ee';
function hubSend(ch, data) { if (hubWin && !hubWin.isDestroyed()) hubWin.webContents.send(ch, data); }
function openHub() {
  if (hubWin && !hubWin.isDestroyed()) { if (hubWin.isMinimized()) hubWin.restore(); hubWin.show(); hubWin.focus(); return; }
  hubWin = new BrowserWindow({
    width: 1120, height: 740, minWidth: 760, minHeight: 500, title: 'MIXTAPE', autoHideMenuBar: true, show: false,
    backgroundColor: HUB_BG, icon: path.join(ASSETS, 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js') },
  });
  hubWin.once('ready-to-show', () => { hubWin.show(); hubWin.focus(); });
  hubWin.on('closed', () => { hubWin = null; });
  hubWin.loadFile(path.join(__dirname, 'hub', 'index.html'));
}
const hubSettings = () => ({ design: 'living', paused: !!settings.paused, key: settings.key || 'shift', login: loginOn(), anyApp: !!settings.anyApp, mac: MAC, dlDir: dlDir(), inicio: Array.isArray(settings.inicio) ? settings.inicio : null });
function packsStatus() {
  let orq = [], piano = false, voice = false;
  try { orq = require('./stems').orqAvailable(); } catch {}
  try { const m = require('./midi/paths'); piano = m.hasPiano(); voice = m.hasVoice(); } catch {}
  let transcribir = false, trDest = '', trWhere = '';
  try { const t = require('./transcribe'); transcribir = t.available(); trDest = t.installDir(); trWhere = t.modelDir() || ''; } catch {}
  return { orquesta: orq.length > 0, midiPro: piano || voice, piano, voice, transcribir, trDest, trWhere, mac: MAC };
}
const EXTS = { image: IMAGE_EXTS, pdf: PDF_EXTS, audio: AUDIO_EXTS, video: VIDEO_EXTS };
function kindOfPaths(paths) {
  const kinds = paths.map((f) => kindFromExt(path.extname(f)));
  if (kinds.includes('video') && kinds.includes('audio')) return 'mix';
  if (kinds.includes('pdf') && kinds.includes('image')) return 'docs';
  return kinds.find(Boolean) || (paths.length ? 'other' : null);
}
ipcMain.handle('hub-init', () => ({ settings: hubSettings(), recents: loadRecents(), packs: packsStatus(), catalog, update: updater.info() }));
ipcMain.handle('hub-update-open', () => (updater.info().ready ? updater.restart() : updater.open()));
ipcMain.handle('hub-kind', (_e, paths) => ({ kind: kindOfPaths(paths || []), count: (paths || []).length, names: (paths || []).map((f) => path.basename(f)) }));
ipcMain.handle('hub-pick', async (e, { kinds, multi, title }) => {
  const ks = kinds && kinds.length ? kinds : Object.keys(EXTS);
  const NAMES = { image: 'Imágenes', audio: 'Audio', video: 'Video', pdf: 'PDF' };
  const all = [...new Set(ks.flatMap((k) => EXTS[k] || []))];
  const filters = [{ name: ks.map((k) => NAMES[k]).join(', '), extensions: all }, ...(ks.length > 1 ? ks.map((k) => ({ name: NAMES[k], extensions: EXTS[k] })) : [])];
  if (!kinds || !kinds.length) filters.push({ name: 'Todos los archivos', extensions: ['*'] });
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: title || 'Elegí un archivo', properties: ['openFile', ...(multi ? ['multiSelections'] : [])], filters });
  return r.canceled ? [] : r.filePaths;
});
ipcMain.on('hub-run', (_e, job) => { handleDrop(job).catch((err) => logError('hub-run', err)); });
ipcMain.on('hub-link', (_e, { url, id }) => { if (url) handleLink(url, id || 'dl_mp3'); });
ipcMain.on('hub-downloader', (_e, url) => openDownloader(url || undefined));
ipcMain.on('hub-open-dl', () => { try { fs.mkdirSync(dlDir(), { recursive: true }); } catch {} shell.openPath(dlDir()); });
ipcMain.handle('hub-reveal', (_e, f) => { if (f && fs.existsSync(f)) { shell.showItemInFolder(f); return true; } return false; });
ipcMain.on('hub-help', () => showHelp());
ipcMain.on('hub-install-pack', () => { if (MAC) installPack(); else shell.openPath(path.dirname(process.execPath)); });
ipcMain.handle('hub-clear-recents', () => { recents = []; try { fs.writeFileSync(recentsPath(), '[]'); } catch {} return []; });
ipcMain.handle('hub-set', (_e, ch) => {
  if ('paused' in ch) { settings.paused = !!ch.paused; watcher.enabled = !settings.paused; }
  if ('key' in ch) { settings.key = ch.key; watcher.key = ch.key; }
  if ('anyApp' in ch) { settings.anyApp = !!ch.anyApp; watcher.anyApp = settings.anyApp; }
  if ('login' in ch) setLogin(!!ch.login);
  if ('inicio' in ch) settings.inicio = Array.isArray(ch.inicio) ? [...new Set(ch.inicio.filter((x) => typeof x === 'string' && x.length < 80))].slice(0, 40) : null;
  saveSettings(); refreshTray();
  return hubSettings();
});
ipcMain.handle('hub-dl-dir', async (e) => {
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { properties: ['openDirectory', 'createDirectory'], defaultPath: dlDir() });
  if (!r.canceled && r.filePaths[0]) { settings.dlDir = r.filePaths[0]; saveSettings(); }
  return hubSettings();
});

// ---------- paquete Transcribir: se baja desde la app (en un hilo aparte) ----------
let trInstall = null;
function installTranscribe(onProgress) {
  if (trInstall) { trInstall.listeners.push(onProgress); return trInstall.promise; }
  const { Worker } = require('worker_threads');
  const dest = require('./transcribe').installDir();
  const job = startJob('Bajando el paquete Transcribir', '560 MB · una sola vez');
  setBusy(1);
  const listeners = [onProgress];
  const promise = new Promise((resolve) => {
    const w = new Worker(path.join(__dirname, 'packs-worker.js'), { workerData: { dest } });
    w.on('message', (m) => {
      if (m.p != null) { job.progress(m.p); listeners.forEach((f) => f && f(m.p)); hubSend('hub-install-progress', m.p); }
      if (m.done) { job.end(true); notify('Paquete Transcribir instalado ✓', 'Ya podés pasar audios y videos a texto.'); resolve({ ok: true }); }
      if (m.error) { job.end(false); logError('instalar transcribir', m.error); resolve({ ok: false, error: m.error }); }
    });
    w.on('error', (e) => { job.end(false); logError('instalar transcribir', e); resolve({ ok: false, error: String(e.message || e) }); });
  }).finally(() => { setBusy(-1); trInstall = null; hubSend('hub-packs', packsStatus()); });
  trInstall = { promise, listeners };
  return promise;
}
function trInfo() {
  const t = require('./transcribe');
  return { available: t.available(), dest: t.installDir(), where: t.modelDir() };
}
// elegir dónde se guarda el paquete (adentro de la carpeta elegida se crea "MIXTAPE - Transcribir")
ipcMain.handle('transcribe-pick-dir', async (e) => {
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: 'Dónde guardar el paquete Transcribir (560 MB)', buttonLabel: 'Guardar acá', properties: ['openDirectory', 'createDirectory'] });
  if (!r.canceled && r.filePaths[0]) {
    settings.trDir = path.join(r.filePaths[0], 'MIXTAPE - Transcribir');
    saveSettings();
    require('./transcribe').setPackDir(settings.trDir);
  }
  return trInfo();
});
ipcMain.handle('pick-folder', async (e, { title, defaultPath } = {}) => {
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: title || 'Elegí una carpeta', buttonLabel: 'Elegir', defaultPath, properties: ['openDirectory', 'createDirectory'] });
  return r.canceled || !r.filePaths[0] ? null : r.filePaths[0];
});
ipcMain.on('open-folder', (_e, d) => { if (d) shell.openPath(d); });
ipcMain.handle('transcribe-info', () => trInfo());
ipcMain.handle('transcribe-install', (e) => installTranscribe((p) => { if (!e.sender.isDestroyed()) e.sender.send('transcribe-install-progress', p); }));
ipcMain.handle('hub-install-transcribe', () => installTranscribe(null));

// ---------- arranque ----------
app.whenReady().then(() => {
  loadSettings();
  try { require('./transcribe').setPackDir(settings.trDir); } catch {}
  createOverlay();
  createWorker();
  setTimeout(ensureProgWin, 1500); // la ventanita de progreso queda cargada (oculta) para aparecer al toque

  if (MAC) {
    app.dock?.hide();
    // menú de la app (sin él no andan ⌘C / ⌘V en los campos de texto de las ventanas)
    Menu.setApplicationMenu(Menu.buildFromTemplate([{ role: 'appMenu' }, { role: 'editMenu' }, { role: 'windowMenu' }]));
  }
  const trayImg = nativeImage.createFromPath(path.join(ASSETS, MAC ? 'trayTemplate.png' : 'tray.png'));
  if (MAC) trayImg.setTemplateImage(true);
  tray = new Tray(trayImg);
  setBusy(0);
  refreshTray();
  // Windows: clic = abrir el hub, clic derecho = menú. Mac: el menú (con "Abrir MIXTAPE" arriba).
  tray.on('click', () => (MAC ? tray.popUpContextMenu() : openHub()));

  try { watcher = new DragWatcher(); } catch (e) {
    watcherError = e; logError('watcher', e);
    watcher = new (require('events').EventEmitter)(); watcher.start = () => {};
  }
  watcher.anyApp = settings.anyApp;
  watcher.key = settings.key || 'shift';
  watcher.enabled = !settings.paused;
  watcher.on('trigger', showOverlay);
  watcher.on('release', () => { hideTimer = setTimeout(hideOverlay, 600); });
  watcher.on('cancel', hideOverlay);
  watcher.on('guard-failed', (why) => logError('bloqueo de Shift', new Error(`no arrancó (${why})`)));
  watcher.start();
  // atajo global para el descargador (agarra el link que tengas copiado)
  try { globalShortcut.register('CommandOrControl+Alt+D', () => openDownloader()); } catch {}
  // precarga la IA de caras en segundo plano para que "Blurear" encuentre las caras al instante
  setTimeout(() => { try { require('./ai').warmUp(); } catch (e) { console.error(e); } }, 4000);

  migrateLogin();
  updater.start({
    icon: path.join(ASSETS, 'icon.png'),
    settings: () => settings,
    save: (ch) => { Object.assign(settings, ch); saveSettings(); },
    onChange: () => { refreshTray(); hubSend('hub-update', updater.info()); },
  });
  const atLogin = process.argv.includes('--login') || (MAC && app.getLoginItemSettings().wasOpenedAtLogin);
  if (!atLogin && !process.env.RUEDITA_TEST) setTimeout(openHub, 600);
  if (settings.firstRun) {
    settings.firstRun = false;
    saveSettings();
    if (app.isPackaged) setLogin(true);
    refreshTray();
    notify('MIXTAPE está activa', MAC ? 'Arrastrá un archivo y apretá Shift. La encontrás arriba, en la barra de menú.' : 'Arrastrá una imagen o un PDF y apretá Shift. La encontrás al lado del reloj.');
    if (MAC) setTimeout(() => macPermissions(true), 800);
  } else if (MAC) setTimeout(() => macPermissions(false), 1500);

  // modo prueba en Linux/Mac: muestra la rueda en el centro de la pantalla
  if (process.env.RUEDITA_DEMO) showOverlay();
  if (process.env.RUEDITA_TEST) require(process.env.RUEDITA_TEST)({ undoRename, overlay, worker, pdfCtx, openEditor, ops, showOverlay, handleDrop, openDownloader, openHub, pushRecent });
});

app.on('second-instance', () => openHub());
app.on('window-all-closed', (e) => e.preventDefault());
app.on('will-quit', () => { try { globalShortcut.unregisterAll(); } catch {} try { watcher?.stopGuard?.(); } catch {} });
