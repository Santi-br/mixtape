const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('ruedita', {
  pathFor: (file) => webUtils.getPathForFile(file),
  invoke: (ch, ...args) => ipcRenderer.invoke(ch, ...args),
  send: (ch, ...args) => ipcRenderer.send(ch, ...args),
  on: (ch, fn) => ipcRenderer.on(ch, (_e, ...args) => fn(...args)),
});
