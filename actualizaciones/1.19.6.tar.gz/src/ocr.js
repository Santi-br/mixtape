// Foto a texto (OCR) sin internet: Tesseract (tesseract.js, WASM) con español + inglés.
// Antes de leer, la foto se endereza (EXIF), se pasa a gris, se lleva a ~2200 px y se le saca la luz despareja
// (se divide por una versión muy borroneada de sí misma), así las fotos con sombra no quedan en negro.
const path = require('path');
const sharp = require('sharp');

const LANG_DIR = path.join(__dirname, '..', 'models', 'ocr');
let workerP = null;

function getWorker() {
  if (!workerP) {
    const { createWorker } = require('tesseract.js');
    workerP = createWorker(['spa', 'eng'], 1, { langPath: LANG_DIR, gzip: true, cacheMethod: 'none' })
      .then(async (w) => { await w.setParameters({ user_defined_dpi: '300' }); return w; })
      .catch((err) => { workerP = null; throw err; });
  }
  return workerP;
}

async function prepare(file) {
  const img = sharp(file, { failOn: 'none' }).rotate();
  const m = await img.metadata();
  const w0 = m.autoOrient?.width || m.width, h0 = m.autoOrient?.height || m.height;
  const long = Math.max(w0, h0);
  const target = long < 1600 ? Math.min(2400, long * 2) : Math.min(long, 2600);
  const scale = target / long;
  const W = Math.round(w0 * scale), H = Math.round(h0 * scale);
  const grey = await img.resize(W, H, { kernel: 'lanczos3' }).flatten({ background: '#ffffff' }).greyscale().raw().toBuffer();
  const bg = await sharp(grey, { raw: { width: W, height: H, channels: 1 } }).blur(Math.max(12, Math.round(Math.min(W, H) / 40))).raw().toBuffer();
  const out = Buffer.alloc(grey.length);
  for (let i = 0; i < grey.length; i++) {
    const v = (grey[i] / Math.max(1, bg[i])) * 255;
    out[i] = v > 255 ? 255 : v;
  }
  return sharp(out, { raw: { width: W, height: H, channels: 1 } }).normalise({ lower: 1, upper: 99 }).png().toBuffer();
}

// devuelve { text, confidence (0-100), words }
async function recognize(file, { onProgress } = {}) {
  onProgress?.(0.05);
  const png = await prepare(file);
  onProgress?.(0.2);
  const w = await getWorker();
  onProgress?.(0.35);
  const { data } = await w.recognize(png);
  onProgress?.(1);
  const text = tidy(data.text || '');
  return { text, confidence: Math.round(data.confidence || 0), words: text ? text.split(/\s+/).length : 0 };
}

// limpia lo que devuelve Tesseract: une palabras cortadas con guion al final de renglón, saca basura suelta
function tidy(t) {
  return t
    .replace(/\r/g, '')
    .replace(/([\p{L}])-\n([\p{Ll}])/gu, '$1$2')
    .split('\n').map((l) => l.replace(/[ \t]+/g, ' ').trim().replace(/^[|¦]\s+/, '').replace(/\s+[|¦]$/, ''))
    .filter((l) => !/^[^\p{L}\p{N}]{1,3}$/u.test(l))
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

async function close() { if (workerP) { const w = await workerP.catch(() => null); workerP = null; await w?.terminate(); } }

module.exports = { recognize, close, prepare };
