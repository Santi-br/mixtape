// Descargador de links (YouTube, Shorts, Instagram, TikTok, X, Facebook, SoundCloud… ) con yt-dlp.
// Gratis, sin anuncios. Usa el FFmpeg de la app para unir video+audio y pasar a MP3/WAV.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const BIN_DIR = path.join(__dirname, '..', 'bin');
const YTDLP = require('./bins').YTDLP;
const FFMPEG = require('./bins').FFMPEG;

function run(args, { onLine } = {}) {
  return new Promise((resolve, reject) => {
    const env = { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' };
    const extra = process.env.RUEDITA_YTDLP_EXTRA ? process.env.RUEDITA_YTDLP_EXTRA.split(' ') : []; // solo para pruebas
    const p = spawn(YTDLP, [...extra, ...args], { windowsHide: true, env });
    let err = '', buf = '';
    const feed = (d) => {
      buf += d.toString('utf8');
      let i;
      while ((i = buf.search(/[\r\n]/)) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (line) onLine?.(line);
      }
    };
    p.stdout.on('data', feed);
    p.stderr.on('data', (d) => { err = (err + d).slice(-8000); feed(d); });
    p.on('error', reject);
    p.on('close', (code) => {
      if (code === 0) return resolve();
      const msg = err.split(/\r?\n/).reverse().find((l) => /ERROR/.test(l)) || err.trim().split(/\r?\n/).pop() || `código ${code}`;
      reject(new Error(friendly(msg.replace(/^.*?ERROR:\s*/, ''))));
    });
  });
}

function friendly(m) {
  if (/private|login|sign in|cookies/i.test(m)) return 'Ese contenido es privado o pide iniciar sesión. Probá con "Usar mi sesión de…" en Opciones.';
  if (/Unsupported URL/i.test(m)) return 'Ese link no es compatible (o no es un video/audio).';
  if (/Unable to download webpage|getaddrinfo|timed out|Connection/i.test(m)) return 'No hay conexión o la página no respondió.';
  if (/Video unavailable|removed|not available/i.test(m)) return 'Ese video no está disponible (borrado, privado o bloqueado en tu país).';
  return m.slice(0, 220);
}

let updatedThisSession = false;
async function selfUpdate() {
  if (updatedThisSession) return false;
  updatedThisSession = true;
  try { await run(['-U']); return true; } catch { return false; }
}

// Mira qué hay en el link sin bajarlo: un video/canción o una playlist/álbum (con su lista).
async function probe(url, { cookies } = {}) {
  let json = '';
  const args = ['--flat-playlist', '-J', '--no-warnings', '--yes-playlist', '--encoding', 'utf-8'];
  if (cookies) args.push('--cookies-from-browser', cookies);
  await new Promise((resolve, reject) => {
    const env = { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' };
    const extra = process.env.RUEDITA_YTDLP_EXTRA ? process.env.RUEDITA_YTDLP_EXTRA.split(' ') : [];
    const p = spawn(YTDLP, [...extra, ...args, url], { windowsHide: true, env });
    let err = '';
    p.stdout.on('data', (d) => { json += d.toString('utf8'); });
    p.stderr.on('data', (d) => { err += d; });
    p.on('error', reject);
    p.on('close', (code) => code === 0 ? resolve() : reject(new Error(friendly((err.split(/\r?\n/).find((l) => /ERROR/.test(l)) || err).replace(/^.*?ERROR:\s*/, '')))));
  });
  const info = JSON.parse(json);
  if (info._type === 'playlist' && Array.isArray(info.entries)) {
    return {
      playlist: true, title: info.title || 'Playlist', uploader: info.uploader || info.channel || '',
      entries: info.entries.map((e, i) => ({ index: i + 1, title: e.title || e.id || `Pista ${i + 1}`, duration: e.duration || 0 })),
    };
  }
  return { playlist: false, title: info.title || '', uploader: info.uploader || info.artist || info.channel || '', duration: info.duration || 0 };
}

// opts: {
//   format: 'mp4' | 'mp3' | 'm4a' | 'opus' | 'flac' | 'wav'   (compat: mode 'video'|'mp3'|'wav')
//   quality: video 'best'|'2160'|'1440'|'1080'|'720'|'480'|'360'   ·   mp3 '320'|'256'|'192'|'128'
//   cookies: ''|'chrome'|'edge'|'firefox', dir, playlist: bool, items: [1,3,5] (de la playlist)
// }
async function download(url, opts = {}, { onProgress, onTitle } = {}) {
  const format = opts.format || (opts.mode === 'video' || !opts.mode ? 'mp4' : opts.mode);
  const dir = opts.dir;
  fs.mkdirSync(dir, { recursive: true });
  const isList = !!opts.playlist;
  const tpl = isList
    ? path.join(dir, '%(playlist_title,playlist|Playlist).120B', '%(playlist_index)03d - %(title).150B.%(ext)s')
    : path.join(dir, '%(title).150B [%(id)s].%(ext)s');
  const args = [
    '--ffmpeg-location', FFMPEG,
    '--newline', '--progress', '--no-color', '--encoding', 'utf-8',
    '--progress-template', 'download:RPROG %(progress._percent_str)s',
    '--print', 'before_dl:RTITLE %(title)s',
    '--print', 'after_move:RFILE %(filepath)s',
    '-o', tpl,
    '--embed-metadata',
    '--ignore-errors', // en playlists, si una canción falla (borrada/privada) sigue con las demás
    isList ? '--yes-playlist' : '--no-playlist',
  ];
  if (isList && opts.items?.length) args.push('--playlist-items', opts.items.join(','));
  if (process.platform === 'win32') args.push('--windows-filenames');
  if (opts.cookies) args.push('--cookies-from-browser', opts.cookies);

  if (format === 'mp4') {
    const h = { '2160': 2160, '1440': 1440, '1080': 1080, '720': 720, '480': 480, '360': 360 }[opts.quality];
    // prioriza MP4 (H.264 + AAC) para que se abra en cualquier lado
    args.push('-S', `${h ? `res:${h},` : ''}vcodec:h264,acodec:aac,ext:mp4:m4a`, '--merge-output-format', 'mp4', '--embed-thumbnail');
  } else {
    args.push('-f', 'bestaudio/best', '-x');
    if (format === 'mp3') args.push('--audio-format', 'mp3', '--audio-quality', `${opts.quality && opts.quality !== 'best' ? opts.quality : '320'}K`);
    else if (format === 'm4a') args.push('--audio-format', 'm4a', '--audio-quality', '0');
    else if (format === 'opus') args.push('--audio-format', 'opus', '--audio-quality', '0');
    else args.push('--audio-format', format); // flac / wav
    if (format !== 'wav') args.push('--embed-thumbnail', '--convert-thumbnails', 'jpg');
  }

  args.push('-N', '8'); // baja varios pedazos a la vez (más rápido)
  args.push(url);

  const total = isList ? (opts.items?.length || opts.total || 0) : 1;
  const files = [];
  // una corrida de yt-dlp (con su propio contador)
  const runOnce = (extraArgs, report) => {
    let n = 0;
    return run([...extraArgs, ...args], {
      onLine: (line) => {
        if (line.startsWith('RTITLE ')) { n++; report.title(line.slice(7)); return; }
        if (line.startsWith('RFILE ')) { files.push(line.slice(6)); report.done(); return; }
        const m = /RPROG\s+([\d.]+)%/.exec(line);
        if (m) report.prog(parseFloat(m[1]) / 100);
      },
    });
  };

  // playlists: 3 descargas en paralelo, repartiendo los temas
  const itemList = isList ? (opts.items?.length ? opts.items : Array.from({ length: total }, (_, i) => i + 1)) : [];
  const workers = isList && itemList.length >= 3 ? 3 : 1;
  let doneCount = 0;
  const partial = new Array(workers).fill(0);
  const emit = () => onProgress?.(Math.min(0.99, total > 1 ? (doneCount + partial.reduce((a, b) => a + b, 0)) / total : partial[0]));
  const makeReport = (w) => ({
    title: (t) => { partial[w] = 0; onTitle?.(t, Math.min(total, doneCount + 1), total); },
    prog: (p) => { partial[w] = p; emit(); },
    done: () => { doneCount++; partial[w] = 0; emit(); },
  });

  const attempt = async () => {
    if (workers === 1) {
      const extra = isList && opts.items?.length ? ['--playlist-items', opts.items.join(',')] : [];
      // (si viene --playlist-items en args ya está incluido arriba)
      await runOnce(extra.length && !args.includes('--playlist-items') ? extra : [], makeReport(0));
      return;
    }
    const groups = Array.from({ length: workers }, () => []);
    itemList.forEach((it, i) => groups[i % workers].push(it));
    const base = args.indexOf('--playlist-items');
    if (base >= 0) args.splice(base, 2); // cada worker lleva su propia lista
    const results = await Promise.allSettled(groups.map((g, w) => runOnce(['--playlist-items', g.join(',')], makeReport(w))));
    const bad = results.find((r) => r.status === 'rejected');
    if (bad && !files.length) throw bad.reason;
  };

  try {
    await attempt();
  } catch (e) {
    // con playlists, si algo se bajó, se toma como éxito parcial
    if (files.length) return files.filter((f) => fs.existsSync(f));
    // los sitios cambian seguido: si falla, se actualiza yt-dlp y se reintenta una vez
    if (await selfUpdate()) { files.length = 0; doneCount = 0; await attempt(); } else throw e;
  }
  return [...new Set(files)].filter((f) => fs.existsSync(f));
}

const isUrl = (s) => /^https?:\/\/\S+$/i.test(String(s || '').trim());

module.exports = { download, probe, isUrl, selfUpdate, YTDLP };
