// Paquetes que se bajan desde la app (una sola vez). Por ahora: Transcribir (Whisper large-v3-turbo, int8).
// Se baja el .tar.bz2 publicado por sherpa-onnx en GitHub, se descomprime al vuelo y se guardan solo los modelos.
const fs = require('fs');
const path = require('path');
const https = require('https');

const WHISPER_URL = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-turbo.tar.bz2';
const WHISPER_SIZE = 563790207;

function get(url, redirects = 6) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': 'MIXTAPE' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) {
        res.resume();
        return resolve(get(new URL(res.headers.location, url).href, redirects - 1));
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error(`La descarga falló (código ${res.statusCode})`)); }
      resolve(res);
    });
    req.on('error', (e) => reject(new Error(`No me pude conectar: ${e.message}`)));
    req.setTimeout(60000, () => req.destroy(new Error('La conexión se cortó')));
  });
}

// lector de .tar en streaming: llama onFile(name, size) → devuelve un WriteStream o null para saltearlo
function untar(onFile) {
  const { Writable } = require('stream');
  let buf = Buffer.alloc(0), state = 'header', left = 0, pad = 0, out = null;
  return new Writable({
    write(chunk, _enc, cb) {
      buf = buf.length ? Buffer.concat([buf, chunk]) : chunk;
      const step = () => {
        while (true) {
          if (state === 'header') {
            if (buf.length < 512) return cb();
            const h = buf.subarray(0, 512); buf = buf.subarray(512);
            if (h.every((b) => b === 0)) continue;
            const name = h.toString('utf8', 0, 100).replace(/\0.*$/s, '');
            const prefix = h.toString('utf8', 345, 500).replace(/\0.*$/s, '');
            const size = parseInt(h.toString('ascii', 124, 136).replace(/\0.*$/s, '').trim() || '0', 8);
            const type = String.fromCharCode(h[156] || 48);
            left = size; pad = (512 - (size % 512)) % 512;
            out = type === '0' || type === '\0' ? onFile(prefix ? `${prefix}/${name}` : name, size) : null;
            state = 'body';
          } else if (state === 'body') {
            if (left > 0) {
              if (!buf.length) return cb();
              const n = Math.min(left, buf.length);
              const part = buf.subarray(0, n); buf = buf.subarray(n); left -= n;
              if (out && !out.write(part)) { out.once('drain', step); return; }
              continue;
            }
            if (out) { out.end(); out = null; }
            state = 'pad';
          } else if (state === 'pad') {
            if (buf.length < pad) { pad -= buf.length; buf = Buffer.alloc(0); return cb(); }
            buf = buf.subarray(pad); pad = 0; state = 'header';
          }
        }
      };
      step();
    },
  });
}

// Quitar fondo: ISNet general use (DIS, Apache 2.0) en ONNX, del repo de rembg en GitHub. Se guarda tal cual.
const RMBG_SIZE = 178648008;
const RMBG_SHA = '60920e99c45464f2ba57bee2ad08c919a52bbf852739e96947fbb4358c0d964a';
async function installRmbg(dest, { onProgress } = {}) {
  const { FILE, URL } = require('./rmbg');
  fs.mkdirSync(dest, { recursive: true });
  const final = path.join(dest, FILE), part = final + '.part';
  const res = await get(URL);
  const total = Number(res.headers['content-length']) || RMBG_SIZE;
  const hash = require('crypto').createHash('sha256');
  let got = 0;
  await new Promise((resolve, reject) => {
    const out = fs.createWriteStream(part);
    res.on('data', (c) => { got += c.length; hash.update(c); onProgress?.(Math.min(0.99, got / total)); });
    res.on('error', reject); out.on('error', reject); out.on('finish', resolve);
    res.pipe(out);
  });
  if (hash.digest('hex') !== RMBG_SHA) { try { fs.unlinkSync(part); } catch {} throw new Error('El archivo bajado vino fallado, probá de nuevo'); }
  fs.renameSync(part, final);
  onProgress?.(1);
  return final;
}

let installing = null;
async function installWhisper(dest, { onProgress } = {}) {
  if (installing) return installing;
  installing = (async () => {
    const tmp = `${dest}.bajando`;
    await fs.promises.rm(tmp, { recursive: true, force: true });
    await fs.promises.mkdir(tmp, { recursive: true });
    const res = await get(WHISPER_URL);
    const total = +res.headers['content-length'] || WHISPER_SIZE;
    let got = 0;
    res.on('data', (d) => { got += d.length; onProgress?.(Math.min(0.99, got / total)); });
    const bz = require('unbzip2-stream')();
    const pending = [];
    const sink = untar((name, size) => {
      const base = path.basename(name);
      if (!/^turbo-(encoder|decoder)\.int8\.onnx$|^turbo-tokens\.txt$/.test(base)) return null;
      const ws = fs.createWriteStream(path.join(tmp, base));
      pending.push(new Promise((ok, ko) => { ws.on('finish', ok); ws.on('error', ko); }));
      return ws;
    });
    await new Promise((ok, ko) => {
      res.on('error', ko); bz.on('error', (e) => ko(new Error(`El archivo bajado está dañado (${e.message || e})`))); sink.on('error', ko);
      sink.on('finish', ok);
      res.pipe(bz).pipe(sink);
    });
    await Promise.all(pending);
    for (const f of ['turbo-encoder.int8.onnx', 'turbo-decoder.int8.onnx', 'turbo-tokens.txt']) {
      if (!fs.existsSync(path.join(tmp, f))) throw new Error('La descarga quedó incompleta. Probá de nuevo.');
    }
    await fs.promises.rm(dest, { recursive: true, force: true });
    await fs.promises.rename(tmp, dest);
    onProgress?.(1);
    return dest;
  })();
  try { return await installing; } finally { installing = null; }
}

module.exports = { installWhisper, WHISPER_SIZE, installRmbg, _test: { untar } };
