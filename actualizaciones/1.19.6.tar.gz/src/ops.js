// Todo el procesamiento de archivos. No depende de Electron (se puede probar con node).
const fs = require('fs');
const path = require('path');
const sharp = require('sharp');
const bmp = require('bmp-js');
const { PDFDocument, degrees } = require('pdf-lib');
const { kindFromExt } = require('./catalog');
let ai = null; // se carga recién cuando se usa (onnxruntime es pesado)
const getAi = () => (ai ||= require('./ai'));

sharp.cache(false);

// ---------- helpers ----------
function extOf(p) { return path.extname(p).slice(1).toLowerCase(); }
function baseOf(p) { return path.basename(p, path.extname(p)); }

function uniquePath(dir, name, ext) {
  let p = path.join(dir, `${name}.${ext}`);
  let i = 2;
  while (fs.existsSync(p)) p = path.join(dir, `${name} (${i++}).${ext}`);
  return p;
}

function uniqueDir(dir, name) {
  let p = path.join(dir, name);
  let i = 2;
  while (fs.existsSync(p)) p = path.join(dir, `${name} (${i++})`);
  fs.mkdirSync(p, { recursive: true });
  return p;
}

function normFmt(f) {
  f = String(f).toLowerCase();
  if (f === 'jpeg') return 'jpg';
  if (f === 'tif') return 'tiff';
  return f;
}

// Abre cualquier imagen soportada como pipeline de sharp (con orientación EXIF aplicada)
async function load(file) {
  if (extOf(file) === 'bmp') {
    const dec = bmp.decode(fs.readFileSync(file));
    const { width, height, data } = dec;
    const rgba = Buffer.alloc(width * height * 4);
    for (let i = 0; i < width * height; i++) {
      rgba[i * 4] = data[i * 4 + 3];
      rgba[i * 4 + 1] = data[i * 4 + 2];
      rgba[i * 4 + 2] = data[i * 4 + 1];
      rgba[i * 4 + 3] = 255;
    }
    return sharp(rgba, { raw: { width, height, channels: 4 } });
  }
  return sharp(file, { animated: false, limitInputPixels: false }).rotate();
}

function encodeBmp(rgb, width, height) {
  const rowSize = Math.ceil((width * 3) / 4) * 4;
  const size = 54 + rowSize * height;
  const b = Buffer.alloc(size);
  b.write('BM', 0);
  b.writeUInt32LE(size, 2);
  b.writeUInt32LE(54, 10);
  b.writeUInt32LE(40, 14);
  b.writeInt32LE(width, 18);
  b.writeInt32LE(height, 22);
  b.writeUInt16LE(1, 26);
  b.writeUInt16LE(24, 28);
  b.writeUInt32LE(rowSize * height, 34);
  b.writeInt32LE(2835, 38);
  b.writeInt32LE(2835, 42);
  for (let y = 0; y < height; y++) {
    const row = 54 + (height - 1 - y) * rowSize;
    for (let x = 0; x < width; x++) {
      const s = (y * width + x) * 3;
      b[row + x * 3] = rgb[s + 2];
      b[row + x * 3 + 1] = rgb[s + 1];
      b[row + x * 3 + 2] = rgb[s];
    }
  }
  return b;
}

async function encodeIco(img) {
  const sizes = [16, 32, 48, 64, 128, 256];
  const pngs = [];
  for (const s of sizes) {
    pngs.push(await img.clone().resize(s, s, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toBuffer());
  }
  const header = Buffer.alloc(6 + 16 * sizes.length);
  header.writeUInt16LE(0, 0);
  header.writeUInt16LE(1, 2);
  header.writeUInt16LE(sizes.length, 4);
  let offset = header.length;
  sizes.forEach((s, i) => {
    const e = 6 + i * 16;
    header[e] = s >= 256 ? 0 : s;
    header[e + 1] = s >= 256 ? 0 : s;
    header.writeUInt16LE(1, e + 4);
    header.writeUInt16LE(32, e + 6);
    header.writeUInt32LE(pngs[i].length, e + 8);
    header.writeUInt32LE(offset, e + 12);
    offset += pngs[i].length;
  });
  return Buffer.concat([header, ...pngs]);
}

// Escribe un pipeline de sharp al formato pedido
async function save(img, fmt, out, { quality } = {}) {
  fmt = normFmt(fmt);
  const white = { r: 255, g: 255, b: 255 };
  switch (fmt) {
    case 'jpg':
      await img.flatten({ background: white }).jpeg({ quality: quality ?? 90, mozjpeg: true }).toFile(out); break;
    case 'png':
      await img.png({ compressionLevel: 9 }).toFile(out); break;
    case 'webp':
      await img.webp({ quality: quality ?? 90 }).toFile(out); break;
    case 'avif':
      await img.avif({ quality: quality ?? 60 }).toFile(out); break;
    case 'gif':
      await img.gif().toFile(out); break;
    case 'tiff':
      await img.tiff({ compression: 'lzw' }).toFile(out); break;
    case 'bmp': {
      const { data, info } = await img.flatten({ background: white }).removeAlpha().raw().toBuffer({ resolveWithObject: true });
      fs.writeFileSync(out, encodeBmp(data, info.width, info.height)); break;
    }
    case 'ico':
      fs.writeFileSync(out, await encodeIco(img)); break;
    default:
      throw new Error(`Formato no soportado: ${fmt}`);
  }
  return out;
}

// Formato de salida "natural" para un archivo (si el original no se puede escribir igual)
function sameFmt(file) {
  const e = normFmt(extOf(file));
  return ['jpg', 'png', 'webp', 'avif', 'gif', 'tiff', 'bmp'].includes(e) ? e : 'png';
}

// ---------- imágenes ----------
async function convertImage(file, fmt) {
  fmt = normFmt(fmt);
  const out = uniquePath(path.dirname(file), baseOf(file), fmt);
  return save(await load(file), fmt, out);
}

async function imagesToPdf(files) {
  const doc = await PDFDocument.create();
  for (const f of files) {
    const e = extOf(f);
    let embedded;
    if (e === 'jpg' || e === 'jpeg') {
      // re-guardamos para aplicar la orientación EXIF
      const buf = await (await load(f)).jpeg({ quality: 92 }).toBuffer();
      embedded = await doc.embedJpg(buf);
    } else {
      const buf = await (await load(f)).png().toBuffer();
      embedded = await doc.embedPng(buf);
    }
    const w = embedded.width * 0.75, h = embedded.height * 0.75;
    const page = doc.addPage([w, h]);
    page.drawImage(embedded, { x: 0, y: 0, width: w, height: h });
  }
  doc.setProducer('MIXTAPE');
  doc.setCreator('MIXTAPE');
  const name = files.length > 1 ? `${baseOf(files[0])} (+${files.length - 1})` : baseOf(files[0]);
  const out = uniquePath(path.dirname(files[0]), name, 'pdf');
  fs.writeFileSync(out, await doc.save());
  return out;
}

// opts: { quality: 1..100, maxSide: 0 (sin cambio) | px, format: 'same'|'jpg'|'webp'|'avif' }
function compressPlan(file, opts = {}) {
  let fmt = opts.format && opts.format !== 'same' ? opts.format : sameFmt(file);
  if (fmt === 'bmp' || fmt === 'tiff' || fmt === 'gif') fmt = 'jpg';
  return { fmt, q: Math.max(1, Math.min(100, Math.round(opts.quality ?? 70))), maxSide: opts.maxSide ?? 0 };
}
async function compressImageBuffer(file, opts = {}) {
  const { fmt, q, maxSide } = compressPlan(file, opts);
  let img = await load(file);
  const meta = await img.metadata();
  if (maxSide && Math.max(meta.width || 0, meta.height || 0) > maxSide) {
    img = img.resize(maxSide, maxSide, { fit: 'inside', withoutEnlargement: true });
  }
  const white = { r: 255, g: 255, b: 255 };
  switch (fmt) {
    case 'png': return img.png({ palette: q < 100, quality: q, compressionLevel: 9, effort: 8 }).toBuffer();
    case 'webp': return img.webp({ quality: q, effort: 5 }).toBuffer();
    case 'avif': return img.avif({ quality: Math.round(q * 0.75), effort: 4 }).toBuffer();
    default: return img.flatten({ background: white }).jpeg({ quality: q, mozjpeg: true }).toBuffer();
  }
}
async function compressImage(file, opts = {}) {
  const { fmt } = compressPlan(file, opts);
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (comprimido)`, fmt);
  fs.writeFileSync(out, await compressImageBuffer(file, opts));
  return out;
}
// tamaño estimado (bytes) para mostrar en el diálogo
async function estimateCompress(file, opts) {
  const before = fs.statSync(file).size;
  const after = (await compressImageBuffer(file, opts)).length;
  return { before, after };
}

async function stripImage(file) {
  const fmt = sameFmt(file);
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (sin metadata)`, fmt);
  return save(await load(file), fmt, out, { quality: 95 });
}

// opts: { angle (grados, horario), flipH, flipV, bg: 'transparent'|'white'|'black'|'crop' }
async function rotateImage(file, opts = {}) {
  if (typeof opts === 'number') opts = { angle: opts };
  const angle = ((opts.angle ?? 90) % 360 + 360) % 360;
  const right = Math.abs(angle % 90) < 1e-6;
  let fmt = sameFmt(file);
  const bg = opts.bg || 'transparent';
  if (!right && bg === 'transparent' && (fmt === 'jpg' || fmt === 'bmp')) fmt = 'png'; // para que se vea lo transparente
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (rotada)`, fmt);
  let buf = await (await load(file)).png().toBuffer();
  if (opts.flipH || opts.flipV) {
    let p = sharp(buf);
    if (opts.flipV) p = p.flip();
    if (opts.flipH) p = p.flop();
    buf = await p.png().toBuffer();
  }
  const meta = await sharp(buf).metadata();
  const background = bg === 'white' ? '#ffffff' : bg === 'black' ? '#000000' : { r: 0, g: 0, b: 0, alpha: 0 };
  // primero el giro en pasos de 90° (sin pérdida) y después el ajuste fino
  const baseA = ((Math.round(angle / 90) * 90) % 360 + 360) % 360;
  const fine = ((angle - baseA + 540) % 360) - 180;
  if (baseA) buf = await sharp(buf).rotate(baseA).png().toBuffer();
  let rotated = Math.abs(fine) > 1e-6 ? await sharp(buf).ensureAlpha().rotate(fine, { background }).png().toBuffer() : buf;
  if (!right && bg === 'crop') {
    // recorte al rectángulo más grande (misma proporción) que entra sin bordes
    const th = (fine * Math.PI) / 180, c = Math.abs(Math.cos(th)), sn = Math.abs(Math.sin(th));
    const bm = await sharp(buf).metadata();
    const w = bm.width, h = bm.height;
    const k = Math.min(w / (w * c + h * sn), h / (w * sn + h * c));
    const rm = await sharp(rotated).metadata();
    const cw = Math.floor(w * k), ch = Math.floor(h * k);
    rotated = await sharp(rotated).extract({ left: Math.floor((rm.width - cw) / 2), top: Math.floor((rm.height - ch) / 2), width: cw, height: ch }).png().toBuffer();
  }
  return save(sharp(rotated), fmt, out, { quality: 95 });
}

// opts: { x, y, width, height } en píxeles del original
async function cropImage(file, opts) {
  const fmt = sameFmt(file);
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (recortada)`, fmt);
  const buf = await (await load(file)).png().toBuffer();
  const r = {
    left: Math.max(0, Math.round(opts.x)),
    top: Math.max(0, Math.round(opts.y)),
    width: Math.max(1, Math.round(opts.width)),
    height: Math.max(1, Math.round(opts.height)),
  };
  return save(sharp(buf).extract(r), fmt, out, { quality: 95 });
}

// opts: { width?, height?, percent? }
async function resizeImage(file, opts) {
  const fmt = sameFmt(file);
  const img = await load(file);
  const meta = await img.metadata();
  let w, h;
  if (opts.percent) {
    w = Math.max(1, Math.round((meta.width * opts.percent) / 100));
    h = Math.max(1, Math.round((meta.height * opts.percent) / 100));
  } else {
    w = opts.width ? Math.round(opts.width) : null;
    h = opts.height ? Math.round(opts.height) : null;
  }
  const label = opts.percent ? `${opts.percent}%` : `${w || 'auto'}x${h || 'auto'}`;
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (${label})`, fmt);
  // si se agranda y está activada la IA, primero se mejora y después se ajusta al tamaño pedido
  const tw = w || Math.round((h / meta.height) * meta.width), th = h || Math.round((w / meta.width) * meta.height);
  const factor = Math.max(tw / meta.width, th / meta.height);
  if (opts.ai && factor > 1.05) {
    const big = await aiUpscaleBuffer(file, factor > 4 ? 4 : factor, opts.onProgress, opts.style);
    return save(big().resize(w, h, { fit: w && h ? 'inside' : 'cover', kernel: 'lanczos3' }), fmt, out, { quality: 92 });
  }
  return save(img.resize(w, h, { fit: w && h ? 'inside' : 'cover' }), fmt, out, { quality: 92 });
}

// opts: { colors: ['#hex','#hex'], angle, padding (0-0.5 relativo), radius (px del original), shadow (bool), format }
async function backgroundImage(file, opts) {
  const src = await (await load(file)).png().toBuffer();
  const meta = await sharp(src).metadata();
  const W = meta.width, H = meta.height;
  const pad = Math.round(Math.max(W, H) * (opts.padding ?? 0.12));
  const CW = W + pad * 2, CH = H + pad * 2;
  const radius = Math.round(opts.radius ?? 0);
  const [c1, c2] = opts.colors && opts.colors.length ? opts.colors : ['#ff7a45', '#ffd166'];
  const angle = opts.angle ?? 135;
  const rad = (angle - 90) * Math.PI / 180;
  const x1 = 50 - Math.cos(rad) * 50, y1 = 50 - Math.sin(rad) * 50;
  const x2 = 50 + Math.cos(rad) * 50, y2 = 50 + Math.sin(rad) * 50;

  const bgSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${CW}" height="${CH}">
    <defs><linearGradient id="g" x1="${x1}%" y1="${y1}%" x2="${x2}%" y2="${y2}%">
      <stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2 || c1}"/>
    </linearGradient></defs>
    <rect width="100%" height="100%" fill="url(#g)"/></svg>`;

  const layers = [];
  if (opts.shadow) {
    const blur = Math.max(4, Math.round(Math.max(W, H) * 0.03));
    const shadowSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${CW}" height="${CH}">
      <defs><filter id="f" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="${blur}"/></filter></defs>
      <rect x="${pad}" y="${pad + blur * 0.6}" width="${W}" height="${H}" rx="${radius}" fill="rgba(0,0,0,0.35)" filter="url(#f)"/></svg>`;
    layers.push({ input: Buffer.from(shadowSvg), left: 0, top: 0 });
  }
  let fg = src;
  if (radius > 0) {
    const mask = Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}"><rect width="${W}" height="${H}" rx="${radius}" ry="${radius}" fill="#fff"/></svg>`);
    fg = await sharp(src).ensureAlpha().composite([{ input: mask, blend: 'dest-in' }]).png().toBuffer();
  }
  layers.push({ input: fg, left: pad, top: pad });

  const fmt = normFmt(opts.format || 'png');
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (con fondo)`, fmt);
  const img = sharp(Buffer.from(bgSvg)).composite(layers);
  const flat = await img.png().toBuffer();
  return save(sharp(flat), fmt, out, { quality: 95 });
}

// ---------- IA ----------
// Devuelve un PNG (Buffer) mejorado x4 (con alfa si el original tenía)
// Mejora x4 con IA. Devuelve un pipeline de sharp con la imagen grande (en crudo, sin límite de píxeles).
async function aiUpscaleBuffer(file, _factor, onProgress, style) {
  const src = await (await load(file)).png().toBuffer();
  const meta = await sharp(src).metadata();
  const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const up = await getAi().upscale4x(data, info.width, info.height, onProgress, style);
  const W = info.width * 4, H = info.height * 4;
  let raw = { data: up, width: W, height: H, channels: 3 };
  if (meta.hasAlpha) {
    const alpha = await sharp(src).extractChannel('alpha').resize(W, H, { kernel: 'lanczos3' }).raw().toBuffer();
    const rgba = Buffer.alloc(W * H * 4);
    for (let i = 0, j = 0, k = 0; i < W * H; i++) { rgba[k++] = up[j++]; rgba[k++] = up[j++]; rgba[k++] = up[j++]; rgba[k++] = alpha[i]; }
    raw = { data: rgba, width: W, height: H, channels: 4 };
  }
  return () => sharp(raw.data, { raw: { width: raw.width, height: raw.height, channels: raw.channels }, limitInputPixels: false });
}

// opts: { scale: 2|4, style: 'detail'|'smooth' }
// quitar fondo (IA, paquete aparte): PNG con transparencia al lado del original
async function removeBgImage(file, onProgress) {
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (sin fondo)`, 'png');
  const png = await require('./rmbg').removeBackground(file, { onProgress });
  await png.toFile(out);
  return out;
}

async function upscaleImage(file, opts = {}) {
  const scale = opts.scale === 4 ? 4 : 2;
  let fmt = sameFmt(file);
  if (fmt === 'gif' || fmt === 'bmp') fmt = 'png';
  const m0 = await (await load(file)).metadata();
  const side = Math.max(m0.width || 0, m0.height || 0) * scale;
  if (side > 16383 && (fmt === 'webp' || fmt === 'avif')) fmt = 'png'; // WEBP/AVIF no soportan tanto
  if (side > 30000) throw new Error(`Quedaría de ${side}px de lado: es demasiado. Probá con 2× o achicala primero.`);
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (mejorada x${scale})`, fmt);
  const big = await aiUpscaleBuffer(file, scale, opts.onProgress, opts.style);
  let img = big();
  if (scale === 2) {
    const w = (m0.orientation >= 5 ? m0.height : m0.width) * 2, h = (m0.orientation >= 5 ? m0.width : m0.height) * 2;
    img = big().resize(w, h, { kernel: 'lanczos3' });
  }
  return save(img, fmt, out, { quality: 95 });
}

// Caras en coordenadas del original: [{x,y,w,h,score}]
async function detectFaces(file) {
  const src = await (await load(file)).removeAlpha().png().toBuffer();
  const { width: W, height: H } = await sharp(src).metadata();
  return getAi().detectFaces(W, H, (x, y, w, h) =>
    sharp(src).extract({ left: x, top: y, width: Math.max(1, Math.min(w, W - x)), height: Math.max(1, Math.min(h, H - y)) })
      .resize(640, 480, { fit: 'fill' }).removeAlpha().raw().toBuffer());
}

// opts: { masks: [{ shape:'ellipse'|'rect', style:'blur'|'pixel'|'black', strength:0..1, feather:0..1, x,y,w,h }] }
// Cada máscara se procesa por separado (con sus propios ajustes) solo en su zona.
// Las fórmulas coinciden con la vista previa de editor.js.
const fxSigma = (minSide, st) => minSide * (0.04 + st * 0.22);
const fxBlock = (minSide, st) => Math.max(3, minSide * (0.06 + st * 0.2));
const fxFeather = (minSide, f) => f * minSide * 0.2;

async function blurImage(file, opts) {
  const src = await (await load(file)).png().toBuffer();
  const meta = await sharp(src).metadata();
  const W = meta.width, H = meta.height;
  const masks = (opts.masks || []).filter((m) => m.w > 1 && m.h > 1);
  if (!masks.length) throw new Error('No marcaste ninguna zona');

  const layers = [];
  for (const m of masks) {
    const style = m.style || opts.style || 'blur';
    const st = Math.min(1, Math.max(0, m.strength ?? opts.strength ?? 0.7));
    const minSide = Math.min(m.w, m.h);
    const sigma = Math.min(300, Math.max(0.5, fxSigma(minSide, st)));
    // zona a procesar: la máscara + margen para que el desenfoque tome lo de alrededor
    const pad = style === 'blur' ? Math.ceil(Math.max(sigma * 2.5, fxFeather(minSide, m.feather ?? 0.35) * 1.5)) : 0;
    const left = Math.max(0, Math.floor(m.x - pad)), top = Math.max(0, Math.floor(m.y - pad));
    const right = Math.min(W, Math.ceil(m.x + m.w + pad)), bottom = Math.min(H, Math.ceil(m.y + m.h + pad));
    const rw = right - left, rh = bottom - top;
    if (rw < 1 || rh < 1) continue;
    const region = sharp(src).extract({ left, top, width: rw, height: rh });

    let effect;
    if (style === 'black') {
      effect = await sharp({ create: { width: rw, height: rh, channels: 4, background: '#000' } }).png().toBuffer();
    } else if (style === 'pixel') {
      const block = fxBlock(minSide, st);
      const small = await region.clone().resize(Math.max(1, Math.round(rw / block)), Math.max(1, Math.round(rh / block)), { kernel: 'cubic' }).png().toBuffer();
      effect = await sharp(small).resize(rw, rh, { kernel: 'nearest' }).png().toBuffer();
    } else {
      effect = await region.clone().blur(sigma).png().toBuffer();
    }

    const f = style === 'blur' ? fxFeather(minSide, m.feather ?? 0.35) : 0;
    const x = m.x - left, y = m.y - top;
    const filt = f > 0.5 ? `<filter id="f" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="${f / 2}"/></filter>` : '';
    const fa = filt ? ' filter="url(#f)"' : '';
    // con borde suave la forma se achica un poco para que el difuminado quede adentro
    const ins = 0; // el difuminado queda centrado sobre el borde, igual que en la vista previa
    const shape = m.shape === 'rect'
      ? `<rect x="${x + ins}" y="${y + ins}" width="${Math.max(1, m.w - 2 * ins)}" height="${Math.max(1, m.h - 2 * ins)}" rx="${Math.min(m.w, m.h) * 0.06}"${fa}/>`
      : `<ellipse cx="${x + m.w / 2}" cy="${y + m.h / 2}" rx="${Math.max(0.5, m.w / 2 - ins)}" ry="${Math.max(0.5, m.h / 2 - ins)}"${fa}/>`;
    const maskSvg = Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${rw}" height="${rh}"><defs>${filt}</defs><g fill="#fff">${shape}</g></svg>`);
    const masked = await sharp(effect).ensureAlpha().composite([{ input: maskSvg, blend: 'dest-in' }]).png().toBuffer();
    layers.push({ input: masked, left, top });
  }

  const fmt = sameFmt(file) === 'gif' ? 'png' : sameFmt(file);
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (blur)`, fmt);
  // de a tandas para no armar una sola operación gigante
  let buf = src;
  for (let i = 0; i < layers.length; i += 40) buf = await sharp(buf).composite(layers.slice(i, i + 40)).png().toBuffer();
  return save(sharp(buf), fmt, out, { quality: 95 });
}

// Info + vista previa para los diálogos
async function preview(file, max = 1400) {
  const img = await load(file);
  const buf = await img.png().toBuffer();
  const meta = await sharp(buf).metadata();
  const small = await sharp(buf).resize(max, max, { fit: 'inside', withoutEnlargement: true }).png().toBuffer();
  return { width: meta.width, height: meta.height, dataUrl: `data:image/png;base64,${small.toString('base64')}` };
}

// ---------- PDF ----------
async function loadPdf(file) {
  return PDFDocument.load(fs.readFileSync(file), { ignoreEncryption: true, updateMetadata: false });
}

// qpdf: abre PDFs protegidos/raros que pdf-lib no puede (antes salían páginas en blanco)
const QPDF = path.join(__dirname, '..', 'bin', process.platform === 'win32' ? 'qpdf/qpdf.exe' : 'qpdf-linux/bin/qpdf');
// en Mac se usa qpdf compilado a WebAssembly (mismo qpdf, sin binario aparte)
const QPDF_WASM = process.platform === 'darwin';
const hasQpdf = () => (QPDF_WASM ? (() => { try { require.resolve('@neslinesli93/qpdf-wasm'); return true; } catch { return false; } })() : fs.existsSync(QPDF));

// corre qpdf-wasm: los archivos reales se copian a un disco virtual y los resultados se copian de vuelta
async function qpdfWasm(args) {
  const create = require('@neslinesli93/qpdf-wasm');
  let err = '';
  const m = await create({ print: () => {}, printErr: (t) => { err += `${t}\n`; } });
  m.FS.mkdir('/i'); m.FS.mkdir('/o');
  const outs = [];
  let k = 0;
  const vargs = args.map((a) => {
    if (!path.isAbsolute(a)) return a;
    if (fs.existsSync(a) && fs.statSync(a).isFile()) {
      const v = `/i/f${k++}.pdf`;
      m.FS.writeFile(v, fs.readFileSync(a));
      return v;
    }
    outs.push(a); // salida (puede tener %d para separar páginas)
    return `/o/${path.basename(a)}`;
  });
  let code = 0;
  try { code = m.callMain(['--warning-exit-0', ...vargs]); } catch (e) { code = typeof e?.status === 'number' ? e.status : 2; if (!err) err = String(e?.message || e); }
  if (code !== 0) {
    if (/password/i.test(err)) throw new Error('Ese PDF tiene contraseña para abrirlo');
    throw new Error(err.trim().split('\n').pop() || `qpdf terminó con código ${code}`);
  }
  const dir = path.dirname(outs[0]);
  for (const name of m.FS.readdir('/o')) {
    if (name === '.' || name === '..') continue;
    fs.writeFileSync(path.join(dir, name), m.FS.readFile(`/o/${name}`));
  }
}

function qpdf(args) {
  if (QPDF_WASM) return qpdfWasm(args);
  return new Promise((resolve, reject) => {
    const { spawn } = require('child_process');
    const env = { ...process.env };
    if (process.platform !== 'win32') env.LD_LIBRARY_PATH = path.join(path.dirname(QPDF), '..', 'lib');
    const p = spawn(QPDF, ['--warning-exit-0', ...args], { windowsHide: true, env });
    let err = '';
    p.stderr.on('data', (d) => { err += d; });
    p.on('error', reject);
    p.on('close', (code) => {
      if (code === 0) return resolve();
      if (/password/i.test(err)) return reject(new Error('Ese PDF tiene contraseña para abrirlo'));
      reject(new Error(err.trim().split('\n').pop() || `qpdf terminó con código ${code}`));
    });
  });
}

async function mergePdfs(files) {
  const dest = uniquePath(path.dirname(files[0]), `${baseOf(files[0])} (unido)`, 'pdf');
  if (hasQpdf()) {
    await qpdf(['--empty', '--decrypt', '--pages', ...files.flatMap((f) => [f, '1-z']), '--', dest]);
    return dest;
  }
  const out = await PDFDocument.create();
  for (const f of files) {
    const src = await loadPdf(f);
    const pages = await out.copyPages(src, src.getPageIndices());
    pages.forEach((p) => out.addPage(p));
  }
  fs.writeFileSync(dest, await out.save());
  return dest;
}

// imágenes y PDFs mezclados → un solo PDF, en el orden en que llegaron (cada imagen es una página)
async function imagePagePdf(f) {
  const doc = await PDFDocument.create();
  const e = extOf(f);
  const embedded = (e === 'jpg' || e === 'jpeg')
    ? await doc.embedJpg(await (await load(f)).jpeg({ quality: 92 }).toBuffer())
    : await doc.embedPng(await (await load(f)).png().toBuffer());
  const w = embedded.width * 0.75, h = embedded.height * 0.75;
  doc.addPage([w, h]).drawImage(embedded, { x: 0, y: 0, width: w, height: h });
  return doc.save();
}
async function joinToPdf(files) {
  const dest = uniquePath(path.dirname(files[0]), `${baseOf(files[0])} (unido)`, 'pdf');
  if (hasQpdf()) {
    // qpdf también abre PDFs protegidos (sin contraseña de apertura): cada imagen pasa primero a un PDF de una página
    const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'mixtape-unir-'));
    try {
      const parts = [];
      for (const [i, f] of files.entries()) {
        if (kindFromExt(extOf(f)) === 'pdf') { parts.push(f); continue; }
        const t = path.join(tmp, `${i}.pdf`);
        fs.writeFileSync(t, await imagePagePdf(f));
        parts.push(t);
      }
      await qpdf(['--empty', '--decrypt', '--pages', ...parts.flatMap((f) => [f, '1-z']), '--', dest]);
    } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
    return dest;
  }
  const out = await PDFDocument.create();
  for (const f of files) {
    if (kindFromExt(extOf(f)) === 'pdf') {
      const src = await loadPdf(f);
      (await out.copyPages(src, src.getPageIndices())).forEach((p) => out.addPage(p));
    } else {
      const e = extOf(f);
      const embedded = (e === 'jpg' || e === 'jpeg')
        ? await out.embedJpg(await (await load(f)).jpeg({ quality: 92 }).toBuffer())
        : await out.embedPng(await (await load(f)).png().toBuffer());
      const w = embedded.width * 0.75, h = embedded.height * 0.75;
      out.addPage([w, h]).drawImage(embedded, { x: 0, y: 0, width: w, height: h });
    }
  }
  out.setProducer('MIXTAPE');
  out.setCreator('MIXTAPE');
  fs.writeFileSync(dest, await out.save());
  return dest;
}

async function splitPdf(file) {
  const dir = uniqueDir(path.dirname(file), `${baseOf(file)} (páginas)`);
  if (hasQpdf()) {
    await qpdf(['--decrypt', '--split-pages', file, path.join(dir, `${baseOf(file)} - página %d.pdf`)]);
    return fs.readdirSync(dir).filter((f) => f.endsWith('.pdf')).sort().map((f) => path.join(dir, f));
  }
  const src = await loadPdf(file);
  const n = src.getPageCount();
  const outs = [];
  for (let i = 0; i < n; i++) {
    const d = await PDFDocument.create();
    const [p] = await d.copyPages(src, [i]);
    d.addPage(p);
    const o = path.join(dir, `${baseOf(file)} - página ${String(i + 1).padStart(String(n).length, '0')}.pdf`);
    fs.writeFileSync(o, await d.save());
    outs.push(o);
  }
  return outs;
}

async function rotatePdf(file, deg = 90) {
  deg = ((Math.round(deg / 90) * 90) % 360 + 360) % 360;
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (rotado)`, 'pdf');
  if (hasQpdf()) {
    if (deg === 0) { fs.copyFileSync(file, out); return out; }
    await qpdf(['--decrypt', `--rotate=+${deg}`, file, out]);
    return out;
  }
  const doc = await loadPdf(file);
  doc.getPages().forEach((p) => p.setRotation(degrees((p.getRotation().angle + deg) % 360)));
  fs.writeFileSync(out, await doc.save());
  return out;
}

async function stripPdf(file) {
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (sin metadata)`, 'pdf');
  if (hasQpdf()) {
    await qpdf(['--decrypt', '--remove-info', '--remove-metadata', file, out]);
    return out;
  }
  const doc = await loadPdf(file);
  doc.setTitle(''); doc.setAuthor(''); doc.setSubject(''); doc.setKeywords([]);
  doc.setProducer(''); doc.setCreator('');
  fs.writeFileSync(out, await doc.save());
  return out;
}

// renderer: async (bytes) => [pngBuffer por página];  texter: async (bytes) => string
async function pdfToImages(file, fmt, renderer) {
  fmt = normFmt(fmt);
  const pages = await renderer(fs.readFileSync(file));
  const outs = [];
  if (pages.length === 1) {
    outs.push(await save(sharp(pages[0]), fmt, uniquePath(path.dirname(file), baseOf(file), fmt)));
  } else {
    const dir = uniqueDir(path.dirname(file), `${baseOf(file)} (${fmt.toUpperCase()})`);
    const pad = String(pages.length).length;
    for (let i = 0; i < pages.length; i++) {
      const o = path.join(dir, `${baseOf(file)} - página ${String(i + 1).padStart(pad, '0')}.${fmt}`);
      outs.push(await save(sharp(pages[i]), fmt, o));
    }
  }
  return outs;
}

async function pdfToText(file, texter) {
  const text = await texter(fs.readFileSync(file));
  const out = uniquePath(path.dirname(file), baseOf(file), 'txt');
  fs.writeFileSync(out, '﻿' + text, 'utf8');
  return out;
}

// ---------- despachador ----------
// job: { ring: 'format'|'action', id, files, options }
// ctx: { renderPdf, textPdf }
async function run(job, ctx = {}) {
  const files = job.files.filter((f) => fs.existsSync(f));
  if (!files.length) throw new Error('No encontré los archivos');
  if (job.id === 'av_replace' || job.id === 'av_mix' || job.id === 'av_adjust') {
    const video = files.find((f) => kindFromExt(extOf(f)) === 'video');
    const audio = files.find((f) => kindFromExt(extOf(f)) === 'audio');
    if (!video || !audio) throw new Error('Arrastrá un video y un audio juntos');
    const opts = job.id === 'av_adjust' ? job.options : { mode: job.id === 'av_mix' ? 'mix' : 'replace', fadeOut: 1 };
    const out = await require('./av').combineAudioVideo(video, audio, opts, ctx.onProgress);
    return { outputs: [out], skipped: Math.max(0, files.length - 2) };
  }
  if (job.id === 'pdf_join') {
    const ok = files.filter((f) => ['image', 'pdf'].includes(kindFromExt(extOf(f))));
    if (ok.length < 2) throw new Error('Para unir arrastrá 2 o más archivos (imágenes y/o PDFs)');
    return { outputs: [await joinToPdf(ok)], skipped: files.length - ok.length };
  }
  const kind = kindFromExt(extOf(files[0]));
  const same = files.filter((f) => kindFromExt(extOf(f)) === kind);
  const outs = [];
  const each = async (fn) => { for (const f of same) [].concat(await fn(f)).forEach((o) => outs.push(o)); };

  if (kind === 'image') {
    if (job.ring === 'format') {
      if (job.id === 'pdf') outs.push(await imagesToPdf(same));
      else await each((f) => convertImage(f, job.id));
    } else {
      switch (job.id) {
        case 'compress': await each((f) => compressImage(f, job.options)); break;
        case 'strip': await each(stripImage); break;
        case 'rotate': await each((f) => rotateImage(f, job.options || { angle: 90 })); break;
        case 'crop': outs.push(await cropImage(same[0], job.options)); break;
        case 'resize': await each((f) => resizeImage(f, { ...job.options, onProgress: ctx.onProgress })); break;
        case 'background': outs.push(await backgroundImage(same[0], job.options)); break;
        case 'upscale': await each((f) => upscaleImage(f, { ...job.options, onProgress: ctx.onProgress })); break;
        case 'rmbg': await each((f) => removeBgImage(f, ctx.onProgress)); break;
        case 'blur': outs.push(await blurImage(same[0], job.options)); break;
        default: throw new Error(`Acción desconocida: ${job.id}`);
      }
    }
  } else if (kind === 'pdf') {
    if (job.ring === 'format') {
      if (job.id === 'txt') await each((f) => pdfToText(f, ctx.textPdf));
      else await each((f) => pdfToImages(f, job.id, ctx.renderPdf));
    } else {
      switch (job.id) {
        case 'merge':
          if (same.length < 2) throw new Error('Para unir arrastrá 2 o más PDFs juntos');
          outs.push(await mergePdfs(same)); break;
        case 'split': await each(splitPdf); break;
        case 'rotate': await each((f) => rotatePdf(f, job.options?.angle ?? 90)); break;
        case 'strip': await each(stripPdf); break;
        default: throw new Error(`Acción desconocida: ${job.id}`);
      }
    }
  } else if (kind === 'audio' || kind === 'video') {
    const av = require('./av');
    const prog = ctx.onProgress;
    if (job.id === 'midi') {
      const midi = require('./midi');
      await each(async (f) => (await midi.convert(f, { ...(job.options || {}), onProgress: prog })).files);
    } else if (job.id === 'stems' || job.id === 'stems4' || job.id === 'stems2') {
      const stems = require('./stems');
      const mode = job.id === 'stems4' ? 'four' : job.id === 'stems2' ? 'two' : 'pick';
      await each((f) => stems.separate(f, mode, { onProgress: prog, ...(job.options || {}) }));
    } else if (job.ring === 'format') {
      if (kind === 'audio') {
        if (job.id === 'mp4') await each((f) => av.audioToVideo(f, prog));
        else await each((f) => av.toAudio(f, job.id, prog));
      } else if (job.id === 'mp3' || job.id === 'wav') await each((f) => av.toAudio(f, job.id, prog));
      else await each((f) => av.videoConvert(f, job.id, prog));
    } else {
      switch (job.id) {
        case 'normalize': await each((f) => av.normalizeAudio(f, prog)); break;
        case 'strip': await each((f) => av.stripMedia(f)); break;
        case 'compress': await each((f) => av.compressVideo(f, prog, job.options)); break;
        case 'mute': await each((f) => av.muteVideo(f)); break;
        case 'vtrim': outs.push(await av.trimMedia(same[0], job.options || {}, prog)); break;
        case 'transcribe': outs.push(...(await require('./transcribe').transcribeFile(same[0], { ...(job.options || {}), onProgress: prog })).files); break;
        default: throw new Error(`Acción desconocida: ${job.id}`);
      }
    }
  } else {
    throw new Error('Ese tipo de archivo todavía no lo soporto');
  }
  return { outputs: outs, skipped: files.length - same.length };
}

module.exports = { run, preview, uniquePath, detectFaces, estimateCompress };
