import * as pdfjsLib from '../../node_modules/pdfjs-dist/build/pdf.mjs';

const base = new URL('../../node_modules/pdfjs-dist/', location.href).href;
pdfjsLib.GlobalWorkerOptions.workerSrc = base + 'build/pdf.worker.mjs';

const MAX_SIDE = 4000;

async function open(bytes) {
  return pdfjsLib.getDocument({
    data: bytes,
    cMapUrl: base + 'cmaps/',
    cMapPacked: true,
    standardFontDataUrl: base + 'standard_fonts/',
  }).promise;
}

async function render(bytes, scale, onlyFirst) {
  const doc = await open(bytes);
  const pages = [];
  const last = onlyFirst ? 1 : doc.numPages;
  for (let i = 1; i <= last; i++) {
    const page = await doc.getPage(i);
    let vp = page.getViewport({ scale });
    const k = Math.min(1, MAX_SIDE / Math.max(vp.width, vp.height));
    if (k < 1) vp = page.getViewport({ scale: scale * k });
    const canvas = new OffscreenCanvas(Math.ceil(vp.width), Math.ceil(vp.height));
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: ctx, viewport: vp }).promise;
    const blob = await canvas.convertToBlob({ type: 'image/png' });
    pages.push(new Uint8Array(await blob.arrayBuffer()));
    page.cleanup();
  }
  await doc.destroy();
  return pages;
}

async function text(bytes) {
  const doc = await open(bytes);
  const out = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i);
    const tc = await page.getTextContent();
    let s = '';
    for (const it of tc.items) {
      s += it.str || '';
      if (it.hasEOL) s += '\n';
    }
    out.push(s.trim());
  }
  await doc.destroy();
  return out.join('\n\n');
}

async function handle({ id, mode, bytes, scale }) {
  try {
    if (mode === 'render') return { id, pages: await render(bytes, scale || 2) };
    if (mode === 'render1') return { id, pages: await render(bytes, scale || 1, true) };
    if (mode === 'text') return { id, text: await text(bytes) };
    throw new Error('modo desconocido');
  } catch (e) {
    return { id, error: String(e && e.message || e) };
  }
}

window.__ruedita_pdf = handle; // para pruebas
if (window.ruedita) window.ruedita.on('pdf-job', async (job) => window.ruedita.send('pdf-result', await handle(job)));
