// Audio → texto con Whisper large-v3-turbo (OpenAI, MIT; export ONNX int8 de sherpa-onnx, Apache 2.0).
// Port de whisper/audio.py (log-mel) y whisper/transcribe.py + decoding.py (búsqueda greedy con reglas de
// marcas de tiempo, ventanas de 30 s, condición con el texto anterior y reintentos con temperatura).
// Sale .txt (texto corrido) y/o .srt (subtítulos).
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const ort = require('onnxruntime-node');

const SR = 16000, N_FFT = 400, HOP = 160, N_MELS = 128, N_FRAMES = 3000, N_SAMPLES = 480000;
const T = { eot: 50257, sot: 50258, translate: 50359, transcribe: 50360, sotLm: 50361, sotPrev: 50362, noSpeech: 50363, noTs: 50364, ts0: 50365 };
const LANG0 = 50259, NLANG = 100, VOCAB = 51866;
const LANGS = ['en', 'zh', 'de', 'es', 'ru', 'ko', 'fr', 'ja', 'pt', 'tr', 'pl', 'ca', 'nl', 'ar', 'sv', 'it', 'id', 'hi', 'fi', 'vi', 'he', 'uk', 'el', 'ms', 'cs', 'ro', 'da', 'hu', 'ta', 'no', 'th', 'ur', 'hr', 'bg', 'lt', 'la', 'mi', 'ml', 'cy', 'sk', 'te', 'fa', 'lv', 'bn', 'sr', 'az', 'sl', 'kn', 'et', 'mk', 'br', 'eu', 'is', 'hy', 'ne', 'mn', 'bs', 'kk', 'sq', 'sw', 'gl', 'mr', 'pa', 'si', 'km', 'sn', 'yo', 'so', 'af', 'oc', 'ka', 'be', 'tg', 'sd', 'gu', 'am', 'yi', 'lo', 'uz', 'fo', 'ht', 'ps', 'tk', 'nn', 'mt', 'sa', 'lb', 'my', 'bo', 'tl', 'mg', 'as', 'tt', 'haw', 'ln', 'ha', 'ba', 'jw', 'su', 'yue'];
const LANG_NAMES = { es: 'español', en: 'inglés', pt: 'portugués', it: 'italiano', fr: 'francés', de: 'alemán', ja: 'japonés', ko: 'coreano', zh: 'chino', ru: 'ruso', ca: 'catalán', nl: 'neerlandés', pl: 'polaco', tr: 'turco', ar: 'árabe', hi: 'hindi' };
const NON_SPEECH = [1, 2, 7, 8, 9, 10, 14, 25, 26, 27, 28, 29, 31, 58, 59, 60, 61, 62, 63, 90, 91, 92, 93, 359, 503, 522, 542, 873, 893, 902, 918, 922, 931, 1350, 1853, 1982, 2460, 2627, 3246, 3253, 3268, 3536, 3846, 3961, 4183, 4667, 6585, 6647, 7273, 9061, 9383, 10428, 10929, 11938, 12033, 12331, 12562, 13793, 14157, 14635, 15265, 15618, 16553, 16604, 18362, 18956, 20075, 21675, 22520, 26130, 26161, 26435, 28279, 29464, 31650, 32302, 32470, 36865, 42863, 47425, 49870, 50254];
const FILES = { enc: 'turbo-encoder.int8.onnx', dec: 'turbo-decoder.int8.onnx', tok: 'turbo-tokens.txt' };

// ---------------- dónde está el modelo (paquete "transcribir", se baja una sola vez) ----------------
let PACK_DIR = null; // carpeta que eligió el usuario para el paquete (ajuste "trDir")
const setPackDir = (d) => { PACK_DIR = d || null; };
function modelDirs() {
  const dirs = [path.join(__dirname, '..', 'models', 'transcribir'), ...require('./bins').packDirs('transcribir')];
  if (PACK_DIR) dirs.unshift(PACK_DIR);
  try { dirs.push(path.join(require('electron').app.getPath('userData'), 'transcribir')); } catch {}
  try { dirs.push(path.join(require('electron').app.getPath('appData'), 'Ruedita', 'transcribir')); } catch {} // de cuando se llamaba Ruedita
  if (process.env.RUEDITA_WHISPER) dirs.unshift(process.env.RUEDITA_WHISPER);
  return dirs;
}
const modelDir = () => modelDirs().find((d) => Object.values(FILES).every((f) => fs.existsSync(path.join(d, f)))) || null;
const available = () => !!modelDir();
function installDir() {
  if (PACK_DIR) return PACK_DIR;
  try { return path.join(require('electron').app.getPath('userData'), 'transcribir'); } catch { return path.join(__dirname, '..', 'models', 'transcribir'); }
}

// ---------------- FFT de 400 puntos (radices 4·4·5·5) ----------------
const TW_RE = new Float64Array(N_FFT), TW_IM = new Float64Array(N_FFT);
for (let k = 0; k < N_FFT; k++) { TW_RE[k] = Math.cos((-2 * Math.PI * k) / N_FFT); TW_IM[k] = Math.sin((-2 * Math.PI * k) / N_FFT); }
const FACT = [4, 4, 5, 5];
function fft(inRe, inIm, off, stride, n, outRe, outIm, outOff, depth) {
  if (n === 1) { outRe[outOff] = inRe[off]; outIm[outOff] = inIm[off]; return; }
  const p = FACT[depth], m = n / p, step = N_FFT / n;
  for (let j = 0; j < p; j++) fft(inRe, inIm, off + j * stride, stride * p, m, outRe, outIm, outOff + j * m, depth + 1);
  const tr = new Float64Array(p), ti = new Float64Array(p);
  for (let k = 0; k < m; k++) {
    for (let j = 0; j < p; j++) { tr[j] = outRe[outOff + j * m + k]; ti[j] = outIm[outOff + j * m + k]; }
    for (let q = 0; q < p; q++) {
      const kk = k + q * m;
      let sr = 0, si = 0;
      for (let j = 0; j < p; j++) {
        const e = ((j * kk) % n) * step;
        const wr = TW_RE[e], wi = TW_IM[e];
        sr += tr[j] * wr - ti[j] * wi; si += tr[j] * wi + ti[j] * wr;
      }
      outRe[outOff + kk] = sr; outIm[outOff + kk] = si;
    }
  }
}

// ---------------- filtros mel (librosa, escala Slaney, norma Slaney) ----------------
function melFilters() {
  const hz2mel = (f) => (f < 1000 ? (3 * f) / 200 : 15 + Math.log(f / 1000) / (Math.log(6.4) / 27));
  const mel2hz = (m) => (m < 15 ? (200 * m) / 3 : 1000 * Math.exp((Math.log(6.4) / 27) * (m - 15)));
  const nb = N_FFT / 2 + 1;
  const freqs = Array.from({ length: nb }, (_, i) => (i * SR) / N_FFT);
  const m0 = hz2mel(0), m1 = hz2mel(SR / 2);
  const melF = Array.from({ length: N_MELS + 2 }, (_, i) => mel2hz(m0 + ((m1 - m0) * i) / (N_MELS + 1)));
  const W = new Float32Array(N_MELS * nb);
  for (let i = 0; i < N_MELS; i++) {
    const enorm = 2 / (melF[i + 2] - melF[i]);
    for (let k = 0; k < nb; k++) {
      const lower = (freqs[k] - melF[i]) / (melF[i + 1] - melF[i]);
      const upper = (melF[i + 2] - freqs[k]) / (melF[i + 2] - melF[i + 1]);
      W[i * nb + k] = Math.max(0, Math.min(lower, upper)) * enorm;
    }
  }
  return W;
}

// log-mel de todo el audio (+30 s de silencio al final, como Whisper). Devuelve [N_MELS][frames] en un Float32Array.
async function logMel(audio) {
  const x = new Float32Array(audio.length + N_SAMPLES);
  x.set(audio);
  const pad = N_FFT / 2, L = x.length;
  const at = (i) => (i < 0 ? x[-i] : i >= L ? x[2 * L - 2 - i] : x[i]); // reflejo
  const frames = Math.floor(L / HOP); // 1 + L/HOP con center, menos el último (Whisper lo descarta)
  const win = new Float64Array(N_FFT);
  for (let i = 0; i < N_FFT; i++) win[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / N_FFT);
  const W = melFilters(), nb = N_FFT / 2 + 1;
  const mel = new Float32Array(N_MELS * frames);
  const re = new Float64Array(N_FFT), im = new Float64Array(N_FFT), oRe = new Float64Array(N_FFT), oIm = new Float64Array(N_FFT), pw = new Float64Array(nb);
  let gmax = -Infinity;
  for (let t = 0; t < frames; t++) {
    if (t % 1500 === 1499) await new Promise((r) => setImmediate(r));
    const s = t * HOP - pad;
    for (let i = 0; i < N_FFT; i++) { re[i] = at(s + i) * win[i]; im[i] = 0; }
    fft(re, im, 0, 1, N_FFT, oRe, oIm, 0, 0);
    for (let k = 0; k < nb; k++) pw[k] = oRe[k] * oRe[k] + oIm[k] * oIm[k];
    for (let m = 0; m < N_MELS; m++) {
      let acc = 0;
      const row = m * nb;
      for (let k = 0; k < nb; k++) { const w = W[row + k]; if (w) acc += w * pw[k]; }
      const v = Math.log10(Math.max(acc, 1e-10));
      mel[m * frames + t] = v;
      if (v > gmax) gmax = v;
    }
  }
  const floor = gmax - 8;
  for (let i = 0; i < mel.length; i++) mel[i] = (Math.max(mel[i], floor) + 4) / 4;
  return { mel, frames };
}

// ---------------- tokens → texto ----------------
let VOCAB_BYTES = null;
function loadVocab(dir) {
  if (VOCAB_BYTES) return VOCAB_BYTES;
  VOCAB_BYTES = [];
  for (const line of fs.readFileSync(path.join(dir, FILES.tok), 'utf8').split('\n')) {
    const sp = line.lastIndexOf(' ');
    if (sp < 0) continue;
    VOCAB_BYTES[+line.slice(sp + 1)] = Buffer.from(line.slice(0, sp), 'base64');
  }
  return VOCAB_BYTES;
}
const decodeText = (ids) => Buffer.concat(ids.filter((i) => i < T.eot).map((i) => VOCAB_BYTES[i] || Buffer.alloc(0))).toString('utf8');

// ---------------- sesiones ----------------
let SESS = null;
async function sessions(dir) {
  if (SESS && SESS.dir === dir) return SESS;
  const opt = { executionProviders: ['cpu'] };
  const [enc, dec] = await Promise.all([ort.InferenceSession.create(path.join(dir, FILES.enc), opt), ort.InferenceSession.create(path.join(dir, FILES.dec), opt)]);
  SESS = { dir, enc, dec };
  return SESS;
}

// ---------------- decodificación ----------------
const NEG = -Infinity;
function logSoftmaxStats(lg) {
  let mx = NEG;
  for (let i = 0; i < lg.length; i++) if (lg[i] > mx) mx = lg[i];
  let s = 0;
  for (let i = 0; i < lg.length; i++) if (lg[i] !== NEG) s += Math.exp(lg[i] - mx);
  return mx + Math.log(s); // logsumexp
}

async function decodeWindow(S, crossK, crossV, { prompt, lang, temperature, maxInitTs = 50 }) {
  const init = [];
  if (prompt && prompt.length) init.push(T.sotPrev, ...prompt.slice(-223));
  const sotIdx = init.length;
  init.push(T.sot, lang, T.transcribe);
  const C = 4 * 1 * 448 * 1280;
  let kc = new ort.Tensor('float32', new Float32Array(C), [4, 1, 448, 1280]);
  let vc = new ort.Tensor('float32', new Float32Array(C), [4, 1, 448, 1280]);
  let offset = 0;
  let feed = init;
  const out = [];
  let sumLp = 0, noSpeechProb = 0;
  for (let step = 0; step < 224; step++) {
    const r = await S.dec.run({
      tokens: new ort.Tensor('int64', BigInt64Array.from(feed.map(BigInt)), [1, feed.length]),
      in_n_layer_self_k_cache: kc, in_n_layer_self_v_cache: vc, n_layer_cross_k: crossK, n_layer_cross_v: crossV,
      offset: new ort.Tensor('int64', BigInt64Array.from([BigInt(offset)]), [1]),
    });
    kc = r.out_n_layer_self_k_cache; vc = r.out_n_layer_self_v_cache;
    const all = r.logits.data, n = feed.length;
    if (step === 0) {
      const row = all.subarray(sotIdx * VOCAB, (sotIdx + 1) * VOCAB);
      const lse = logSoftmaxStats(row);
      noSpeechProb = Math.exp(row[T.noSpeech] - lse);
    }
    const lg = Float32Array.from(all.subarray((n - 1) * VOCAB, n * VOCAB));
    offset += n;
    // --- tokens prohibidos ---
    for (const t of NON_SPEECH) lg[t] = NEG;
    for (const t of [T.transcribe, T.translate, T.sot, T.sotPrev, T.sotLm, T.noSpeech, T.noTs]) lg[t] = NEG;
    for (let i = 0; i < NLANG; i++) lg[LANG0 + i] = NEG;
    if (!out.length) { lg[220] = NEG; lg[T.eot] = NEG; }
    // --- reglas de marcas de tiempo ---
    const lastTs = out.length >= 1 && out[out.length - 1] >= T.ts0;
    const prevTs = out.length < 2 || out[out.length - 2] >= T.ts0;
    if (lastTs) {
      if (prevTs) for (let i = T.ts0; i < VOCAB; i++) lg[i] = NEG; // después de un par, va texto
      else for (let i = 0; i < T.eot; i++) lg[i] = NEG; // después de una sola, otra marca o el final
    }
    const tss = out.filter((t) => t >= T.ts0);
    if (tss.length) {
      const lim = lastTs && !prevTs ? tss[tss.length - 1] : tss[tss.length - 1] + 1;
      for (let i = T.ts0; i < lim; i++) lg[i] = NEG;
    }
    if (!out.length) {
      for (let i = 0; i < T.ts0; i++) lg[i] = NEG; // empieza con una marca
      for (let i = T.ts0 + maxInitTs + 1; i < VOCAB; i++) lg[i] = NEG;
    }
    // si la probabilidad total de las marcas le gana al mejor texto, va marca
    const lse = logSoftmaxStats(lg);
    let tsMass = NEG, txtMax = NEG;
    { let mx = NEG; for (let i = T.ts0; i < VOCAB; i++) if (lg[i] > mx) mx = lg[i];
      if (mx > NEG) { let s = 0; for (let i = T.ts0; i < VOCAB; i++) if (lg[i] !== NEG) s += Math.exp(lg[i] - mx); tsMass = mx + Math.log(s) - lse; } }
    for (let i = 0; i < T.ts0; i++) if (lg[i] > txtMax) txtMax = lg[i];
    if (tsMass > txtMax - lse) for (let i = 0; i < T.ts0; i++) lg[i] = NEG;
    // --- elegir ---
    let tok;
    if (temperature > 0) {
      let mx = NEG; for (let i = 0; i < VOCAB; i++) if (lg[i] > mx) mx = lg[i];
      let s = 0; const pr = new Float64Array(VOCAB);
      for (let i = 0; i < VOCAB; i++) { pr[i] = lg[i] === NEG ? 0 : Math.exp((lg[i] - mx) / temperature); s += pr[i]; }
      let u = Math.random() * s; tok = 0;
      for (let i = 0; i < VOCAB; i++) { u -= pr[i]; if (u <= 0) { tok = i; break; } }
    } else {
      tok = 0; for (let i = 1; i < VOCAB; i++) if (lg[i] > lg[tok]) tok = i;
    }
    const lse2 = logSoftmaxStats(lg);
    sumLp += lg[tok] - lse2;
    if (tok === T.eot) break;
    out.push(tok);
    feed = [tok];
    if (offset >= 447) break;
  }
  return { tokens: out, avgLogprob: sumLp / Math.max(1, out.length + 1), noSpeechProb };
}

function compressionRatio(text) {
  const b = Buffer.from(text, 'utf8');
  if (!b.length) return 0;
  return b.length / zlib.deflateSync(b).length;
}

async function detectLanguage(S, crossK, crossV) {
  const C = 4 * 448 * 1280;
  const r = await S.dec.run({
    tokens: new ort.Tensor('int64', BigInt64Array.from([BigInt(T.sot)]), [1, 1]),
    in_n_layer_self_k_cache: new ort.Tensor('float32', new Float32Array(C), [4, 1, 448, 1280]),
    in_n_layer_self_v_cache: new ort.Tensor('float32', new Float32Array(C), [4, 1, 448, 1280]),
    n_layer_cross_k: crossK, n_layer_cross_v: crossV, offset: new ort.Tensor('int64', BigInt64Array.from([0n]), [1]),
  });
  const lg = r.logits.data;
  let best = 0;
  for (let i = 1; i < NLANG; i++) if (lg[LANG0 + i] > lg[LANG0 + best]) best = i;
  return LANGS[best];
}

// audio mono 16 kHz → segmentos [{ start, end, text }]
async function transcribeAudio(audio, { language = 'auto', onProgress } = {}) {
  const dir = modelDir();
  if (!dir) throw new Error('Falta el paquete Transcribir');
  loadVocab(dir);
  const S = await sessions(dir);
  const { mel, frames } = await logMel(audio);
  const content = frames - N_FRAMES;
  const win = new Float32Array(N_MELS * N_FRAMES);
  const segments = [];
  let seek = 0, prompt = [], lang = language && language !== 'auto' ? language : null;
  while (seek < content) {
    const size = Math.min(N_FRAMES, content - seek);
    // la ventana se completa con el log-mel del silencio agregado al final (como hace transformers),
    // no con ceros: con ceros el modelo turbo pierde mayúsculas y puntuación
    for (let m = 0; m < N_MELS; m++) win.set(mel.subarray(m * frames + seek, m * frames + seek + N_FRAMES), m * N_FRAMES);
    const e = await S.enc.run({ mel: new ort.Tensor('float32', win, [1, N_MELS, N_FRAMES]) });
    const crossK = e.n_layer_cross_k, crossV = e.n_layer_cross_v;
    if (!lang) lang = await detectLanguage(S, crossK, crossV);
    const langTok = LANG0 + Math.max(0, LANGS.indexOf(lang));
    let res = null, usedT = 0;
    for (const temp of [0, 0.2, 0.4, 0.6, 0.8, 1.0]) {
      res = await decodeWindow(S, crossK, crossV, { prompt, lang: langTok, temperature: temp });
      usedT = temp;
      const txt = decodeText(res.tokens);
      const bad = compressionRatio(txt) > 2.4 || res.avgLogprob < -1;
      const silent = res.noSpeechProb > 0.6 && res.avgLogprob < -1;
      if (process.env.WH_DEBUG) console.log('try', temp, res.avgLogprob.toFixed(3), compressionRatio(txt).toFixed(2), res.noSpeechProb.toFixed(3), JSON.stringify(txt.slice(0, 80)));
      if (!bad || silent) break;
    }
    const off = seek * 0.01;
    if (res.noSpeechProb > 0.6 && res.avgLogprob < -1) { seek += size; onProgress?.(Math.min(0.99, seek / content)); continue; }
    const tk = res.tokens;
    const isTs = tk.map((t) => t >= T.ts0);
    const singleEnd = tk.length >= 2 && !isTs[tk.length - 2] && isTs[tk.length - 1];
    const cons = [];
    for (let i = 1; i < tk.length; i++) if (isTs[i] && isTs[i - 1]) cons.push(i);
    const before = segments.length;
    if (cons.length) {
      const slices = [...cons];
      if (singleEnd) slices.push(tk.length);
      let last = 0;
      for (const cur of slices) {
        const part = tk.slice(last, cur);
        const a = (part[0] - T.ts0) * 0.02, b = (part[part.length - 1] - T.ts0) * 0.02;
        const text = decodeText(part).trim();
        if (text) segments.push({ start: off + a, end: off + b, text });
        last = cur;
      }
      if (singleEnd) seek += size;
      else seek += (tk[last - 1] - T.ts0) * 2;
    } else {
      let dur = size * 0.01;
      const tsl = tk.filter((t) => t >= T.ts0);
      if (tsl.length && tsl[tsl.length - 1] !== T.ts0) dur = (tsl[tsl.length - 1] - T.ts0) * 0.02;
      const text = decodeText(tk).trim();
      if (text) segments.push({ start: off, end: off + dur, text });
      seek += size;
    }
    // el texto nuevo sirve de contexto para la próxima ventana (salvo que haya salido "a la fuerza")
    prompt = usedT > 0.5 ? [] : prompt.concat(tk.filter((t) => t < T.eot)).slice(-223);
    for (let i = before; i < segments.length; i++) segments[i].end = Math.min(segments[i].end, audio.length / SR);
    onProgress?.(Math.min(0.99, seek / content));
  }
  return { segments: segments.filter((s) => s.end > s.start || s.text), language: lang };
}

// ---------------- salida ----------------
const pad2 = (n, w = 2) => String(n).padStart(w, '0');
function srtTime(t) {
  const ms = Math.max(0, Math.round(t * 1000));
  return `${pad2(Math.floor(ms / 3600000))}:${pad2(Math.floor(ms / 60000) % 60)}:${pad2(Math.floor(ms / 1000) % 60)},${pad2(ms % 1000, 3)}`;
}
// subtítulos cómodos: hasta 2 renglones de ~42 letras y ~6 s por subtítulo
function srtCues(segments) {
  const cues = [];
  for (const s of segments) {
    const words = s.text.split(/\s+/).filter(Boolean);
    const chunks = [];
    let cur = [];
    for (const w of words) {
      const len = cur.join(' ').length;
      if (cur.length && (len + 1 + w.length > 84 || (len > 50 && /[.,;:?!]$/.test(cur[cur.length - 1])))) { chunks.push(cur); cur = []; }
      cur.push(w);
    }
    if (cur.length) chunks.push(cur);
    const total = words.join(' ').length || 1;
    let t = s.start, acc = 0;
    for (const c of chunks) {
      const txt = c.join(' ');
      acc += txt.length + 1;
      const end = chunks.length === 1 ? s.end : s.start + (s.end - s.start) * Math.min(1, acc / total);
      cues.push({ start: t, end: Math.max(end, t + 0.4), text: twoLines(txt) });
      t = end;
    }
  }
  return cues;
}
function twoLines(t) {
  if (t.length <= 42) return t;
  const mid = t.length / 2;
  let best = -1;
  for (let i = 0; i < t.length; i++) if (t[i] === ' ' && (best < 0 || Math.abs(i - mid) < Math.abs(best - mid))) best = i;
  return best < 0 ? t : `${t.slice(0, best)}\n${t.slice(best + 1)}`;
}
const toSrt = (segments) => srtCues(segments).map((c, i) => `${i + 1}\n${srtTime(c.start)} --> ${srtTime(c.end)}\n${c.text}\n`).join('\n');
function toTxt(segments) {
  // párrafos: se corta cuando hay una pausa de más de 1,5 s
  const paras = [];
  let cur = '';
  let lastEnd = 0;
  for (const s of segments) {
    if (cur && s.start - lastEnd > 1.5) { paras.push(cur.trim()); cur = ''; }
    cur += (cur ? ' ' : '') + s.text;
    lastEnd = s.end;
  }
  if (cur.trim()) paras.push(cur.trim());
  return paras.join('\n\n') + '\n';
}

// archivo de audio o video → .txt / .srt al lado
// opts: { language: 'auto'|'es'|..., output: 'txt'|'srt'|'both', vocals: bool (sacar la voz antes: canciones), onProgress }
async function transcribeFile(file, opts = {}) {
  const av = require('./av');
  const out = opts.output || 'both';
  const p = opts.onProgress || (() => {});
  let audio;
  if (opts.vocals) {
    const [L, R] = await av.decodeStereo(file, 44100);
    const { separateRaw } = require('./stems');
    const { out: st } = await separateRaw(L, R, new Set(['vocals']), { quality: 'fast', onProgress: (x) => p(x * 0.3) });
    const [vl, vr] = st.vocals;
    const mono = new Float32Array(vl.length);
    for (let i = 0; i < mono.length; i++) mono[i] = 0.5 * (vl[i] + vr[i]);
    audio = await av.resampleMono(mono, 44100, SR);
  } else {
    audio = await av.decodeMono(file, SR);
  }
  const base = opts.vocals ? 0.3 : 0;
  const { segments, language } = await transcribeAudio(audio, { language: opts.language, onProgress: (x) => p(base + x * (1 - base)) });
  if (!segments.length) throw new Error('No encontré nada para transcribir (¿tiene voz?)');
  const dir = opts.outDir && fs.existsSync(opts.outDir) ? opts.outDir : path.dirname(file), name = path.basename(file, path.extname(file));
  const { uniquePath } = require('./ops');
  const files = [];
  if (out === 'txt' || out === 'both') { const f = uniquePath(dir, name, 'txt'); fs.writeFileSync(f, '﻿' + toTxt(segments)); files.push(f); }
  if (out === 'srt' || out === 'both') { const f = uniquePath(dir, name, 'srt'); fs.writeFileSync(f, toSrt(segments)); files.push(f); }
  p(1);
  return { files, language, segments };
}

module.exports = { transcribeFile, transcribeAudio, available, modelDir, installDir, setPackDir, FILES, LANG_NAMES, _test: { logMel, melFilters, fft, toSrt, toTxt } };
