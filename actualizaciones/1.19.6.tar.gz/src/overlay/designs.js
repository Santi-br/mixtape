/* global window, document */
// Diseño de la rueda: Carrusel (29). La rueda clásica queda en overlay.js como respaldo.
// Cada diseño expone: mount(root), build(ctx), hit(x, y), setHot(item), setHub(label, sub, cancel), backdrop(bd)
// ctx = { kind, count, formats, actions, icons }  (items con { id, label, icon, ring, off })
(() => {
  const H = (tag, cls, parent, html) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    if (parent) parent.appendChild(e);
    return e;
  };
  const SVGNS = 'http://www.w3.org/2000/svg';
  const icon = (d, size = 20) => `<svg class="ico" width="${size}" height="${size}" viewBox="0 0 24 24" aria-hidden="true"><path d="${d || ''}"/></svg>`;
  const inRect = (x, y, r) => x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  // ---------- vidrio: cada panel lleva su propia copia desenfocada de lo que hay detrás ----------
  let BD = null;
  function glassify(el) {
    el.classList.add('gl');
    if (!el.querySelector(':scope > .bdl')) el.prepend(H('i', 'bdl'), H('i', 'tnt'));
  }
  // posición del panel dentro de la ventana, sin contar transforms (offsetLeft/Top)
  function offsetIn(el) {
    let x = 0, y = 0, n = el;
    while (n && n !== document.body) { x += n.offsetLeft; y += n.offsetTop; n = n.offsetParent; }
    return [x, y];
  }
  // ox/oy opcionales: posición conocida del panel (si se está moviendo con transición)
  function paintOne(el, ox, oy) {
    const l = el.querySelector(':scope > .bdl');
    if (!l) return;
    if (!BD) { l.style.backgroundImage = ''; return; }
    if (ox == null) [ox, oy] = offsetIn(el);
    Object.assign(l.style, {
      backgroundImage: `url("${BD.dataUrl}")`, left: `${BD.x - ox}px`, top: `${BD.y - oy}px`, width: `${BD.w}px`, height: `${BD.h}px`,
    });
  }
  function paintGlass(root) { for (const el of root.querySelectorAll('.gl')) paintOne(el); }

  const kindGlyph = { image: 'IMG', pdf: 'PDF', audio: '♪', video: '▶', mix: '▶♪', docs: 'PDF', other: '…', link: '↓' };

  // =====================================================================
  // 29 · Carrusel
  // =====================================================================
  const carrusel = {
    root: null, cards: [], chips: [], ctx: null, idx: 0,
    mount(root) {
      this.root = root;
      root.innerHTML = '';
      this.strip = H('div', 'c-strip', root);
      this.dots = H('div', 'c-dots', root);
      this.pill = H('div', 'c-pill', root); glassify(this.pill);
      this.thumb = H('div', 'c-thumb', this.pill);
      const txt = H('div', 'c-ptxt', this.pill);
      this.hl = H('b', '', txt); this.hs = H('span', '', txt);
      this.fbar = H('div', 'c-fbar', root); glassify(this.fbar);
      this.hint = H('div', 'c-hint', root, 'mové a los costados para pasar');
    },
    build(ctx) {
      this.ctx = ctx;
      this.strip.textContent = '';
      this.dots.textContent = '';
      this.cards = ctx.actions.map((it) => {
        const c = H('div', `c-card${it.off ? ' off' : ''}`, this.strip, icon(ctx.icons[it.icon], 30) + `<span>${it.label}</span>`);
        glassify(c);
        it.node = c;
        it.dot = H('i', '', this.dots);
        return it;
      });
      this.idx = Math.floor((ctx.actions.length - 1) / 2);
      this.thumb.textContent = kindGlyph[ctx.kind] || '';
      this.thumb.className = `c-thumb k-${ctx.kind}`;
      // chips de formatos
      const bar = this.fbar;
      [...bar.querySelectorAll('.c-chip')].forEach((n) => n.remove());
      this.chips = ctx.formats.map((it) => { const ch = H('span', `c-chip${it.off ? ' off' : ''}`, bar, it.label); it.node = ch; return it; });
      bar.style.visibility = ctx.formats.length ? '' : 'hidden'; // sin formatos (p. ej. solo Renombrar): sin barra
      this.layout(null);
      this.center();
      // rectángulos de los chips en coordenadas de la ventana
      for (const it of this.chips) it.rect = { x: this.fbar.offsetLeft + it.node.offsetLeft - 3, y: 236, w: it.node.offsetWidth + 6, h: 60 };
      paintGlass(this.root);
      this.hotItem = null;
      this.layout(null);
      this.hint.style.display = ctx.actions.length > 1 ? '' : 'none';
    },
    center() {
      for (const el of [this.pill, this.fbar]) el.style.left = `${Math.round((440 - el.offsetWidth) / 2)}px`;
    },
    layout(hotItem) {
      const n = this.cards.length;
      const X = [0, 106, 180, 228], S = [1, 0.8, 0.64, 0.54], O = [1, 0.85, 0.5, 0.25];
      this.cards.forEach((it, i) => {
        const k = i - this.idx, a = Math.abs(k);
        const x = 220 + Math.sign(k) * (X[Math.min(a, 3)] + (a > 3 ? 30 : 0));
        paintOne(it.node, x - 56, 22);
        Object.assign(it.node.style, {
          left: `${x - 56}px`, transform: `scale(${S[Math.min(a, 3)]})`,
          opacity: a > 3 ? 0 : 1, zIndex: 10 - a,
        });
        // el vidrio queda opaco; lo que se atenúa es el contenido (si no, se ve el fondo nítido a través)
        it.node.style.setProperty('--co', a > 3 ? 0 : (it.off ? 0.4 : 1) * O[a]);
        it.node.classList.toggle('front', k === 0 && hotItem === it);
        it.dot.classList.toggle('on', i === this.idx);
      });
      this.dots.style.display = n > 1 ? '' : 'none';
    },
    hit(x, y) {
      const n = this.cards.length;
      if (y < 182 && n) {
        const s = Math.min(64, 400 / n), x0 = 220 - (n * s) / 2;
        const i = clamp(Math.floor((x - x0) / s), 0, n - 1);
        if (i !== this.idx) { this.idx = i; this.layout(this.hotItem); }
        return { item: this.cards[i] };
      }
      if (inRect(x, y, { x: 40, y: 186, w: 360, h: 48 })) return { cancel: true };
      for (const it of this.chips) if (it.rect && inRect(x, y, it.rect)) return { item: it };
      return {};
    },
    setHot(prev, next) {
      prev?.node?.classList.remove('hot');
      next?.node?.classList.add('hot');
      this.hotItem = next;
      this.layout(next);
    },
    setHub(label, sub, cancel) {
      this.hl.textContent = label;
      this.hs.textContent = cancel ? 'soltá acá para cancelar' : sub;
      this.pill.classList.toggle('cancel', !!cancel);
      this.center();
      paintOne(this.pill);
    },
    backdrop(bd) { BD = bd; if (this.root) requestAnimationFrame(() => { paintGlass(this.root); this.layout(this.hotItem); }); },
  };

  window.ALT_DESIGNS = { carrusel };
})();
