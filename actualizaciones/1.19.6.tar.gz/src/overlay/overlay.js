/* global ruedita */
const C = 200;
const HUB_R = 46;
const RINGS = { format: [54, 116], action: [124, 182] };
const SVGNS = 'http://www.w3.org/2000/svg';
const EDGE = 14;      // ancho del borde que refracta (px)
const LENS_SCALE = 44; // tiene que coincidir con scale del feDisplacementMap

const MIME_EXT = {
  'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/avif': 'avif',
  'image/gif': 'gif', 'image/tiff': 'tiff', 'image/bmp': 'bmp', 'application/pdf': 'pdf',
  'audio/mpeg': 'mp3', 'audio/mp3': 'mp3', 'audio/wav': 'wav', 'audio/x-wav': 'wav', 'audio/wave': 'wav',
  'audio/flac': 'flac', 'audio/x-flac': 'flac', 'audio/mp4': 'm4a', 'audio/x-m4a': 'm4a', 'audio/ogg': 'ogg',
  'audio/aiff': 'aiff', 'audio/x-aiff': 'aiff', 'video/mp4': 'mp4', 'video/quicktime': 'mov', 'video/webm': 'webm',
  'video/mpeg': 'mpeg', 'video/x-mpeg': 'mpeg', 'video/mp2t': 'ts', 'video/vnd.dlna.mpeg-tts': 'm2ts', 'video/x-matroska': 'mkv',
  'video/x-msvideo': 'avi', 'video/avi': 'avi', 'video/x-ms-wmv': 'wmv', 'video/x-flv': 'flv', 'video/3gpp': '3gp', 'video/ogg': 'ogv',
};

const ICONS = {
  compress: 'M4 4l5 5M9 5v4H5M20 20l-5-5M15 19v-4h4M20 4l-5 5M15 5v4h4M4 20l5-5M5 15h4v4',
  crop: 'M6 2v16h16M2 6h16v16',
  text: 'M4 6V4h16v2M12 4v16M9 20h6M17 13h4M17 17h4',
  trim: 'M6 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM20 4L8.12 15.88M14.47 14.48L20 20M8.12 8.12L12 12',
  resize: 'M14 4h6v6M20 4l-7 7M10 20H4v-6M4 20l7-7',
  vedit: 'M3 5h18v9H3zM7.5 5v9M16.5 5v9M3 18.5h7M13 18.5h8M11.5 16.5v4',
  rmbg: 'M12 6.2a2.6 2.6 0 1 1 0 5.2 2.6 2.6 0 0 1 0-5.2zM7.2 17.6c.7-2.6 2.6-4 4.8-4s4.1 1.4 4.8 4M3 7.5V4h3.5M21 7.5V4h-3.5M3 16.5V20h3.5M21 16.5V20h-3.5',
  background: 'M3 7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v10a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4zM8 8h8v8H8z',
  upscale: 'M11 3l1.8 4.7 4.7 1.8-4.7 1.8L11 16l-1.8-4.7L4.5 9.5l4.7-1.8zM18.5 14l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9z',
  blur: 'M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18M8 8.5h.01M12 8.5h.01M16 8.5h.01M8 12h.01M12 12h.01M16 12h.01M8 15.5h.01M12 15.5h.01M16 15.5h.01',
  stems: 'M4 6h16M4 12h16M4 18h16M8 4v4M15 10v4M11 16v4',
  vocal: 'M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3zM5 11a7 7 0 0 0 14 0M12 18v3',
  normalize: 'M3 12h1M7 8v8M11 4v16M15 8v8M19 10v4M21 12h0',
  mute: 'M4 9h4l5-4v14l-5-4H4zM17 9l4 6M21 9l-4 6',
  keybpm: 'M9 3h6l4 18H5zM12 17l5-10M8.5 13h7',
  midi: 'M3 6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM8 4v10M12 4v16M16 4v10M8 14v6M16 14v6',
  sliders: 'M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M14 4v4M8 10v4M16 16v4',
  rename: 'M3 7h9M3 12h6M3 17h9M16 5v14M13.5 5h5M13.5 19h5',
  rotate: 'M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5',
  strip: 'M3 12l8.5-8.5H20V12l-8.5 8.5zM15.5 8.5h.01M4 20L20 4',
  merge: 'M5 4v4a4 4 0 0 0 4 4h6a4 4 0 0 1 4 4v4M19 4v4a4 4 0 0 1-4 4M16 17l3 3 3-3',
  split: 'M12 3v7M12 10l-6 6v5M12 10l6 6v5M3 18l3 3 3-3M15 18l3 3 3-3',
};

let catalog = null;
let design = { id: 'rueda', w: 400, h: 400, ax: 200, ay: 200 };
let alt = null; // diseño alternativo activo (designs.js) o null para la rueda clásica
const box = () => (alt ? $('alt') : $('wheel'));
let current = { kind: null, items: [], count: 0, exts: [] };
let hot = null;

const $ = (id) => document.getElementById(id);
const rad = (d) => (d - 90) * Math.PI / 180;
const pt = (r, d) => [C + r * Math.cos(rad(d)), C + r * Math.sin(rad(d))];

function el(tag, attrs, parent) {
  const e = document.createElementNS(SVGNS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (parent) parent.appendChild(e);
  return e;
}

// ---------- forma del vidrio: centro + 2 anillos flotando separados ----------
const circle = (r) => `M${C - r} ${C}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0Z`;
const GLASS = [circle(HUB_R), circle(RINGS.format[1]), circle(RINGS.format[0]), circle(RINGS.action[1]), circle(RINGS.action[0])].join('');

function setupGlass() {
  for (const id of ['clipShape', 'shadow', 'tint', 'innerGlow', 'rimPath']) $(id).setAttribute('d', GLASS);
  $('clipShape').setAttribute('clip-rule', 'evenodd');
  $('lensMap').setAttribute('href', lensMap());
}

// Mapa de desplazamiento: cerca de cada borde, el vidrio "trae" lo que hay un poco más afuera,
// como el canto grueso de una lente. R/G = desplazamiento x/y (128 = nada).
function lensMap() {
  const N = 400;
  const cv = document.createElement('canvas');
  cv.width = cv.height = N;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(N, N);
  const shapes = [[0, HUB_R], RINGS.format, RINGS.action];
  const maxShift = LENS_SCALE / 2;
  for (let y = 0; y < N; y++) {
    for (let x = 0; x < N; x++) {
      const dx = x + 0.5 - C, dy = y + 0.5 - C;
      const r = Math.hypot(dx, dy) || 1e-6;
      let ox = 0, oy = 0;
      for (const [r0, r1] of shapes) {
        if (r < r0 || r > r1) continue;
        const dOut = r1 - r, dIn = r0 > 0 ? r - r0 : Infinity;
        const d = Math.min(dOut, dIn);
        if (d < EDGE) {
          const t = 1 - d / EDGE;
          const f = t * t * (3 - 2 * t) * 0.9; // curva suave
          const dir = dOut <= dIn ? 1 : -1; // hacia el borde más cercano
          ox = (dx / r) * dir * f * maxShift;
          oy = (dy / r) * dir * f * maxShift;
        }
        break;
      }
      const i = (y * N + x) * 4;
      img.data[i] = Math.round(128 + (ox / maxShift) * 127);
      img.data[i + 1] = Math.round(128 + (oy / maxShift) * 127);
      img.data[i + 2] = 128;
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return cv.toDataURL('image/png');
}

// ---------- items ----------
function layoutRing(ringName, list) {
  const [r0, r1] = RINGS[ringName];
  const step = 360 / list.length;
  return list.map((item, i) => {
    const mid = i * step;
    return { ...item, ring: ringName, r0, r1, a0: mid - step / 2, a1: mid + step / 2, mid, step };
  });
}

function build(kind, count, exts) {
  if (!catalog) return;
  const def = catalog[kind] || catalog.image;
  const onlyExt = !['mix', 'link', 'docs'].includes(kind) && exts.length && exts.every((e) => e === exts[0]) ? exts[0] : null;
  const formats = def.formats.filter((f) => !(onlyExt && (f.id === onlyExt || (f.id === 'jpg' && onlyExt === 'jpeg'))));
  const actions = def.actions.map((a) => ({ ...a, off: a.multi && count < 2 }));
  if (alt) {
    const fs = formats.map((f) => ({ ...f, ring: 'format' })), as = actions.map((a) => ({ ...a, ring: 'action' }));
    current = { kind, items: [...fs, ...as], count, exts };
    alt.build({ kind, count, formats: fs, actions: as, icons: ICONS });
    hot = null;
    setHub(null);
    return;
  }
  const items = [...layoutRing('format', formats), ...layoutRing('action', actions)];
  current = { kind, items, count, exts };

  const g = $('items');
  g.textContent = '';
  for (const it of items) {
    const node = el('g', { class: `item ${it.ring === 'action' ? 'act' : 'fmt'}${it.off ? ' off' : ''}` }, g);
    const [tx, ty] = pt((it.r0 + it.r1) / 2, it.mid);
    if (it.ring === 'action') {
      el('path', { class: 'ico', d: ICONS[it.icon] || '', transform: `translate(${tx - 10} ${ty - 19}) scale(0.84)`, 'vector-effect': 'non-scaling-stroke' }, node);
      el('text', { x: tx, y: ty + 15, 'text-anchor': 'middle' }, node).textContent = it.label;
    } else {
      el('text', { x: tx, y: ty + 5, 'text-anchor': 'middle' }, node).textContent = it.label;
    }
    it.node = node;
  }
  hot = null;
  pill.target = null;
  $('pill').classList.remove('on');
  setHub(null);
}

// ---------- burbuja de selección (se desliza entre opciones) ----------
const pill = { r: 0, a0: 0, a1: 0, w: 0, target: null, raf: 0 };

function pillTarget(it) {
  const w = it.r1 - it.r0 - 10;
  const r = (it.r0 + it.r1) / 2;
  const capDeg = ((w / 2) / r) * 180 / Math.PI;
  const span = Math.max(0, it.step - 2 * capDeg - 5);
  return { r, w, a0: it.mid - span / 2, a1: it.mid + span / 2 };
}

function pillPath(p) {
  const [x0, y0] = pt(p.r, p.a0), [x1, y1] = pt(p.r, p.a1);
  if (p.a1 - p.a0 < 0.01) return `M${x0} ${y0}L${x0 + 0.01} ${y0}`;
  return `M${x0} ${y0}A${p.r} ${p.r} 0 ${p.a1 - p.a0 > 180 ? 1 : 0} 1 ${x1} ${y1}`;
}

function animatePill() {
  const t = pill.target;
  if (!t) { pill.raf = 0; return; }
  const k = 0.28;
  pill.r += (t.r - pill.r) * k;
  pill.w += (t.w - pill.w) * k;
  pill.a0 += (t.a0 - pill.a0) * k;
  pill.a1 += (t.a1 - pill.a1) * k;
  const p = $('pill');
  p.setAttribute('d', pillPath(pill));
  p.setAttribute('stroke-width', pill.w);
  const done = Math.abs(t.a0 - pill.a0) < 0.05 && Math.abs(t.a1 - pill.a1) < 0.05 && Math.abs(t.r - pill.r) < 0.05 && Math.abs(t.w - pill.w) < 0.05;
  pill.raf = done ? 0 : requestAnimationFrame(animatePill);
}

function movePill(it) {
  const p = $('pill');
  if (!it) { p.classList.remove('on'); pill.target = null; return; }
  const t = pillTarget(it);
  if (p.classList.contains('on') && pill.target) {
    // camino angular más corto
    const shift = Math.round(((pill.a0 + pill.a1) / 2 - it.mid) / 360) * 360;
    t.a0 += shift; t.a1 += shift;
  } else {
    // aparece desde el centro del item
    Object.assign(pill, { r: t.r, w: t.w * 0.6, a0: it.mid, a1: it.mid });
  }
  pill.target = t;
  p.classList.add('on');
  if (!pill.raf) pill.raf = requestAnimationFrame(animatePill);
}

function setHot(item) {
  const next = item && !item.off ? item : null;
  if (hot === next) return;
  if (alt) { const prev = hot; hot = next; alt.setHot(prev, next); return; }
  if (hot?.node) hot.node.classList.remove('hot');
  hot = next;
  if (hot?.node) hot.node.classList.add('hot');
  movePill(hot);
}

function setHub(item, cancel) {
  document.body.classList.toggle('cancel', !!cancel);
  let l, s;
  if (cancel) { l = 'Cancelar'; s = 'soltá acá'; }
  else if (item) {
    l = item.ring === 'format' && !['mix', 'link'].includes(current.kind) ? `a ${item.label}` : item.label;
    s = item.off ? 'arrastrá 2 o más' : (current.count > 1 ? `${current.count} archivos` : '');
  } else {
    l = { pdf: 'PDF', image: 'Imagen', audio: 'Audio', video: 'Video', mix: 'Video + audio', docs: 'Imágenes + PDF', other: 'Archivos', link: 'Descargar' }[current.kind] || 'MIXTAPE';
    s = current.count > 1 ? `${current.count} archivos` : 'elegí';
  }
  if (alt) { alt.setHub(l, s, cancel); return; }
  $('hubLabel').textContent = l;
  $('hubSub').textContent = s;
}

function hitTest(x, y) {
  if (alt) return alt.hit(x, y);
  const dx = x - C, dy = y - C;
  const r = Math.hypot(dx, dy);
  if (r < HUB_R + 4) return { cancel: true };
  if (r > RINGS.action[1] + 6) return {};
  const a = Math.atan2(dy, dx) * 180 / Math.PI + 90;
  // el espacio entre anillos cuenta para el anillo más cercano
  const ring = r < (RINGS.format[1] + RINGS.action[0]) / 2 ? 'format' : 'action';
  for (const it of current.items) {
    if (it.ring !== ring) continue;
    let aa = a;
    while (aa < it.a0) aa += 360;
    while (aa >= it.a0 + 360) aa -= 360;
    if (aa < it.a1) return { item: it };
  }
  return {};
}

const isLinkDrag = (dt) => !![...(dt?.items || [])].every((i) => i.kind !== 'file') && [...(dt?.types || [])].includes('text/uri-list');
function readDrag(dt) {
  if (isLinkDrag(dt)) return { kind: 'link', count: 1, exts: [] };
  const files = [...(dt?.items || [])].filter((i) => i.kind === 'file');
  const types = files.map((i) => i.type);
  // el tipo lo decide el primer archivo
  const t0 = types.find(Boolean) || '';
  let kind = null;
  if (t0 === 'application/pdf') kind = 'pdf';
  else if (t0.startsWith('image/')) kind = 'image';
  else if (t0.startsWith('audio/')) kind = 'audio';
  else if (t0.startsWith('video/')) kind = 'video';
  if (types.some((t) => t.startsWith('video/')) && types.some((t) => t.startsWith('audio/'))) kind = 'mix';
  if (types.includes('application/pdf') && types.some((t) => t.startsWith('image/'))) kind = 'docs';
  // tipo desconocido pero informado (zip, docx…): solo Renombrar; sin tipo, como antes
  return { kind: kind || (t0 ? 'other' : 'image'), count: files.length || 1, exts: types.map((t) => MIME_EXT[t]).filter(Boolean) };
}

let armed = false;
function onDragOver(e) {
  e.preventDefault();
  if (armed) {
    const hasFiles = [...(e.dataTransfer?.items || [])].some((i) => i.kind === 'file');
    if (!hasFiles && !isLinkDrag(e.dataTransfer)) return;
    armed = false;
    ruedita.send('overlay-active');
    requestAnimationFrame(() => box().classList.remove('hidden'));
  }
  const info = readDrag(e.dataTransfer);
  if (info.kind !== current.kind || info.count !== current.count || info.exts.join() !== current.exts.join()) build(info.kind, info.count, info.exts);
  const h = hitTest(e.clientX, e.clientY);
  if (h.item && !h.item.off) {
    setHot(h.item); setHub(h.item);
    e.dataTransfer.dropEffect = 'copy'; // nunca "mover": el original no se toca
  } else {
    setHot(null);
    setHub(h.item || null, h.cancel);
    e.dataTransfer.dropEffect = 'none';
  }
}

document.addEventListener('dragenter', onDragOver);
document.addEventListener('dragover', onDragOver);
document.addEventListener('dragleave', (e) => {
  if (e.relatedTarget) return;
  setHot(null); setHub(null);
});
document.addEventListener('drop', (e) => {
  e.preventDefault();
  const h = hitTest(e.clientX, e.clientY);
  if (current.kind === 'link') {
    setHot(null);
    const url = (e.dataTransfer.getData('text/uri-list') || e.dataTransfer.getData('text/plain') || '').split(/\r?\n/).find((l) => /^https?:/i.test(l.trim()));
    if (!h.item || !url) { ruedita.send('overlay-cancel'); return; }
    ruedita.send('drop', { paths: [], urls: [url.trim()], ring: h.item.ring, id: h.item.id });
    return;
  }
  const files = [...(e.dataTransfer?.files || [])];
  setHot(null);
  if (!h.item || h.item.off || !files.length) { ruedita.send('overlay-cancel'); return; }
  const paths = files.map((f) => ruedita.pathFor(f)).filter(Boolean);
  ruedita.send('drop', { paths, ring: h.item.ring, id: h.item.id });
});

// fondo real (captura de lo que hay debajo)
ruedita.on('backdrop', (bd) => {
  if (!bd) { document.body.classList.remove('has-bd'); return; }
  const img = $('bd');
  img.setAttribute('href', bd.dataUrl);
  img.setAttribute('x', bd.x);
  img.setAttribute('y', bd.y);
  img.setAttribute('width', bd.w);
  img.setAttribute('height', bd.h);
  document.body.classList.toggle('tone-dark', bd.tone === 'dark');
  document.body.classList.toggle('tone-light', bd.tone !== 'dark');
  document.body.classList.add('has-bd');
  alt?.backdrop(bd);
});

ruedita.on('show', () => {
  setHot(null);
  build('image', 1, []);
  current.kind = null; // se recalcula con el primer dragover
  document.body.classList.remove('has-bd', 'tone-dark', 'cancel');
  document.body.classList.add('tone-light');
  alt?.backdrop(null);
  // invisible hasta el primer dragover: si no es un archivo (ej. Shift+clic o selección), nunca se ve
  box().classList.add('hidden');
  armed = true;
});
ruedita.on('hide', () => { armed = false; box().classList.add('hidden'); setHot(null); });
// ---------- diseño elegido en la bandeja ----------
function applyDesign(d) {
  if (!d) return;
  design = d;
  hot = null;
  alt = d.id !== 'rueda' ? (window.ALT_DESIGNS || {})[d.id] || null : null;
  for (const n of [document.documentElement, document.body]) { n.style.width = `${d.w}px`; n.style.height = `${d.h}px`; }
  document.body.className = document.body.className.replace(/\bd-\S+/g, '').trim();
  document.body.classList.add(`d-${alt ? d.id : 'rueda'}`);
  $('wheel').style.display = alt ? 'none' : '';
  const a = $('alt');
  a.style.display = alt ? '' : 'none';
  a.classList.add('hidden');
  $('wheel').classList.add('hidden');
  if (alt) {
    a.className = 'hidden';
    a.style.transformOrigin = `${d.ax}px ${d.ay}px`;
    alt.mount(a);
    if (alt.setDisc) alt.setDisc(d.disc);
  }
  current.kind = null;
  if (catalog) { build('image', 1, []); current.kind = null; }
}
ruedita.on('design', applyDesign);

setupGlass();
Promise.all([ruedita.invoke('catalog'), ruedita.invoke('design')]).then(([c, d]) => {
  catalog = c;
  applyDesign(d);
  build('image', 1, []); current.kind = null;
});

// ---------- diagnóstico (Mac) ----------
if (/Mac/.test(navigator.platform)) document.body.classList.add('mac');
let diagOn = false;
const diagLast = {};
ruedita.on('diag', (on) => { diagOn = on; document.body.classList.toggle('diag', on); });
for (const t of ['dragenter', 'dragover', 'drop', 'mousemove', 'mouseenter', 'mousedown', 'pointermove']) {
  window.addEventListener(t, () => {
    if (!diagOn) return;
    const now = Date.now();
    if (now - (diagLast[t] || 0) < 150) return;
    diagLast[t] = now;
    ruedita.send('diag-ev', t);
  }, true);
}
