// FFT / STFT para el separador de stems (equivalente a torch.stft / torch.istft con center=True).
const FFT = require('fft.js');

const isPow2 = (n) => (n & (n - 1)) === 0;
const nextPow2 = (n) => 1 << Math.ceil(Math.log2(n));

// DFT compleja de tamaño n (cualquier n). Datos intercalados [re, im, re, im, ...].
// fft.js para potencias de 2, Bluestein para el resto (ej. 7680).
function makeDFT(n) {
  if (isPow2(n)) {
    const f = new FFT(n);
    const out = f.createComplexArray();
    return {
      forward(data) { f.transform(out, data); return out; },
      // inversa SIN normalizar (se normaliza afuera)
      inverse(data) { f.inverseTransform(out, data); for (let i = 0; i < out.length; i++) out[i] *= n; return out; },
    };
  }
  const M = nextPow2(2 * n - 1);
  const f = new FFT(M);
  const wr = new Float64Array(n), wi = new Float64Array(n);
  for (let k = 0; k < n; k++) {
    const a = (Math.PI * ((k * k) % (2 * n))) / n;
    wr[k] = Math.cos(a); wi[k] = -Math.sin(a); // w_k = e^{-iπk²/n}
  }
  // b = conj(w) simétrico, y su FFT
  const b = f.createComplexArray();
  for (let k = 0; k < n; k++) {
    b[2 * k] = wr[k]; b[2 * k + 1] = -wi[k];
    if (k > 0) { b[2 * (M - k)] = wr[k]; b[2 * (M - k) + 1] = -wi[k]; }
  }
  const B = f.createComplexArray();
  f.transform(B, b);
  const a = f.createComplexArray(), A = f.createComplexArray(), c = f.createComplexArray();
  const out = new Float64Array(2 * n);

  function dft(data, sign) {
    // sign = +1 directa, -1 inversa (vía conjugados)
    a.fill(0);
    for (let k = 0; k < n; k++) {
      const xr = data[2 * k], xi = sign * data[2 * k + 1];
      a[2 * k] = xr * wr[k] - xi * wi[k];
      a[2 * k + 1] = xr * wi[k] + xi * wr[k];
    }
    f.transform(A, a);
    for (let k = 0; k < M; k++) {
      const ar = A[2 * k], ai = A[2 * k + 1], br = B[2 * k], bi = B[2 * k + 1];
      A[2 * k] = ar * br - ai * bi;
      A[2 * k + 1] = ar * bi + ai * br;
    }
    f.inverseTransform(c, A); // incluye 1/M
    for (let k = 0; k < n; k++) {
      const cr = c[2 * k], ci = c[2 * k + 1];
      out[2 * k] = cr * wr[k] - ci * wi[k];
      out[2 * k + 1] = sign * (cr * wi[k] + ci * wr[k]);
    }
    return out;
  }
  return { forward: (d) => dft(d, 1), inverse: (d) => dft(d, -1) };
}

const cache = new Map();
function plan(nfft) {
  if (cache.has(nfft)) return cache.get(nfft);
  const win = new Float64Array(nfft);
  for (let i = 0; i < nfft; i++) win[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / nfft); // hann periódica
  const p = { dft: makeDFT(nfft), win, buf: new Float64Array(2 * nfft) };
  cache.set(nfft, p);
  return p;
}

// STFT de un chunk estéreo (L, R de largo `len`), center=True con reflect.
// Escribe en `dst` (Float32Array [4, dimF, T]) los canales L_re, L_im, R_re, R_im.
function stftStereo(L, R, nfft, hop, dimF, T, dst, t0 = 0, scale = 1) {
  const { dft, win, buf } = plan(nfft);
  const half = nfft / 2, len = L.length;
  const at = (x, i) => { // reflect padding
    if (i < 0) i = -i;
    if (i >= len) i = 2 * (len - 1) - i;
    return x[i];
  };
  const plane = dimF * T;
  for (let t = 0; t < T; t++) {
    const start = (t + t0) * hop - half;
    for (let i = 0; i < nfft; i++) {
      const w = win[i] * scale;
      buf[2 * i] = at(L, start + i) * w; // L como real
      buf[2 * i + 1] = at(R, start + i) * w; // R como imaginaria
    }
    const Z = dft.forward(buf);
    for (let k = 0; k < dimF; k++) {
      const nk = k === 0 ? 0 : nfft - k;
      const zr = Z[2 * k], zi = Z[2 * k + 1], cr = Z[2 * nk], ci = -Z[2 * nk + 1];
      const o = k * T + t;
      dst[o] = (zr + cr) / 2;                // L re
      dst[plane + o] = (zi + ci) / 2;        // L im
      dst[2 * plane + o] = (zi - ci) / 2;    // R re
      dst[3 * plane + o] = -(zr - cr) / 2;   // R im
    }
  }
}

// iSTFT inversa de stftStereo (bins >= dimF en cero). Devuelve [L, R] de largo hop*(T-1).
function istftStereo(spec, nfft, hop, dimF, T) {
  const { dft, win, buf } = plan(nfft);
  const half = nfft / 2;
  const total = nfft + hop * (T - 1);
  const yl = new Float64Array(total), yr = new Float64Array(total), env = new Float64Array(total);
  const plane = dimF * T;
  for (let t = 0; t < T; t++) {
    buf.fill(0);
    // Z_k = L_k + i R_k, con simetría hermitiana de L y R
    for (let k = 0; k < dimF; k++) {
      const o = k * T + t;
      const lr = spec[o], li = spec[plane + o], rr = spec[2 * plane + o], ri = spec[3 * plane + o];
      if (k === 0 || 2 * k === nfft) { buf[2 * k] = lr; buf[2 * k + 1] = rr; continue; } // DC y Nyquist: solo parte real (como irfft)
      buf[2 * k] = lr - ri; buf[2 * k + 1] = li + rr;
      const m = nfft - k; buf[2 * m] = lr + ri; buf[2 * m + 1] = -li + rr;
    }
    const z = dft.inverse(buf);
    const base = t * hop;
    for (let i = 0; i < nfft; i++) {
      const w = win[i];
      yl[base + i] += (z[2 * i] / nfft) * w;
      yr[base + i] += (z[2 * i + 1] / nfft) * w;
      env[base + i] += w * w;
    }
  }
  const outLen = hop * (T - 1);
  const L = new Float32Array(outLen), R = new Float32Array(outLen);
  for (let i = 0; i < outLen; i++) {
    const e = env[half + i];
    const d = e > 1e-11 ? e : 1;
    L[i] = yl[half + i] / d; R[i] = yr[half + i] / d;
  }
  return [L, R];
}

module.exports = { stftStereo, istftStereo, makeDFT };
