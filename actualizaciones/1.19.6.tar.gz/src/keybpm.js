// Detector de tonalidad (key) y tempo (BPM).
// Key: notas de Basic Pitch → cromagrama (los graves pesan más) → perfiles de tonalidad
// (Krumhansl + Temperley) + qué acorde "es casa" (el de la tónica). BPM: src/midi/tempo.
const av = require('./av');

const PC_SHARP = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const MAJ_NAME = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const MIN_NAME = ['Cm', 'C#m', 'Dm', 'Ebm', 'Em', 'Fm', 'F#m', 'Gm', 'G#m', 'Am', 'Bbm', 'Bm'];
const ES = { C: 'Do', 'C#': 'Do#', Db: 'Re♭', D: 'Re', 'D#': 'Re#', Eb: 'Mi♭', E: 'Mi', F: 'Fa', 'F#': 'Fa#', G: 'Sol', 'G#': 'Sol#', Ab: 'La♭', A: 'La', 'A#': 'La#', Bb: 'Si♭', B: 'Si' };
// rueda de Camelot (la que usan Rekordbox, Mixed In Key, Serato)
const CAMELOT_MAJ = { 0: '8B', 7: '9B', 2: '10B', 9: '11B', 4: '12B', 11: '1B', 6: '2B', 1: '3B', 8: '4B', 3: '5B', 10: '6B', 5: '7B' };
const CAMELOT_MIN = { 9: '8A', 4: '9A', 11: '10A', 6: '11A', 1: '12A', 8: '1A', 3: '2A', 10: '3A', 5: '4A', 0: '5A', 7: '6A', 2: '7A' };

const PROFILES = [
  // Krumhansl-Kessler
  [[6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88], [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]],
  // Temperley (Kostka-Payne)
  [[0.748, 0.060, 0.488, 0.082, 0.670, 0.460, 0.096, 0.715, 0.104, 0.366, 0.057, 0.400], [0.712, 0.084, 0.474, 0.618, 0.049, 0.460, 0.105, 0.747, 0.404, 0.067, 0.133, 0.330]],
];

function pearson(a, b) {
  const n = a.length; let ma = 0, mb = 0;
  for (let i = 0; i < n; i++) { ma += a[i]; mb += b[i]; }
  ma /= n; mb /= n;
  let num = 0, da = 0, db = 0;
  for (let i = 0; i < n; i++) { const x = a[i] - ma, y = b[i] - mb; num += x * y; da += x * x; db += y * y; }
  return da && db ? num / Math.sqrt(da * db) : 0;
}

function keyInfo(tonic, mode) {
  const name = mode === 'major' ? MAJ_NAME[tonic] : MIN_NAME[tonic];
  const root = name.replace(/m$/, '');
  return {
    tonic, mode, name,
    label: `${ES[root] || root} ${mode === 'major' ? 'mayor' : 'menor'}`,
    camelot: mode === 'major' ? CAMELOT_MAJ[tonic] : CAMELOT_MIN[tonic],
  };
}

// notes: [{start,end,pitch,velocity}] → candidatos de key ordenados
function keyFromNotes(notes, chordSegs = []) {
  const c = new Float64Array(12);
  for (const n of notes) {
    const d = Math.max(0, Math.min(4, n.end - n.start));
    const w = d * ((n.velocity ?? 80) / 127) * (n.pitch < 55 ? 1.6 : n.pitch > 84 ? 0.5 : 1);
    c[n.pitch % 12] += w;
  }
  const tot = c.reduce((x, y) => x + y, 0);
  if (tot <= 0) return [];
  // cuánto suena cada acorde (para decidir entre relativas: La menor vs Do mayor)
  const chordDur = new Map();
  let chordTot = 0;
  for (const s of chordSegs) {
    const base = s.name.replace(/(maj7|m7|7|sus4|sus2|dim)$/, (q) => (q === 'm7' ? 'm' : q === 'maj7' || q === '7' ? '' : `|${q}`));
    const d = s.end - s.start; chordTot += d;
    chordDur.set(base, (chordDur.get(base) || 0) + d);
  }
  const firstC = chordSegs[0]?.name, lastC = chordSegs[chordSegs.length - 1]?.name;
  const cands = [];
  for (let t = 0; t < 12; t++) {
    for (const mode of ['major', 'minor']) {
      let r = 0;
      for (const [maj, min] of PROFILES) {
        const prof = mode === 'major' ? maj : min;
        const rot = Array.from({ length: 12 }, (_, i) => prof[(i - t + 12) % 12]);
        r += pearson(Array.from(c), rot);
      }
      r /= PROFILES.length;
      // acorde de la tónica: cuánto suena y si abre/cierra el tema
      const sharp = PC_SHARP[t], flat = MAJ_NAME[t];
      const names = mode === 'major' ? [sharp, flat] : [`${sharp}m`, `${flat}m`];
      let home = 0; for (const nm of names) home = Math.max(home, chordDur.get(nm) || 0);
      const isHome = (x) => !!x && names.some((nm) => x === nm || x.startsWith(nm) && (mode === 'minor' || !x.startsWith(`${nm}m`)));
      let bonus = chordTot ? 0.35 * (home / chordTot) : 0;
      if (isHome(firstC)) bonus += 0.06;
      if (isHome(lastC)) bonus += 0.06;
      cands.push({ ...keyInfo(t, mode), score: r + bonus, corr: r });
    }
  }
  cands.sort((a, b) => b.score - a.score);
  // relativas (La menor / Do mayor tienen las mismas notas): decide el acorde con el que arranca
  // y cierra el tema y cuánto suena cada tónica (en reggaetón y pop el loop arranca en la tónica)
  const a = cands[0];
  const bi = a ? cands.findIndex((k) => k.mode !== a.mode && (a.mode === 'major' ? (a.tonic + 9) % 12 === k.tonic : (a.tonic + 3) % 12 === k.tonic)) : -1;
  const b = bi > 0 ? cands[bi] : null;
  if (a && b && a.score - b.score < 0.3) {
    const ev = (k) => {
      const nm = [PC_SHARP[k.tonic], MAJ_NAME[k.tonic]].map((x) => (k.mode === 'minor' ? `${x}m` : x));
      const is = (x) => !!x && nm.some((y) => x === y || (x.startsWith(y) && (k.mode === 'minor' || !x.startsWith(`${y}m`))));
      let d = 0; for (const s of chordSegs) if (is(s.name)) d += s.end - s.start;
      return 2 * is(firstC) + is(lastC) + (chordTot ? d / chordTot : 0);
    };
    if (ev(b) > ev(a) + 0.5) { cands.splice(bi, 1); cands.unshift(b); b.score = a.score + 0.01; }
  }
  return cands;
}

const niceBpm = (b) => (Math.abs(b - Math.round(b)) < 0.15 ? Math.round(b) : Math.round(b * 10) / 10);

// file → { bpm, bpmAlt, key, keyAlt, confidence }
async function analyze(file, { onProgress } = {}) {
  const bp = require('./midi/basicpitch');
  const tempo = require('./midi/tempo');
  const chords = require('./midi/chords');
  const post = require('./midi/post');
  const x = await av.decodeMono(file, 22050); // misma frecuencia para Basic Pitch y el tempo
  const dur = x.length / 22050;
  if (dur < 3) throw new Error('El audio es muy corto para detectar el tempo (mínimo 3 segundos).');
  onProgress?.(0.05);
  const tp = tempo.estimate(x);
  onProgress?.(0.15);
  const out = await bp.infer(x, (p) => onProgress?.(0.15 + 0.8 * p));
  let notes = bp.toNotes(out, { onsetThresh: 0.5, frameThresh: 0.3, minNoteMs: 120 });
  notes = post.polyphonic(post.mergeRetriggers(notes));
  const segs = chords.detect(notes, { bpm: tp?.bpm, phase: tp?.phase || 0, duration: dur });
  const cands = keyFromNotes(notes, segs);
  onProgress?.(1);
  // sin notas claras (solo batería, ruido): no hay tonalidad
  const tonal = notes.length >= 20 && cands[0] && cands[0].corr >= 0.55;
  const key = tonal ? cands[0] : null;
  // segunda opción: suele ser la relativa o la quinta
  const keyAlt = key ? cands.find((k) => k !== key && !(k.mode !== key.mode && (key.mode === 'major' ? (key.tonic + 9) % 12 === k.tonic : (key.tonic + 3) % 12 === k.tonic))) || null : null;
  const relative = key ? keyInfo(key.mode === 'major' ? (key.tonic + 9) % 12 : (key.tonic + 3) % 12, key.mode === 'major' ? 'minor' : 'major') : null;
  const margin = key && keyAlt ? key.score - keyAlt.score : 0;
  let bpm = tp ? niceBpm(tp.bpm) : null, bpmAlt = null;
  if (bpm && bpm < 85) bpmAlt = niceBpm(bpm * 2);
  else if (bpm && bpm > 160) bpmAlt = niceBpm(bpm / 2);
  return {
    bpm, bpmAlt, key, relative, keyAlt: keyAlt && margin < 0.08 && keyAlt.name !== relative?.name ? keyAlt : null,
    keyConfidence: margin > 0.15 ? 'alta' : margin > 0.06 ? 'media' : 'baja',
    bpmConfidence: tp ? (tp.confidence > 0.4 ? 'alta' : tp.confidence > 0.2 ? 'media' : 'baja') : 'baja',
    duration: dur,
  };
}

module.exports = { analyze, keyFromNotes, keyInfo, CAMELOT_MAJ, CAMELOT_MIN };

// ---- guardar el resultado ----
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const TAGGABLE = ['.mp3', '.flac', '.ogg', '.opus', '.m4a'];
const tagLine = (r) => [r.key && `${r.key.camelot} - ${r.key.name}`, r.bpm && `${r.bpm} BPM`].filter(Boolean).join(' - ');

// "Tema.mp3" → "Tema (8A - Am - 95 BPM).mp3" (si ya tenía una etiqueta así, se reemplaza)
function renameWith(file, r) {
  const ext = path.extname(file);
  let base = path.basename(file, ext).replace(/\s*\((\d{1,2}[AB] - [^)]*|[^)]*\d+(\.\d)? BPM)\)\s*$/, '');
  const t = tagLine(r);
  if (!t) return file;
  let dst = path.join(path.dirname(file), `${base} (${t})${ext}`);
  if (dst === file) return file;
  for (let i = 2; fs.existsSync(dst); i++) dst = path.join(path.dirname(file), `${base} (${t}) ${i}${ext}`);
  fs.renameSync(file, dst);
  return dst;
}

// escribe BPM y key en las etiquetas (sin tocar el audio). MP3: TBPM/TKEY; FLAC/OGG/OPUS: BPM/INITIALKEY; M4A: solo BPM
function writeTags(file, r) {
  const ext = path.extname(file).toLowerCase();
  if (!TAGGABLE.includes(ext)) return Promise.resolve(false);
  const args = ['-hide_banner', '-nostdin', '-loglevel', 'error', '-y', '-i', file, '-map', '0', '-c', 'copy', '-map_metadata', '0'];
  const bpm = r.bpm ? String(Math.round(r.bpm)) : null, key = r.key?.name || null;
  if (ext === '.mp3') { args.push('-id3v2_version', '3'); if (bpm) args.push('-metadata', `TBPM=${bpm}`); if (key) args.push('-metadata', `TKEY=${key}`); }
  else if (ext === '.m4a') { if (bpm) args.push('-metadata', `tmpo=${bpm}`); }
  else { if (bpm) args.push('-metadata', `BPM=${bpm}`); if (key) args.push('-metadata', `INITIALKEY=${key}`); }
  const tmp = path.join(path.dirname(file), `.ruedita-tmp-${Date.now()}${ext}`);
  args.push(tmp);
  return new Promise((resolve) => {
    const p = spawn(av.BIN, args, { windowsHide: true });
    p.on('error', () => resolve(false));
    p.on('close', (code) => {
      try {
        if (code === 0 && fs.statSync(tmp).size > 1000) { fs.renameSync(tmp, file); return resolve(true); }
      } catch {}
      try { fs.unlinkSync(tmp); } catch {}
      resolve(false);
    });
  });
}

module.exports.renameWith = renameWith;
module.exports.writeTags = writeTags;
module.exports.tagLine = tagLine;
module.exports.TAGGABLE = TAGGABLE;
