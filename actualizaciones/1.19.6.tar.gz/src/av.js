// Audio y video con FFmpeg (viene adentro de la app, funciona sin internet).
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const BIN = require('./bins').FFMPEG;

const extOf = (p) => path.extname(p).slice(1).toLowerCase();
const baseOf = (p) => path.basename(p, path.extname(p));
function uniquePath(dir, name, ext) {
  let p = path.join(dir, `${name}.${ext}`);
  for (let i = 2; fs.existsSync(p); i++) p = path.join(dir, `${name} (${i}).${ext}`);
  return p;
}

const LOSSLESS = ['wav', 'flac', 'aif', 'aiff'];

// ---------- correr ffmpeg ----------
function parseTime(s) {
  const m = /(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(s);
  return m ? +m[1] * 3600 + +m[2] * 60 + +m[3] : 0;
}

function ffmpeg(args, { duration, onProgress } = {}) {
  return new Promise((resolve, reject) => {
    const p = spawn(BIN, ['-hide_banner', '-nostdin', '-y', ...args], { windowsHide: true });
    let err = '';
    p.stderr.on('data', (d) => {
      const s = d.toString();
      err = (err + s).slice(-6000);
      if (duration && onProgress) {
        const m = /time=(\d+:\d+:\d+(?:\.\d+)?)/.exec(s);
        if (m) onProgress(Math.min(0.99, parseTime(m[1]) / duration));
      }
    });
    p.on('error', reject);
    p.on('close', (code) => {
      if (code === 0) resolve(err);
      else reject(new Error(lastLine(err) || `ffmpeg terminó con código ${code}`));
    });
  });
}
const lastLine = (s) => s.trim().split(/\r?\n/).filter((l) => !/^\s*(frame|size)=/.test(l)).slice(-1)[0];

// Info básica: duración y si tiene video / tapa (portada)
async function probe(file) {
  const out = await new Promise((resolve) => {
    const p = spawn(BIN, ['-hide_banner', '-i', file], { windowsHide: true });
    let err = '';
    p.stderr.on('data', (d) => { err += d.toString(); });
    p.on('close', () => resolve(err));
    p.on('error', () => resolve(''));
  });
  const dm = /Duration:\s*(\d+:\d+:\d+(?:\.\d+)?)/.exec(out);
  const videoLines = out.split('\n').filter((l) => /Stream #.*Video:/.test(l));
  return {
    duration: dm ? parseTime(dm[1]) : 0,
    hasAudio: /Stream #.*Audio:/.test(out),
    hasVideo: videoLines.some((l) => !/attached pic/.test(l)),
    hasCover: videoLines.some((l) => /attached pic/.test(l)),
    vcodec: (/Video:\s*(\w+)/.exec(videoLines.find((l) => !/attached pic/.test(l)) || '') || [])[1] || '',
    acodecs: [...out.matchAll(/Stream #.*Audio:\s*(\w+)/g)].map((m) => m[1]),
    ...videoSize(videoLines.find((l) => !/attached pic/.test(l)) || '', out),
  };
}

// artista y título de las etiquetas (para renombrar)
async function tags(file) {
  const out = await new Promise((resolve) => {
    const p = spawn(BIN, ['-hide_banner', '-i', file], { windowsHide: true });
    let err = '';
    p.stderr.on('data', (d) => { err += d.toString(); });
    p.on('close', () => resolve(err));
    p.on('error', () => resolve(''));
  });
  const meta = out.split(/\n\s*Duration:/)[0];
  const pick = (k) => ((new RegExp(`^\\s+${k}\\s*:\\s*(.+)$`, 'mi').exec(meta) || [])[1] || '').trim();
  return { artist: pick('artist') || pick('album_artist'), title: pick('title') };
}

// Decodifica el audio a estéreo float 44.1 kHz → [L, R]
function decodeStereo(file, sr = 44100) {
  return new Promise((resolve, reject) => {
    const p = spawn(BIN, ['-hide_banner', '-nostdin', '-i', file, '-vn', '-ac', '2', '-ar', String(sr), '-f', 'f32le', '-'], { windowsHide: true });
    const chunks = [];
    let err = '';
    p.stdout.on('data', (d) => chunks.push(d));
    p.stderr.on('data', (d) => { err = (err + d).slice(-3000); });
    p.on('error', reject);
    p.on('close', (code) => {
      if (code !== 0) return reject(new Error(lastLine(err) || 'No pude leer el audio'));
      const buf = Buffer.concat(chunks);
      const f = new Float32Array(buf.buffer, buf.byteOffset, Math.floor(buf.length / 4));
      const n = f.length / 2;
      const L = new Float32Array(n), R = new Float32Array(n);
      for (let i = 0; i < n; i++) { L[i] = f[2 * i]; R[i] = f[2 * i + 1]; }
      if (!n) return reject(new Error('El archivo no tiene audio'));
      resolve([L, R]);
    });
  });
}

// ---------- audio ----------
function audioCodec(fmt, srcExt) {
  const hi = LOSSLESS.includes(srcExt);
  switch (fmt) {
    case 'mp3': return ['-c:a', 'libmp3lame', '-b:a', '320k', '-id3v2_version', '3'];
    case 'wav': return ['-c:a', hi ? 'pcm_s24le' : 'pcm_s16le'];
    case 'aiff': return ['-c:a', hi ? 'pcm_s24be' : 'pcm_s16be', '-write_id3v2', '1'];
    case 'flac': return ['-c:a', 'flac', '-compression_level', '8'];
    case 'm4a': return ['-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart'];
    case 'ogg': return ['-c:a', 'libvorbis', '-q:a', '7'];
    default: throw new Error(`Formato no soportado: ${fmt}`);
  }
}
const COVER_OK = ['mp3', 'flac', 'm4a'];

async function toAudio(file, fmt, onProgress) {
  const info = await probe(file);
  if (!info.hasAudio) throw new Error('Ese archivo no tiene audio');
  const out = uniquePath(path.dirname(file), baseOf(file), fmt);
  const codec = audioCodec(fmt, extOf(file));
  const opts = { duration: info.duration, onProgress };
  // intentamos conservar la tapa (portada) si el formato la admite
  if (info.hasCover && COVER_OK.includes(fmt)) {
    try {
      await ffmpeg(['-i', file, '-map', '0:a:0', '-map', '0:v:0', '-map_metadata', '0', ...codec, '-c:v', fmt === 'flac' ? 'copy' : 'mjpeg', '-disposition:v', 'attached_pic', out], opts);
      return out;
    } catch { try { fs.unlinkSync(out); } catch {} }
  }
  await ffmpeg(['-i', file, '-map', '0:a:0', '-vn', '-map_metadata', '0', ...codec, out], opts);
  return out;
}

// Audio → MP4 con la tapa del tema (o fondo negro) para subir a redes
async function audioToVideo(file, onProgress) {
  const info = await probe(file);
  const out = uniquePath(path.dirname(file), baseOf(file), 'mp4');
  const tmp = path.join(os.tmpdir(), `ruedita-cover-${Date.now()}.png`);
  let hasImg = false;
  if (info.hasCover) {
    try { await ffmpeg(['-i', file, '-an', '-frames:v', '1', tmp]); hasImg = fs.existsSync(tmp); } catch {}
  }
  const vf = 'scale=1080:1080:force_original_aspect_ratio=decrease,pad=1080:1080:(ow-iw)/2:(oh-ih)/2:color=black,format=yuv420p';
  const imgIn = hasImg ? ['-loop', '1', '-framerate', '2', '-i', tmp] : ['-f', 'lavfi', '-i', 'color=c=black:s=1080x1080:r=2'];
  try {
    await ffmpeg([...imgIn, '-i', file, '-map', '0:v', '-map', '1:a:0', '-vf', vf, '-c:v', 'libx264', '-tune', 'stillimage', '-preset', 'veryfast', '-crf', '22',
      '-c:a', 'aac', '-b:a', '320k', '-shortest', '-movflags', '+faststart', out], { duration: info.duration, onProgress });
  } finally { try { fs.unlinkSync(tmp); } catch {} }
  return out;
}

async function normalizeAudio(file, onProgress) {
  const info = await probe(file);
  let fmt = extOf(file);
  if (fmt === 'aif') fmt = 'aiff';
  if (!['mp3', 'wav', 'aiff', 'flac', 'm4a', 'ogg'].includes(fmt)) fmt = 'wav';
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (normalizado)`, fmt);
  // -14 LUFS (nivel de Spotify/YouTube), picos a -1 dB
  await ffmpeg(['-i', file, '-map', '0:a:0', '-vn', '-map_metadata', '0', '-af', 'loudnorm=I=-14:TP=-1:LRA=11', '-ar', '44100', ...audioCodec(fmt, extOf(file)), out],
    { duration: info.duration, onProgress });
  return out;
}

async function stripMedia(file) {
  const ext = extOf(file);
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (sin metadata)`, ext);
  const info = await probe(file);
  const maps = info.hasVideo ? ['-map', '0:v?', '-map', '0:a?'] : ['-map', '0:a'];
  await ffmpeg(['-i', file, ...maps, '-map_metadata', '-1', '-map_chapters', '-1', '-c', 'copy', out]);
  return out;
}

// ---------- video ----------
const H264 = ['-c:v', 'libx264', '-preset', 'veryfast', '-pix_fmt', 'yuv420p'];

async function videoConvert(file, fmt, onProgress) {
  const info = await probe(file);
  if (!info.hasVideo) throw new Error('Ese archivo no tiene video');
  const out = uniquePath(path.dirname(file), baseOf(file), fmt);
  const opts = { duration: info.duration, onProgress };
  if (fmt === 'mp4') {
    await ffmpeg(['-i', file, ...H264, '-crf', '20', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', out], opts);
  } else if (fmt === 'mov') {
    // copiar sin recomprimir solo si QuickTime/Premiere/Final Cut lo abren tal cual (MPEG-2, WMV, etc. se recodifican)
    const okV = ['h264', 'hevc', 'prores', 'mjpeg'].includes(info.vcodec);
    const okA = info.acodecs.every((c) => ['aac', 'alac', 'mp3', 'ac3'].includes(c) || c.startsWith('pcm_'));
    try { if (!okV || !okA) throw new Error('recodificar'); await ffmpeg(['-i', file, '-map', '0:v', '-map', '0:a?', '-c', 'copy', out], opts); } catch {
      try { fs.unlinkSync(out); } catch {}
      await ffmpeg(['-i', file, ...H264, '-crf', '18', '-c:a', 'aac', '-b:a', '256k', out], opts);
    }
  } else if (fmt === 'webm') {
    await ffmpeg(['-i', file, '-c:v', 'libvpx-vp9', '-crf', '33', '-b:v', '0', '-row-mt', '1', '-deadline', 'good', '-cpu-used', '4', '-c:a', 'libopus', '-b:a', '128k', out], opts);
  } else if (fmt === 'gif') {
    // GIF: 12 fps, 480 px de ancho máximo, hasta 30 segundos
    const dur = Math.min(info.duration || 30, 30);
    await ffmpeg(['-t', '30', '-i', file, '-vf', "fps=12,scale='min(480,iw)':-2:flags=lanczos,split[a][b];[a]palettegen=stats_mode=diff[p];[b][p]paletteuse=dither=bayer:bayer_scale=4", '-loop', '0', out],
      { duration: dur, onProgress });
  } else {
    throw new Error(`Formato no soportado: ${fmt}`);
  }
  return out;
}

// opts: { quality: 0..100 (100 = casi sin pérdida), height: 0 (original) | 1080 | 720 | 480 }
function videoCompressArgs(opts = {}) {
  const q = Math.max(0, Math.min(100, opts.quality ?? 50));
  const crf = Math.round(36 - q * 0.18); // 100 → 18, 50 → 27, 0 → 36
  const h = opts.height || 0;
  const vf = h ? [`scale='if(gt(ih,${h}),-2,iw)':'if(gt(ih,${h}),${h},ih)'`] : [];
  return [...(vf.length ? ['-vf', vf[0]] : []), ...H264, '-crf', String(crf), '-c:a', 'aac', '-b:a', q > 70 ? '192k' : '128k', '-movflags', '+faststart'];
}

async function compressVideo(file, onProgress, opts = {}) {
  const info = await probe(file);
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (comprimido)`, 'mp4');
  await ffmpeg(['-i', file, ...videoCompressArgs(opts), out], { duration: info.duration, onProgress });
  return out;
}

// Estima el tamaño final comprimiendo 4 segundos del medio
async function estimateVideoCompress(file, opts = {}) {
  const info = await probe(file);
  const before = fs.statSync(file).size;
  const sample = Math.min(4, info.duration || 4);
  const ss = Math.max(0, (info.duration - sample) / 2);
  const tmp = path.join(os.tmpdir(), `ruedita-est-${Date.now()}.mp4`);
  try {
    await ffmpeg(['-ss', String(ss), '-t', String(sample), '-i', file, ...videoCompressArgs(opts), tmp]);
    const after = Math.round((fs.statSync(tmp).size / sample) * (info.duration || sample));
    return { before, after, duration: info.duration };
  } finally { try { fs.unlinkSync(tmp); } catch {} }
}

async function muteVideo(file) {
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (sin audio)`, extOf(file));
  await ffmpeg(['-i', file, '-map', '0:v', '-c', 'copy', '-an', out]);
  return out;
}

// Pone un audio en un video.
// opts: { mode: 'replace'|'mix', newVol (0..2), origVol (0..2, solo mix), offset (s: desde dónde arranca el audio),
//         length: 'video'|'audio', fadeOut (s) }
async function combineAudioVideo(video, audio, opts = {}, onProgress) {
  const mode = opts.mode === 'mix' ? 'mix' : 'replace';
  const vi = await probe(video), ai = await probe(audio);
  if (!vi.hasVideo) throw new Error('El archivo de video no tiene imagen');
  if (!ai.hasAudio) throw new Error('El archivo de audio no tiene sonido');
  const offset = Math.max(0, +opts.offset || 0);
  const audioLen = Math.max(0, (ai.duration || 0) - offset);
  const total = opts.length === 'audio' ? Math.max(vi.duration, audioLen) : vi.duration;
  const fade = Math.min(Math.max(0, +opts.fadeOut || 0), total / 2);
  const newVol = opts.newVol ?? 1, origVol = opts.origVol ?? 0.35;

  const ext = ['mp4', 'mov', 'mkv'].includes(extOf(video)) ? extOf(video) : 'mp4';
  const out = uniquePath(path.dirname(video), `${baseOf(video)} (${mode === 'mix' ? 'con audio sumado' : 'audio nuevo'})`, ext);

  const fadeF = fade > 0 ? `,afade=t=out:st=${(total - fade).toFixed(3)}:d=${fade.toFixed(3)}` : '';
  let filter;
  if (mode === 'mix' && vi.hasAudio) {
    filter = `[0:a:0]volume=${origVol},apad[a0];[1:a:0]volume=${newVol},apad[a1];[a0][a1]amix=inputs=2:duration=longest:normalize=0,atrim=0:${total.toFixed(3)}${fadeF}[a]`;
  } else {
    filter = `[1:a:0]volume=${newVol},apad,atrim=0:${total.toFixed(3)}${fadeF}[a]`;
  }
  // si el audio dura más que el video y se eligió "hasta que termine el audio", se congela el último cuadro
  const extendVideo = total > vi.duration + 0.05;
  const vfilter = extendVideo ? `[0:v:0]tpad=stop_mode=clone:stop_duration=${(total - vi.duration).toFixed(3)}[v]` : null;
  const base = ['-i', video, '-ss', String(offset), '-i', audio, '-filter_complex', vfilter ? `${filter};${vfilter}` : filter,
    '-map', vfilter ? '[v]' : '0:v:0', '-map', '[a]', '-t', total.toFixed(3)];
  const aout = ['-c:a', 'aac', '-b:a', '320k'];
  const fast = ext === 'mp4' || ext === 'mov' ? ['-movflags', '+faststart'] : [];
  const prog = { duration: total, onProgress };
  if (!extendVideo) {
    // el video se copia tal cual (rápido y sin perder calidad)
    try { await ffmpeg([...base, '-c:v', 'copy', ...aout, ...fast, out], prog); return out; } catch { try { fs.unlinkSync(out); } catch {} }
  }
  await ffmpeg([...base, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', ...aout, ...fast, out], prog);
  return out;
}


// audio mono a la frecuencia pedida (para los modelos de MIDI)
function decodeMono(file, sr = 22050) {
  return new Promise((resolve, reject) => {
    // estéreo y promedio en JS: "-ac 1" de ffmpeg suma con +3 dB, los modelos esperan (L+R)/2
    const p = spawn(BIN, ['-hide_banner', '-nostdin', '-i', file, '-vn', '-ac', '2', '-ar', String(sr), '-f', 'f32le', '-'], { windowsHide: true });
    const chunks = [];
    let err = '';
    p.stdout.on('data', (d) => chunks.push(d));
    p.stderr.on('data', (d) => { err = (err + d).slice(-3000); });
    p.on('error', reject);
    p.on('close', (code) => {
      if (code !== 0) return reject(new Error(lastLine(err) || 'No pude leer el audio'));
      const buf = Buffer.concat(chunks);
      const st = new Float32Array(Math.floor(buf.length / 4));
      Buffer.from(st.buffer).set(buf.subarray(0, st.length * 4));
      const f = new Float32Array(st.length >> 1);
      for (let i = 0; i < f.length; i++) f[i] = 0.5 * (st[2 * i] + st[2 * i + 1]);
      if (!f.length) return reject(new Error('El archivo no tiene audio'));
      resolve(f);
    });
  });
}
// cambia la frecuencia de muestreo de un audio que ya está en memoria (mono)
function resampleMono(x, srIn, srOut) {
  if (srIn === srOut) return Promise.resolve(Float32Array.from(x));
  return new Promise((resolve, reject) => {
    const p = spawn(BIN, ['-hide_banner', '-nostdin', '-f', 'f32le', '-ar', String(srIn), '-ac', '1', '-i', 'pipe:0', '-ar', String(srOut), '-f', 'f32le', 'pipe:1'], { windowsHide: true });
    const chunks = [];
    let err = '';
    p.stdout.on('data', (d) => chunks.push(d));
    p.stderr.on('data', (d) => { err = (err + d).slice(-3000); });
    p.on('error', reject);
    p.on('close', (code) => {
      if (code !== 0) return reject(new Error(lastLine(err) || 'No pude convertir el audio'));
      const buf = Buffer.concat(chunks);
      const f = new Float32Array(Math.floor(buf.length / 4));
      Buffer.from(f.buffer).set(buf.subarray(0, f.length * 4));
      resolve(f);
    });
    p.stdin.on('error', () => {});
    p.stdin.end(Buffer.from(x.buffer, x.byteOffset, x.length * 4));
  });
}

// ---------- recortar (tiempo y, en video, encuadre) ----------
// opts: { start, end (s), crop: { x, y, w, h } en fracciones de la imagen o null, fast: sin recomprimir }
const AUDIO_SAME = { mp3: 'mp3', wav: 'wav', aif: 'aiff', aiff: 'aiff', flac: 'flac', m4a: 'm4a', ogg: 'ogg' };
async function trimMedia(file, opts = {}, onProgress) {
  const info = await probe(file);
  const total = info.duration || 0;
  const start = Math.max(0, Math.min(+opts.start || 0, total));
  const end = Math.max(start + 0.05, Math.min(+opts.end || total, total || Infinity));
  const dur = end - start;
  const src = extOf(file);
  const prog = { duration: dur, onProgress };
  const cut = ['-ss', start.toFixed(3), '-i', file, '-t', dur.toFixed(3)];
  if (info.hasVideo) {
    const crop = opts.crop && opts.crop.w > 0 && opts.crop.h > 0 ? opts.crop : null;
    const fast = !!opts.fast && !crop;
    const keep = ['mp4', 'mov', 'mkv', 'm4v'].includes(src) || (fast && ['webm', 'avi', 'mpeg', 'mpg', 'ts', 'mts', 'm2ts'].includes(src));
    const ext = keep ? src : 'mp4';
    const out = uniquePath(path.dirname(file), `${baseOf(file)} (recorte)`, ext);
    const faststart = ['mp4', 'mov', 'm4v'].includes(ext) ? ['-movflags', '+faststart'] : [];
    if (fast) {
      try {
        await ffmpeg([...cut, '-map', '0:v:0', '-map', '0:a?', '-c', 'copy', '-avoid_negative_ts', 'make_zero', ...faststart, out], prog);
        return out;
      } catch { try { fs.unlinkSync(out); } catch {} }
    }
    const f = (v) => Math.max(0, Math.min(1, +v || 0)).toFixed(5);
    const vf = crop
      ? ['-vf', `crop=w=trunc(iw*${f(crop.w)}/2)*2:h=trunc(ih*${f(crop.h)}/2)*2:x=trunc(iw*${f(crop.x)}):y=trunc(ih*${f(crop.y)})`]
      : [];
    const audio = info.hasAudio ? ['-c:a', 'aac', '-b:a', '256k'] : [];
    await ffmpeg([...cut, '-map', '0:v:0', '-map', '0:a:0?', ...vf, ...H264, '-crf', '17', ...audio, ...faststart, out], prog);
    return out;
  }
  if (!info.hasAudio) throw new Error('Ese archivo no tiene audio ni video');
  const lossless = LOSSLESS.includes(src) || ['wv', 'ape'].includes(src);
  const fmt = AUDIO_SAME[src] || (lossless ? 'flac' : 'mp3');
  const out = uniquePath(path.dirname(file), `${baseOf(file)} (recorte)`, fmt);
  if (opts.fast && AUDIO_SAME[src] && !LOSSLESS.includes(src)) {
    try { await ffmpeg([...cut, '-map', '0:a:0', '-map_metadata', '0', '-c', 'copy', out], prog); return out; } catch { try { fs.unlinkSync(out); } catch {} }
  }
  const codec = audioCodec(fmt, src);
  if (info.hasCover && COVER_OK.includes(fmt)) {
    try {
      await ffmpeg([...cut, '-map', '0:a:0', '-map', '0:v:0', '-map_metadata', '0', ...codec, '-c:v', fmt === 'flac' ? 'copy' : 'mjpeg', '-disposition:v', 'attached_pic', out], prog);
      return out;
    } catch { try { fs.unlinkSync(out); } catch {} }
  }
  await ffmpeg([...cut, '-map', '0:a:0', '-vn', '-map_metadata', '0', ...codec, out], prog);
  return out;
}

// cuadritos para la línea de tiempo del editor (data URLs JPG)
// ancho y alto como se ve (los videos del celu vienen girados con "rotation of -90"), y cuadros por segundo
function videoSize(line, all) {
  const m = /,\s*(\d{2,5})x(\d{2,5})[\s,\[]/.exec(line);
  if (!m) return { width: 0, height: 0, fps: 0 };
  let w = +m[1], h = +m[2];
  const rot = /rotation of (-?\d+(?:\.\d+)?) degrees/.exec(all) || /rotate\s*:\s*(-?\d+)/.exec(all);
  if (rot && Math.abs(Math.round(+rot[1])) % 180 === 90) [w, h] = [h, w];
  const f = /(\d+(?:\.\d+)?) fps/.exec(line);
  return { width: w, height: h, fps: f ? +f[1] : 0 };
}

async function thumbnails(file, n = 12, height = 72) {
  const info = await probe(file);
  const d = info.duration || 0;
  const one = (t) => new Promise((resolve) => {
    const p = spawn(BIN, ['-hide_banner', '-nostdin', '-ss', t.toFixed(2), '-i', file, '-frames:v', '1', '-vf', `scale=-2:${height}`, '-q:v', '5', '-f', 'image2pipe', '-c:v', 'mjpeg', 'pipe:1'], { windowsHide: true });
    const chunks = [];
    p.stdout.on('data', (c) => chunks.push(c));
    p.on('close', () => resolve(chunks.length ? `data:image/jpeg;base64,${Buffer.concat(chunks).toString('base64')}` : null));
    p.on('error', () => resolve(null));
  });
  const times = Array.from({ length: n }, (_, i) => Math.min(Math.max(0, d - 0.1), (d * (i + 0.5)) / n));
  const out = [];
  for (let i = 0; i < times.length; i += 4) out.push(...(await Promise.all(times.slice(i, i + 4).map(one))));
  return out;
}

// forma de onda: picos (0..1) para dibujar
function peaks(file, n = 1600) {
  return new Promise((resolve) => {
    const p = spawn(BIN, ['-hide_banner', '-nostdin', '-i', file, '-map', '0:a:0', '-ac', '1', '-ar', '4000', '-f', 's16le', 'pipe:1'], { windowsHide: true });
    const chunks = [];
    p.stdout.on('data', (c) => chunks.push(c));
    p.on('error', () => resolve([]));
    p.on('close', () => {
      const b = Buffer.concat(chunks);
      const len = Math.floor(b.length / 2);
      if (!len) return resolve([]);
      const per = Math.max(1, Math.floor(len / n));
      const out = [];
      let max = 1;
      for (let i = 0; i < len; i += per) {
        let m = 0;
        for (let j = i; j < Math.min(len, i + per); j++) { const v = Math.abs(b.readInt16LE(j * 2)); if (v > m) m = v; }
        out.push(m); if (m > max) max = m;
      }
      resolve(out.map((v) => +(v / max).toFixed(3)));
    });
  });
}

// copia liviana para poder verla en el editor (MPEG-2, AVI, WMV, AIFF, WMA…)
async function previewProxy(file) {
  const info = await probe(file);
  const tmp = path.join(os.tmpdir(), `ruedita-prev-${process.pid}-${Date.now()}.${info.hasVideo ? 'mp4' : 'mp3'}`);
  if (info.hasVideo) {
    await ffmpeg(['-i', file, '-map', '0:v:0', '-map', '0:a:0?', '-vf', "scale='min(960,iw)':-2", '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '28', '-pix_fmt', 'yuv420p', '-g', '15', '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', tmp]);
  } else {
    await ffmpeg(['-i', file, '-map', '0:a:0', '-vn', '-c:a', 'libmp3lame', '-b:a', '192k', tmp]);
  }
  return tmp;
}

module.exports = { tags, trimMedia, thumbnails, peaks, previewProxy, decodeMono, resampleMono, combineAudioVideo, estimateVideoCompress, ffmpeg, probe, decodeStereo, toAudio, audioToVideo, normalizeAudio, stripMedia, videoConvert, compressVideo, muteVideo, BIN };
