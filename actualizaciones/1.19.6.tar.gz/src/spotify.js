// Spotify: lee la lista de temas de la página pública de Spotify (la de "insertar", sin clave),
// y si la playlist tiene más de 100 temas pide el resto como el reproductor web.
// busca cada tema en YouTube Music y lo baja con yt-dlp, poniéndole artista / título / álbum de Spotify.
// (No toca el audio protegido de Spotify.)
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const BIN_DIR = path.join(__dirname, '..', 'bin');
const YTDLP = require('./bins').YTDLP;
const FFMPEG = require('./bins').FFMPEG;
const TRACK_TIMEOUT = 4 * 60 * 1000;

const isSpotify = (u) => /^https?:\/\/(open|play)\.spotify\.com\//i.test(String(u || '').trim()) || /^spotify:/i.test(String(u || ''));

function withTimeout(promise, ms, msg) {
  let t;
  return Promise.race([promise, new Promise((_, rej) => { t = setTimeout(() => rej(new Error(msg)), ms); })]).finally(() => clearTimeout(t));
}

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
// embed.spotify.com/?uri=spotify:playlist:ID → open.spotify.com/embed/playlist/ID (directo, sin redirección)
const embedUrl = (u) => { const m = /uri=spotify:([a-z]+):([A-Za-z0-9]+)/.exec(u); return m ? `https://open.spotify.com/embed/${m[1]}/${m[2]}` : u; };
const fetchEmbed = (u, o = {}) => fetch(embedUrl(u), { ...o, signal: AbortSignal.timeout(15000), headers: { 'User-Agent': UA, 'Accept-Language': 'es-AR,es;q=0.9,en;q=0.8' } });

const artistsOf = (t) => {
  const names = [].concat(t.artists || []).filter(Boolean).map((a) => a.name || a).filter(Boolean);
  return names.length ? names.join(', ') : (t.subtitle || '').replace(/ /g, ' ');
};

const INVALID = 'Ese link de Spotify no es válido (tiene que ser de una canción, álbum o playlist).';
const NO_RESP = 'Spotify no respondió. Revisá la conexión y probá de nuevo.';

// Página de "insertar": trae los datos (hasta 100 temas) y un pase anónimo temporal de Spotify
async function embedPage(clean) {
  const m = /spotify\.com\/(?:embed\/)?(track|album|playlist)\/([A-Za-z0-9]+)/i.exec(clean) || /^spotify:(track|album|playlist):([A-Za-z0-9]+)/i.exec(clean);
  if (!m) throw new Error(INVALID);
  const type = m[1].toLowerCase(), id = m[2];
  let html = '', lastErr;
  for (let i = 0; i < 3 && !html.includes('<html'); i++) {
    try { html = await (await fetchEmbed(`https://open.spotify.com/embed/${type}/${id}`)).text(); } catch (e) { lastErr = e; }
  }
  if (!html) throw new Error(/abort|timeout/i.test(String(lastErr?.name) + lastErr?.message) ? NO_RESP : `No pude leer el link de Spotify (${lastErr?.message || 'sin respuesta'})`);
  let entity, token;
  const nd = /<script[^>]*id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/.exec(html);
  if (nd) {
    try {
      const st = JSON.parse(nd[1]).props?.pageProps?.state;
      entity = st?.data?.entity; token = st?.settings?.session?.accessToken;
    } catch {}
  }
  if (!entity) {
    try { entity = require('spotify-url-info').parseData(html); } catch { throw new Error('Spotify no mostró ese link (¿es privado o lo borraron?).'); }
  }
  return { type: entity.uri ? entity.uri.split(':')[1] : type, id, entity, token };
}

// ---- Playlists de más de 100 temas: la misma consulta que usa el reproductor web de Spotify ----
const KNOWN_OPS = [{ op: 'fetchPlaylist', hash: '8964e8eafb21aa992a7d951d256d83285c04be2105d209262901de70cb97584a' }];

function trackFromItem(it) {
  const d = it?.itemV2?.data || it?.item?.data || it?.data || {};
  const names = (d.artists?.items || d.albumOfTrack?.artists?.items || []).map((a) => a?.profile?.name || a?.name).filter(Boolean);
  return {
    name: String(d.name || '').trim(),
    artist: names.join(', '),
    duration: Math.round((d.trackDuration?.totalMilliseconds || d.duration?.totalMilliseconds || 0) / 1000),
  };
}

async function pathfinderPage(o, id, offset) {
  const variables = { enableWatchFeedEntrypoint: false, uri: `spotify:playlist:${id}`, offset, limit: 100 };
  const headers = { 'Content-Type': 'application/json;charset=UTF-8', Accept: 'application/json', 'app-platform': 'WebPlayer', 'User-Agent': UA, Authorization: `Bearer ${o.token}` };
  const r = await fetch('https://api-partner.spotify.com/pathfinder/v1/query', {
    method: 'POST', signal: AbortSignal.timeout(15000), headers,
    body: JSON.stringify({ variables, operationName: o.op, extensions: { persistedQuery: { version: 1, sha256Hash: o.hash } } }),
  });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const j = await r.json();
  const c = j?.data?.playlistV2?.content;
  if (!c || !Array.isArray(c.items)) throw new Error(j?.errors?.[0]?.message || 'respuesta sin temas');
  return c;
}

async function pathfinderAll(o, id) {
  const first = await pathfinderPage(o, id, 0);
  const total = first.totalCount || first.items.length;
  const items = first.items.slice();
  for (let page = 0; items.length < total && page < 100; page++) {
    const c = await pathfinderPage(o, id, items.length);
    if (!c.items.length) break;
    items.push(...c.items);
  }
  return items.map(trackFromItem).filter((t) => t.name);
}

// API web pública con el mismo pase anónimo (plan B)
async function webApiAll(token, id) {
  const out = [];
  for (const kind of ['tracks', 'items']) {
    try {
      let next = `https://api.spotify.com/v1/playlists/${id}/${kind}?limit=100&offset=0&additional_types=track`;
      for (let page = 0; next && page < 100; page++) {
        const r = await fetch(next, { signal: AbortSignal.timeout(15000), headers: { Authorization: `Bearer ${token}`, 'User-Agent': UA } });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const j = await r.json();
        for (const it of j.items || []) {
          const t = it.track || it.item;
          if (t?.name) out.push({ name: t.name, artist: (t.artists || []).map((a) => a.name).join(', '), duration: Math.round((t.duration_ms || 0) / 1000) });
        }
        next = j.next;
      }
      if (out.length) return out;
    } catch { out.length = 0; }
  }
  return out;
}

async function fullPlaylist(id, token) {
  if (!token) return null;
  for (const o of KNOWN_OPS) {
    try { const t = await pathfinderAll({ ...o, token }, id); if (t.length) return t; } catch {}
  }
  try { const t = await webApiAll(token, id); if (t.length) return t; } catch {}
  return null;
}

// Lista de temas del link (para mostrar y elegir)
async function probe(url) {
  const clean = String(url).trim().replace(/\/intl-[a-z]{2}(-[a-z]{2})?\//i, '/').replace(/\?.*$/, '');
  if (/\/(artist|show|episode)\//i.test(clean)) throw new Error('Pegá el link de una canción, álbum o playlist de Spotify (artistas y podcasts no).');
  const { type, id, entity: data, token } = await withTimeout(embedPage(clean), 50000, NO_RESP);
  const isList = type !== 'track';
  const raw = isList ? (data.trackList || []) : [data];
  let tracks = raw.map((t) => ({
    name: String(t.title || t.name || '').trim(),
    artist: artistsOf(t).trim(),
    duration: Math.round((t.duration || t.duration_ms || 0) / 1000),
  })).filter((t) => t.name);
  let partial = false;
  // la página de "insertar" corta en 100: si hay más, se piden todos
  if (type === 'playlist' && raw.length >= 100) {
    const all = await withTimeout(fullPlaylist(id, token), 120000, 'tarde').catch(() => null);
    if (all && all.length >= tracks.length) tracks = all; else partial = true;
  }
  tracks = tracks.map((t, i) => ({ ...t, index: i + 1 }));
  if (!tracks.length) throw new Error('No encontré temas en ese link de Spotify.');
  const listName = data.name || data.title || 'Spotify';
  return {
    playlist: isList, spotify: true, partial,
    title: isList ? listName : `${tracks[0].artist} - ${tracks[0].name}`,
    uploader: isList ? (data.subtitle || '') : '', album: type === 'album' ? listName : '',
    entries: tracks.map((t) => ({ index: t.index, title: `${t.artist} - ${t.name}`, duration: t.duration })),
    tracks, duration: tracks[0].duration,
  };
}

const safeName = (s) => String(s).replace(/[<>:"/\\|?*\u0000-\u001f]/g, '').replace(/\s+/g, ' ').replace(/[. ]+$/, '').trim().slice(0, 150) || 'tema';

function runYtdlp(args, ms) {
  return new Promise((resolve, reject) => {
    const env = { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' };
    const extra = process.env.RUEDITA_YTDLP_EXTRA ? process.env.RUEDITA_YTDLP_EXTRA.split(' ') : []; // solo pruebas
    const p = spawn(YTDLP, [...extra, ...args], { windowsHide: true, env });
    let out = '';
    const timer = setTimeout(() => { try { p.kill(); } catch {} reject(new Error('tardó demasiado')); }, ms);
    p.stdout.on('data', (d) => { out = (out + d.toString('utf8')).slice(-20000); });
    p.stderr.on('data', (d) => { out = (out + d.toString('utf8')).slice(-20000); });
    p.on('error', (e) => { clearTimeout(timer); reject(e); });
    // 101 = se cortó a propósito al bajar el primer resultado que coincide (--max-downloads 1)
    p.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0 || code === 101) return resolve(out);
      const err = out.split(/\r?\n/).reverse().find((l) => /ERROR/.test(l)) || `yt-dlp terminó con código ${code}`;
      reject(new Error(err.replace(/^.*?ERROR:\s*/, '').slice(0, 200)));
    });
  });
}

// Busca un tema en YouTube Music (en "Canciones", con duración parecida a la de Spotify) y lo baja
async function downloadTrack(t, { format, quality, outBase, album, position, total }) {
  const query = `${t.artist} ${t.name}`.replace(/\s+/g, ' ').trim();
  const q = encodeURIComponent(query);
  const tol = t.duration ? Math.max(12, Math.round(t.duration * 0.08)) : 0;
  const filter = t.duration ? ['--match-filter', `duration>${Math.max(0, t.duration - tol)} & duration<${t.duration + tol}`] : [];
  const audio = ['-f', 'bestaudio/best', '-x'];
  if (format === 'mp3') audio.push('--audio-format', 'mp3', '--audio-quality', `${quality && quality !== 'best' ? quality : '320'}K`);
  else if (format === 'm4a' || format === 'opus') audio.push('--audio-format', format, '--audio-quality', '0');
  else audio.push('--audio-format', format);
  // datos de Spotify en el archivo (yt-dlp los escribe antes de poner la tapa)
  const lit = (v) => String(v).replace(/\\/g, '').replace(/%/g, '%%').replace(/:/g, '\\:');
  const meta = [];
  const tags = { title: t.name, artist: t.artist, album, track: total > 1 ? `${position}/${total}` : '' };
  for (const [k, v] of Object.entries(tags)) if (v) meta.push('--parse-metadata', `${lit(v)}:%(meta_${k})s`);
  const common = ['--ffmpeg-location', FFMPEG, '--no-warnings', '--no-progress', '--encoding', 'utf-8', '-N', '4',
    '--yes-playlist', '--no-overwrites', '--print', 'after_move:RFILE %(filepath)s', '-o', `${outBase}.%(ext)s`, ...audio,
    '--embed-metadata', ...meta];
  if (format !== 'wav') common.push('--embed-thumbnail', '--convert-thumbnails', 'jpg');

  const ytm = `https://music.youtube.com/search?q=${q}#songs`;
  const tries = [
    [ytm, ...filter, '--playlist-items', '1:5', '--max-downloads', '1'],       // canción en YT Music con la misma duración
    [`ytsearch5:${query} audio`, ...filter, '--max-downloads', '1'],            // YouTube normal, misma duración
    [ytm, '--playlist-items', '1', '--max-downloads', '1'],                    // lo primero que aparezca
  ];
  let file = null, lastErr;
  for (const tr of tries) {
    try {
      const out = await runYtdlp([...common, ...tr], TRACK_TIMEOUT);
      const m = /RFILE (.+)/.exec(out);
      if (m && fs.existsSync(m[1].trim())) { file = m[1].trim(); break; }
    } catch (e) { lastErr = e; }
  }
  if (!file) throw lastErr || new Error('no lo encontré en YouTube Music');
  return file;
}

// opts: { format: mp3|m4a|flac|wav|opus, quality, dir, items: [índices], tracks / listTitle / album (del probe) }
async function download(url, opts = {}, { onProgress, onTitle } = {}) {
  const info = opts.tracks?.length
    ? { tracks: opts.tracks, playlist: !!opts.playlist || opts.tracks.length > 1, title: opts.listTitle, album: opts.album }
    : await probe(url);
  let tracks = info.tracks;
  if (opts.items?.length) tracks = tracks.filter((t) => opts.items.includes(t.index));
  if (!tracks.length) throw new Error('No hay temas elegidos');
  const format = ['mp3', 'm4a', 'flac', 'wav', 'opus'].includes(opts.format) ? opts.format : 'mp3';
  const isList = !!info.playlist;
  const dir = isList ? path.join(opts.dir, safeName(info.title || 'Spotify')) : opts.dir;
  fs.mkdirSync(dir, { recursive: true });

  const files = [], errors = [];
  let done = 0;
  const total = tracks.length;
  const pad = Math.max(2, String(info.tracks.length).length);
  const queue = tracks.slice();
  onProgress?.(0.01);
  const worker = async () => {
    while (queue.length) {
      const t = queue.shift();
      onTitle?.(`${t.artist} - ${t.name}`, Math.min(total, done + 1), total);
      const outBase = path.join(dir, `${isList ? `${String(t.index).padStart(pad, '0')} - ` : ''}${safeName(`${t.artist} - ${t.name}`)}`);
      try {
        files.push(await downloadTrack(t, { format, quality: opts.quality, outBase, album: info.album || (isList ? info.title : ''), position: t.index, total: isList ? info.tracks.length : 1 }));
      } catch (e) { errors.push(`${t.artist} - ${t.name}: ${e.message}`); }
      done++;
      onProgress?.(Math.min(0.99, done / total));
    }
  };
  await Promise.all(Array.from({ length: Math.min(3, total) }, worker)); // 3 temas a la vez
  if (!files.length) throw new Error(errors[0] || 'No se pudo bajar ningún tema');
  if (errors.length) {
    try { fs.writeFileSync(path.join(dir, 'no-encontrados.txt'), `${errors.join('\r\n')}\r\n`, 'utf8'); } catch {}
  }
  return files.sort();
}

module.exports = { isSpotify, probe, download };
