/* global ruedita */
// Hub de MIXTAPE: la ventana que se abre al abrir la app. Diseño Living: tapas de herramientas, estante con lo último y la barra de arriba.
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const SCENES = window.HUB_SCENES;
const stage = $('#stage');

// (mismos íconos que la rueda)
const ICONS = {
  compress: 'M4 4l5 5M9 5v4H5M20 20l-5-5M15 19v-4h4M20 4l-5 5M15 5v4h4M4 20l5-5M5 15h4v4',
  crop: 'M6 2v16h16M2 6h16v16',
  text: 'M4 6V4h16v2M12 4v16M9 20h6M17 13h4M17 17h4',
  trim: 'M6 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM20 4L8.12 15.88M14.47 14.48L20 20M8.12 8.12L12 12',
  resize: 'M14 4h6v6M20 4l-7 7M10 20H4v-6M4 20l7-7',
  vedit: 'M3 5h18v9H3zM7.5 5v9M16.5 5v9M3 18.5h7M13 18.5h8M11.5 16.5v4',
  rmbg: 'M12 6.2a2.6 2.6 0 1 1 0 5.2 2.6 2.6 0 0 1 0-5.2zM7.2 17.6c.7-2.6 2.6-4 4.8-4s4.1 1.4 4.8 4M3 7.5V4h3.5M21 7.5V4h-3.5M3 16.5V20h3.5M21 16.5V20h-3.5',
  background: 'M3 7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v10a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4zM8 8h8v8H8z',
  upscale: 'M11 3l1.8 4.7 4.7 1.8-4.7 1.8L11 16l-1.8-4.7L4.5 9.5l4.7-1.8zM18.5 14l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9z',
  blur: 'M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18M8 8.5h.01M12 8.5h.01M16 8.5h.01M8 12h.01M12 12h.01M16 12h.01M8 15.5h.01M12 15.5h.01M16 15.5h.01',
  stems: 'M4 6h16M4 12h16M4 18h16M8 4v4M15 10v4M11 16v4',
  vocal: 'M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3zM5 11a7 7 0 0 0 14 0M12 18v3',
  normalize: 'M3 12h1M7 8v8M11 4v16M15 8v8M19 10v4M21 12h0',
  mute: 'M4 9h4l5-4v14l-5-4H4zM17 9l4 6M21 9l-4 6',
  keybpm: 'M9 3h6l4 18H5zM12 17l5-10M8.5 13h7',
  midi: 'M3 6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM8 4v10M12 4v16M16 4v10M8 14v6M16 14v6',
  sliders: 'M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M14 4v4M8 10v4M16 16v4',
  rename: 'M3 7h9M3 12h6M3 17h9M16 5v14M13.5 5h5M13.5 19h5',
  rotate: 'M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5',
  strip: 'M3 12l8.5-8.5H20V12l-8.5 8.5zM15.5 8.5h.01M4 20L20 4',
  merge: 'M5 4v4a4 4 0 0 0 4 4h6a4 4 0 0 1 4 4v4M19 4v4a4 4 0 0 1-4 4M16 17l3 3 3-3',
  split: 'M12 3v7M12 10l-6 6v5M12 10l6 6v5M3 18l3 3 3-3M15 18l3 3 3-3',
};

const KIND = {
  image: { name: 'Imagen', g: 'linear-gradient(135deg, #8fb4ff, #6f86ff 55%, #4a3fd1)', ic: 'M4 5h16v14H4zM4 15l5-5 5 5M13 13l2-2 5 5M15.5 8.5h.01' },
  audio: { name: 'Audio', g: 'linear-gradient(135deg, #5ec8e5, #002FA7)', ic: 'M9 18V5l11-2v13M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM20 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z' },
  video: { name: 'Video', g: 'linear-gradient(135deg, #b39cff, #5b3fd6)', ic: 'M3 6h12v12H3zM15 10l6-3v10l-6-3' },
  mix: { name: 'Video + audio', g: 'linear-gradient(135deg, #b39cff, #5b3fd6)', ic: 'M3 6h12v12H3zM15 10l6-3v10l-6-3' },
  other: { name: 'Archivos', g: 'linear-gradient(135deg, #b8c0cc, #6b7686)', ic: 'M6 3h9l4 4v14H6zM14 3v5h5' },
  docs: { name: 'Imágenes + PDF', g: 'linear-gradient(135deg, #6c7a96, #2b3450)', ic: 'M6 3h9l4 4v14H6zM14 3v5h5M9 13h6M9 17h6' },
  pdf: { name: 'PDF', g: 'linear-gradient(135deg, #6c7a96, #2b3450)', ic: 'M6 3h9l4 4v14H6zM14 3v5h5M9 13h6M9 17h6' },
  link: { name: 'Link', g: 'linear-gradient(135deg, #7fe0cf, #2a9d9a)', ic: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1' },
};
// herramientas sueltas (tapas del Living): qué archivos sirven y qué acción corre
const TOOLS = {
  convert: { kinds: ['image', 'audio', 'video', 'pdf'], sheet: true, multi: true, title: 'Elegí qué convertir' },
  compress: { kinds: ['image', 'video'], id: 'compress', multi: true },
  crop: { kinds: ['image'], id: 'crop' },
  vtrim: { kinds: ['video', 'audio'], id: 'vtrim' },
  upscale: { kinds: ['image'], id: 'upscale', multi: true },
  stems: { kinds: ['audio', 'video'], id: 'stems' },
  stems2: { kinds: ['audio', 'video'], id: 'stems2', multi: true },
  midi: { kinds: ['audio', 'video'], id: 'midi' },
  keybpm: { kinds: ['audio', 'video'], id: 'keybpm', multi: true },
  transcribe: { kinds: ['audio', 'video'], id: 'transcribe' },
  avmix: { mix: true },
};
// menú "Todas": cada opción dice qué archivos pide y qué corre (ring/id como en la rueda)
const ALL_GROUPS = [
  ['Imagen', [
    ['convertir', 'Convertir', { kinds: ['image'], formats: true, multi: true }, 'formato jpg png webp avif gif tiff bmp ico pdf'],
    ['comprimir', 'Comprimir', { kinds: ['image'], id: 'compress', multi: true }, 'peso liviano'],
    ['recortar', 'Recortar', { kinds: ['image'], id: 'crop' }, 'crop'],
    ['mejorar', 'Mejorar (IA)', { kinds: ['image'], id: 'upscale', multi: true }, 'agrandar upscale calidad'],
    ['ocr', 'Foto a texto', { kinds: ['image'], id: 'ocr', multi: true }, 'ocr leer texto escanear copiar letras cartel captura documento'],
    ['blur', 'Blurear', { kinds: ['image'], id: 'blur' }, 'caras pixelar tapar desenfocar'],
    ['tamano', 'Tamaño', { kinds: ['image'], id: 'resize', multi: true }, 'resize redimensionar'],
    ['rmbg', 'Quitar fondo', { kinds: ['image'], id: 'rmbg', multi: true }, 'sacar fondo remove background recortar persona png transparente'],
    ['fondo', 'Poner fondo', { kinds: ['image'], id: 'background' }, 'agregar fondo color'],
    ['rotar', 'Rotar', { kinds: ['image'], id: 'rotate', multi: true }, 'girar espejo enderezar'],
    ['meta', 'Quitar metadata', { kinds: ['image'], id: 'strip', multi: true }, 'exif datos'],
  ]],
  ['Audio', [
    ['convertir', 'Convertir', { kinds: ['audio'], formats: true, multi: true }, 'formato mp3 wav flac m4a aiff ogg'],
    ['video', 'Recortar', { kinds: ['audio'], id: 'vtrim' }, 'cortar trim'],
    ['texto', 'A texto', { kinds: ['audio'], id: 'transcribe' }, 'transcribir subtitulos srt letra whisper'],
    ['stems', 'Stems', { kinds: ['audio'], id: 'stems' }, 'separar bateria bajo guitarra piano orquesta'],
    ['voz', 'Voz / Inst', { kinds: ['audio'], id: 'stems2', multi: true }, 'acapella instrumental vocal'],
    ['midi', 'A MIDI', { kinds: ['audio'], id: 'midi' }, 'melodia acordes notas'],
    ['key', 'Key / BPM', { kinds: ['audio'], id: 'keybpm', multi: true }, 'tonalidad tempo camelot'],
    ['norm', 'Normalizar', { kinds: ['audio'], id: 'normalize', multi: true }, 'volumen lufs nivel'],
    ['mp4', 'A MP4 con la tapa', { kinds: ['audio'], ring: 'format', id: 'mp4', multi: true }, 'video youtube'],
    ['meta', 'Quitar metadata', { kinds: ['audio'], id: 'strip', multi: true }, 'etiquetas tags'],
  ]],
  ['Video', [
    ['vedit', 'Editar y unir videos', { kinds: ['video', 'audio', 'image'], id: 'vedit', multi: true }, 'editor linea de tiempo timeline juntar unir cortar pistas musica clips'],
    ['convertir', 'Convertir', { kinds: ['video'], formats: true, multi: true }, 'formato mp4 mov webm gif mp3 wav'],
    ['video', 'Cortar y encuadrar', { kinds: ['video'], id: 'vtrim' }, 'recortar trim 9:16 tiktok reels'],
    ['comprimir', 'Comprimir', { kinds: ['video'], id: 'compress', multi: true }, 'peso liviano'],
    ['texto', 'A texto', { kinds: ['video'], id: 'transcribe' }, 'transcribir subtitulos srt'],
    ['mix', 'Audio + video', { tool: 'avmix' }, 'juntar reemplazar sumar audio musica'],
    ['mute', 'Sin audio', { kinds: ['video'], id: 'mute', multi: true }, 'mudo silenciar quitar sonido'],
    ['stems', 'Stems', { kinds: ['video'], id: 'stems' }, 'separar voz'],
    ['midi', 'A MIDI', { kinds: ['video'], id: 'midi' }, 'notas'],
  ]],
  ['PDF y más', [
    ['merge', 'Unir PDF', { kinds: ['pdf', 'image'], id: 'pdf_join', multi: true, min: 2 }, 'juntar combinar imagenes jpg fotos'],
    ['split', 'Separar páginas', { kinds: ['pdf'], id: 'split' }, 'dividir'],
    ['pdfimg', 'PDF a imagen', { kinds: ['pdf'], ring: 'format', id: 'png' }, 'png jpg'],
    ['pdftxt', 'PDF a texto', { kinds: ['pdf'], ring: 'format', id: 'txt' }, 'txt extraer'],
    ['rotar', 'Rotar PDF', { kinds: ['pdf'], id: 'rotate' }, 'girar'],
    ['link', 'Bajar de un link', { tool: 'download' }, 'descargar spotify youtube tiktok instagram'],
    ['link', 'Bajar una playlist o álbum', { tool: 'download' }, 'playlist lista album disco varios temas spotify youtube music descargar'],
    ['rename', 'Renombrar archivos', { kinds: null, id: 'rename', multi: true }, 'nombre cambiar nombres masivo numerar lote'],
  ]],
];
const KEYS = { shift: 'Shift', alt: 'Alt', ctrlshift: 'Ctrl + Shift' };
const KEYS_MAC = { shift: 'Shift', alt: 'Option', ctrlshift: 'Control + Shift' };

let st = { settings: {}, recents: [], packs: {}, catalog: {} };
let design = 'living';
let fmtSel = 'dl_mp3';
let active = 2; // tapa del medio al abrir (Stems)
let installPct = null; // descarga del paquete Transcribir en curso

const esc = (t) => String(t ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const svgI = (d, size = 18, color = '#fff', sw = 2) => `<svg aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round"><path d="${d}"/></svg>`;
const chip = (kind, size = 28, r = 8, isz = 14) => { const k = KIND[kind] || KIND.image; return `<span class="kchip" style="width:${size}px;height:${size}px;border-radius:${r}px;background:${k.g}">${svgI(k.ic, isz)}</span>`; };
const base = (p) => String(p || '').split(/[\\/]/).pop();
function ago(t) {
  const m = Math.round((Date.now() - t) / 60000);
  if (m < 1) return 'recién';
  if (m < 60) return `hace ${m} min`;
  const h = Math.round(m / 60);
  if (h < 24) return `hace ${h} h`;
  const d = Math.round(h / 24);
  return d === 1 ? 'ayer' : `hace ${d} días`;
}
function toast(t, ms = 2600) {
  const el = $('#toast'); el.textContent = t; el.hidden = false;
  clearTimeout(toast.t); toast.t = setTimeout(() => { el.hidden = true; }, ms);
}

// ---------------- escena y escala ----------------
function mount(d) {
  design = 'living';
  const sc = SCENES[design];
  stage.innerHTML = sc.html;
  stage.style.width = `${sc.w}px`; stage.style.height = `${sc.h}px`;
  document.body.className = `d-${design}`;
  if (design === 'living') buildCovers();
  fit(); paint();
}
// El Living llena la ventana, pero en pantallas grandes (maximizado) no se agranda más de KMAX:
// queda centrado y la pared y el piso siguen hacia los costados (los bordes de la escena se esfuman).
const KMAX = 1.2, FLOOR_Y = 612;
function fit() {
  const sc = SCENES[design];
  let k = design === 'living' ? Math.max(innerWidth / sc.w, innerHeight / sc.h) : Math.min(innerWidth / sc.w, innerHeight / sc.h);
  if (design === 'living') k = Math.min(k, KMAX);
  const dx = (innerWidth - sc.w * k) / 2;
  const free = innerHeight - sc.h * k;
  const dy = design === 'living' ? (free > 0 ? free * 0.4 : Math.min(0, free * 0.15)) : free / 2;
  curK = k;
  stage.style.transform = `translate(${dx}px, ${dy}px) scale(${k})`;
  if (design === 'living') {
    const fy = Math.round(dy + FLOOR_Y * k);
    document.body.style.background = `linear-gradient(to bottom, #dcdee1 0, #d9dbde ${fy - 1}px, #bdbbba ${fy}px, #b3b1b0 100%)`;
    const masks = [];
    if (dx > 1) masks.push('linear-gradient(to right, transparent 0, #000 36px, #000 calc(100% - 36px), transparent 100%)');
    if (dy > 1) masks.push('linear-gradient(to bottom, transparent 0, #000 50px, #000 calc(100% - 60px), transparent 100%)');
    const m = masks.length ? masks.join(', ') : 'none';
    stage.style.webkitMaskImage = m; stage.style.maskImage = m;
    stage.style.webkitMaskComposite = masks.length > 1 ? 'source-in' : ''; stage.style.maskComposite = masks.length > 1 ? 'intersect' : '';
  } else { document.body.style.background = ''; stage.style.maskImage = stage.style.webkitMaskImage = 'none'; }
}
addEventListener('resize', fit);

function paint() { paintStatus(); paintClock(); paintRecents(); paintPacks(); }
function paintStatus() {
  const s = st.settings;
  $$('.st-txt').forEach((e) => { e.textContent = s.paused ? 'Pausada' : 'Activa'; });
  $$('.st-dot').forEach((e) => { e.style.background = s.paused ? '#b0b0b8' : (design === 'living' ? '#1fa45a' : '#5dff9b'); e.style.boxShadow = s.paused ? 'none' : ''; });
  $$('.key-name').forEach((e) => { e.textContent = (s.mac ? KEYS_MAC : KEYS)[s.key] || 'Shift'; });
}
function paintClock() {
  const d = new Date();
  const hm = d.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', hour12: false });
  const short = d.toLocaleDateString('es-AR', { weekday: 'short', day: 'numeric', month: 'short' }).replace(/[.,]/g, '');
  const long = d.toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' });
  $$('.hub-time').forEach((e) => { e.textContent = hm; });
  $$('.hub-date').forEach((e) => { e.textContent = short; });
  $$('.hub-date-long').forEach((e) => { e.textContent = long; });
}
setInterval(paintClock, 15000);

// ---------------- recientes ----------------
const recName = (r) => (r.kind === 'link' ? base(r.out) : base(r.src));
const recSub = (r) => `${r.label}${r.n > 1 ? ` · ${r.n} archivos` : ''}`;
function paintRecents() {
  const R = st.recents || [];
  const last = $('.hub-last');
  if (last) {
    if (!R.length) last.innerHTML = '<div class="empty">Todavía no hiciste nada. Soltá un archivo en cualquier lado para empezar.</div>';
    else {
      const [a, ...rest] = R;
      const bars = a.kind === 'audio' ? `<div aria-hidden="true" style="display:flex;gap:2px;align-items:flex-end;height:14px;margin-top:4px">${[5, 9, 12, 7, 13, 10, 6, 11, 14, 8, 5, 9, 12, 6, 10, 13, 7, 4].map((h) => `<span style="width:3px;height:${h}px;border-radius:1px;background:#2c7be5;opacity:.7"></span>`).join('')}</div>` : '';
      last.innerHTML = `<button class="last-big" data-reveal="0">${chip(a.kind, 44, 10, 22)}<div style="flex:1;min-width:0"><div class="nm" style="font-size:13.5px;font-weight:700">${esc(recName(a))}</div><div class="sub" style="font-size:12px">${esc(recSub(a))}</div>${bars}</div></button>`
        + rest.slice(0, 2).map((r, i) => `<button class="last-row" data-reveal="${i + 1}">${chip(r.kind)}<div style="min-width:0"><div class="nm">${esc(recName(r))}</div><div class="sub">${esc(recSub(r))} · ${ago(r.at)}</div></div></button>`).join('');
    }
  }
  const shelf = $('.shelf');
  if (shelf) paintShelf(shelf, R);
}
// lomos del estante: tus recientes con nombre, y relleno decorativo alrededor
// lomos en clave fría (MIXTAPE): azul Klein, marino, acero, hielo, petróleo, celeste, blanco, grafito, lavanda, plata
const SPINE = { image: [['#6f86ff', '#4459d6'], ['#dfe7f2', '#b3c0d3'], ['#8fa3bf', '#647a99']], audio: [['#002FA7', '#001f73'], ['#5ec8e5', '#2f98b6'], ['#2a9d9a', '#1b6f6d']],
  video: [['#1b2a4a', '#0e1830'], ['#c7ccd4', '#9aa2ae']], pdf: [['#2b2e35', '#15171b']], link: [['#f4f6f9', '#c9d0da'], ['#5ec8e5', '#2f98b6']], mix: [['#8fa3bf', '#647a99']] };
const FILL = [['#f4f6f9', '#c9d0da'], ['#2b2e35', '#15171b'], ['#8fa3bf', '#647a99'], ['#6f86ff', '#4459d6'], ['#5ec8e5', '#2f98b6'], ['#dfe7f2', '#b3c0d3'], ['#002FA7', '#001f73'], ['#1b2a4a', '#0e1830'], ['#2a9d9a', '#1b6f6d'], ['#c7ccd4', '#9aa2ae']];
function paintShelf(shelf, R) {
  let seed = 21;
  const rnd = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
  const spines = [];
  const recs = R.slice(0, 12);
  const total = 36;
  const slots = recs.map((_, i) => Math.round(((i + 0.5) * total) / Math.max(recs.length, 1)));
  for (let i = 0, r = 0; i < total; i++) {
    if (r < recs.length && slots[r] === i) {
      const rec = recs[r];
      const pal = SPINE[rec.kind] || FILL;
      const [c1, c2] = pal[r % pal.length];
      const dark = ['#f4f6f9', '#dfe7f2', '#5ec8e5', '#c7ccd4', '#8fa3bf'].includes(c1);
      spines.push(`<button class="sp rec" data-reveal="${r}" title="${esc(recName(rec))} — ${esc(recSub(rec))}" style="width:22px;height:${100 + Math.round(rnd() * 10)}px;background:linear-gradient(90deg, ${c2} 0%, ${c1} 18%, ${c1} 62%, ${c2} 100%);box-shadow:inset 0 1px 0 rgba(255,255,255,.35)"><span style="color:${dark ? '#1d1d1f' : '#fff'}">${esc(recName(rec))}</span></button>`);
      r++;
    } else {
      const [c1, c2] = FILL[Math.floor(rnd() * FILL.length)];
      const w = [9, 11, 13, 15, 18][Math.floor(rnd() * 5)];
      spines.push(`<div class="sp" aria-hidden="true" style="width:${w}px;height:${74 + Math.round(rnd() * 34)}px;background:linear-gradient(90deg, ${c2} 0%, ${c1} 18%, ${c1} 62%, ${c2} 100%);box-shadow:inset 0 1px 0 rgba(255,255,255,.35)"></div>`);
    }
  }
  shelf.innerHTML = spines.join('');
}
async function reveal(i) {
  const r = (st.recents || [])[i];
  if (!r) return;
  const ok = await ruedita.invoke('hub-reveal', r.out);
  if (!ok) toast('Ese archivo ya no está (lo moviste o lo borraste)');
}

// ---------------- paquetes ----------------
function paintPacks() {
  const el = $('.hub-packs');
  if (!el) return;
  const p = st.packs || {};
  const row = (name, ok) => `<div class="pk"><span>${name}</span><b class="${ok ? 'ok' : 'no'}">${ok ? 'Instalado' : 'No instalado'}</b></div><div class="pkbar ${ok ? 'ok' : ''}"></div>`;
  el.innerHTML = row('Orquesta', p.orquesta) + row('MIDI Pro', p.midiPro) + row('Transcribir', p.transcribir);
}

// ---------------- hoja: qué hacer con un archivo ----------------
function openSheet(html, onClick) {
  const v = $('#veil');
  $('.sheet-body', v).innerHTML = html;
  v.hidden = false;
  v.onclick = (e) => {
    if (e.target === v || e.target.closest('.x')) return closeSheet();
    const b = e.target.closest('button');
    if (b && onClick) onClick(b, e);
  };
}
function closeSheet() { $('#veil').hidden = true; }

async function sheetForFiles(paths, only) {
  const info = await ruedita.invoke('hub-kind', paths);
  if (!info.kind) return toast('Ese tipo de archivo todavía no lo soporto');
  const cat = st.catalog[info.kind];
  const many = info.count > 1;
  const title = many ? `${info.count} archivos` : info.names[0];
  const fmts = (cat.formats || []).map((f) => `<button data-ring="format" data-id="${f.id}">${esc(f.label)}</button>`).join('');
  const acts = only === 'formats' ? '' : (cat.actions || []).map((a) => {
    const off = (a.single && many) || (a.multi && !many);
    return `<button data-ring="action" data-id="${a.id}" ${off ? 'disabled title="Para esto soltá un solo archivo (o varios, en Unir)"' : ''}><span class="ic" style="background:${KIND[info.kind].g}">${svgI(ICONS[a.icon] || '', 18)}</span><b>${esc(a.label)}</b></button>`;
  }).join('');
  const isMix = info.kind === 'mix';
  openSheet(`<div class="sh-file">${chip(info.kind, 40, 12, 20)}<div style="min-width:0"><div class="t nm">${esc(title)}</div><div class="sub">${esc(KIND[info.kind].name)}${many && !isMix ? ` · ${info.names.slice(0, 3).map(esc).join(', ')}${info.count > 3 ? '…' : ''}` : ''}</div></div></div>`
    + (fmts ? `<div class="sh-h">${isMix ? 'COMBINAR' : info.kind === 'docs' ? 'UNIR TODO EN UN' : 'CONVERTIR A'}</div><div class="${isMix ? 'sh-fmts' : 'sh-fmts'}">${fmts}</div>` : '')
    + (acts ? `<div class="sh-h">HERRAMIENTAS</div><div class="sh-acts">${acts}</div>` : ''),
  (b) => {
    if (!b.dataset.id) return;
    closeSheet();
    ruedita.send('hub-run', { paths, ring: b.dataset.ring, id: b.dataset.id });
    toast('Listo, ya arranca. Te aviso cuando termine.');
  });
}
function sheetForLink(url) {
  const opts = [['dl_video', 'Video (MP4)'], ['dl_mp3', 'MP3'], ['dl_wav', 'WAV']];
  openSheet(`<div class="sh-file">${chip('link', 40, 12, 20)}<div style="min-width:0"><div class="t nm">${esc(url.replace(/^https?:\/\/(www\.)?/, ''))}</div><div class="sub">Link</div></div></div>`
    + `<div class="sh-h">DESCARGAR COMO</div><div class="sh-fmts">${opts.map(([id, l]) => `<button data-id="${id}">${l}</button>`).join('')}<button data-id="more">Más opciones…</button></div>`,
  (b) => {
    if (!b.dataset.id) return;
    closeSheet();
    if (b.dataset.id === 'more') return ruedita.send('hub-downloader', url);
    ruedita.send('hub-link', { url, id: b.dataset.id });
    toast('Descargando… te aviso cuando termine.');
  });
}

async function pick(kinds, multi, title) {
  return ruedita.invoke('hub-pick', { kinds, multi, title });
}
// pick = elegir tapas para el inicio (+ suma, ✓ saca) en vez de abrir la herramienta
let amPick = false;
function amItem(id, k, label, q, attrs) {
  const M = SCENES.living.minis || {};
  const on = amPick && inicioIds().includes(id);
  return `<button class="am-it${on ? ' on' : ''}" ${attrs} data-id="${esc(id)}" data-q="${esc(q)}"><span class="am-mini" aria-hidden="true">${M[k] || ''}</span><span class="am-l">${esc(label)}</span>`
    + `${amPick ? `<span class="am-b" aria-label="${on ? 'En el inicio' : 'Sumar'}">${on ? '✓' : '+'}</span>` : ''}</button>`;
}
function paintAll() {
  const m = $('#allmenu');
  const cols = ALL_GROUPS.map(([g, items], gi) => `<div class="am-col"><div class="am-h">${esc(g.toUpperCase())}</div>`
    + items.map(([k, label, , kw], ii) => amItem(`${g}/${label}`, k, label, `${label} ${kw} ${g}`.toLowerCase(), `data-g="${gi}" data-i="${ii}"`)).join('') + '</div>');
  if (amPick) {
    cols.unshift('<div class="am-col am-def"><div class="am-h">LAS DE SIEMPRE</div><div class="am-defs">'
      + SCENES.living.covers.filter((c) => c.tool !== 'all').map((c) => amItem(c.k, c.k, c.title, `${c.title} ${c.desc}`.toLowerCase(), '')).join('') + '</div></div>');
  }
  m.querySelector('.am-grid').innerHTML = cols.join('');
  m.querySelector('.am').classList.toggle('pick', amPick);
  m.querySelector('.am-t').textContent = amPick ? 'Sumá tapas al inicio' : 'Todo lo que hace MIXTAPE';
  m.querySelector('.am-foot').textContent = amPick ? 'Tocá + para sumar una tapa al inicio y ✓ para sacarla. Lo que no esté en el inicio sigue estando en Todas.'
    : 'Tocá una y elegí el archivo. O soltá el archivo en cualquier lado y te muestra solo lo que sirve para él.';
  filterAll();
}
function showAll(pick = false) {
  amPick = pick;
  const q = $('#allmenu input'); q.value = '';
  paintAll();
  $('#allmenu').hidden = false;
  setTimeout(() => q.focus(), 30);
}
function closeAll() { $('#allmenu').hidden = true; }
function filterAll() {
  const v = $('#allmenu input').value.trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  $$('#allmenu .am-it').forEach((b) => { b.hidden = !!v && !b.dataset.q.normalize('NFD').replace(/[̀-ͯ]/g, '').includes(v); });
  $$('#allmenu .am-col').forEach((c) => { c.hidden = !c.querySelector('.am-it:not([hidden])'); });
}
async function togglePick(id) {
  const ids = inicioIds();
  const i = ids.indexOf(id);
  if (i >= 0) ids.splice(i, 1); else ids.push(id);
  await saveInicio(ids);
  const b = [...$$('#allmenu .am-it')].filter((x) => x.dataset.id === id);
  const on = ids.includes(id);
  b.forEach((x) => { x.classList.toggle('on', on); const bd = x.querySelector('.am-b'); if (bd) bd.textContent = on ? '✓' : '+'; });
}
async function runAllItem(gi, ii) {
  const [, label, a] = ALL_GROUPS[gi][1][ii];
  closeAll();
  if (a.tool) return runTool(a.tool);
  const paths = await pick(a.kinds, !!a.multi, `${label}: elegí ${a.multi ? 'los archivos' : 'el archivo'}`);
  if (!paths.length) return;
  if (a.min && paths.length < a.min) return toast(`Para ${label.toLowerCase()} elegí ${a.min} o más`);
  if (a.formats) return sheetForFiles(paths, 'formats');
  ruedita.send('hub-run', { paths, ring: a.ring || 'action', id: a.id });
  toast('Listo, ya arranca. Te aviso cuando termine.');
}
$('#allmenu').addEventListener('click', (e) => {
  if (e.target.id === 'allmenu' || e.target.closest('.am-x')) return closeAll();
  const b = e.target.closest('.am-it');
  if (!b) return;
  if (amPick) return togglePick(b.dataset.id);
  runAllItem(+b.dataset.g, +b.dataset.i);
});
$('#allmenu input').addEventListener('input', filterAll);
$('#allmenu input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { const b = $('#allmenu .am-it:not([hidden])'); if (b) b.click(); }
});
async function runTool(tool) {
  if (tool === 'all') return showAll();
  if (tool === 'download') {
    const inp = $('.hub-link');
    if (inp) { inp.focus(); return toast('Pegá el link acá y tocá Bajar'); }
    return ruedita.send('hub-downloader');
  }
  const t = TOOLS[tool];
  if (!t) return;
  if (t.mix) {
    const v = await pick(['video'], false, 'Elegí el video');
    if (!v.length) return;
    const a = await pick(['audio'], true, 'Ahora elegí el audio (o varios)');
    if (!a.length) return;
    return sheetForFiles([...v, ...a]);
  }
  const paths = await pick(t.kinds, t.multi, t.title);
  if (!paths.length) return;
  if (t.sheet) return sheetForFiles(paths, 'formats');
  ruedita.send('hub-run', { paths, ring: 'action', id: t.id });
  toast('Listo, ya arranca.');
}
function linkGo() {
  const inp = $('.hub-link');
  const url = (inp?.value || '').trim();
  if (!/^https?:\/\//i.test(url)) { inp?.focus(); return toast('Pegá un link que empiece con https://'); }
  ruedita.send('hub-link', { url, id: fmtSel });
  inp.value = '';
  toast('Descargando… te aviso cuando termine.');
}

// ---------------- paneles: recientes, paquetes, ajustes ----------------
function showRecents() {
  const R = st.recents || [];
  openSheet(`<div class="sh-file"><div class="t">Recientes</div></div><div class="sh-h">LO ÚLTIMO QUE HICISTE</div>`
    + (R.length ? `<div class="rows">${R.map((r, i) => `<div class="row">${chip(r.kind, 32, 9, 16)}<div class="grow"><div class="nm">${esc(recName(r))}</div><div class="sub">${esc(recSub(r))}</div></div><span class="when">${ago(r.at)}</span><button class="btn2" data-reveal="${i}">Abrir carpeta</button></div>`).join('')}</div>`
      + '<div style="margin-top:16px;display:flex;justify-content:flex-end"><button class="btn2" data-clear="1">Borrar historial</button></div>'
      : '<div class="empty">Todavía no hay nada. Lo que conviertas o descargues va a aparecer acá.</div>'),
  async (b) => {
    if (b.dataset.reveal) return reveal(+b.dataset.reveal);
    if (b.dataset.clear) { st.recents = await ruedita.invoke('hub-clear-recents'); paintRecents(); showRecents(); }
  });
}
function showPacks() {
  const p = st.packs || {};
  const where = p.mac ? 'En el ícono de MIXTAPE (barra de arriba) → "Instalar paquete…", o con el botón de acá.' : 'Se descomprimen al lado de MIXTAPE.exe (carpetas "orquesta" y "midi-pro").';
  const row = (n, d, ok) => `<div class="opt"><div>${n}<small>${d}</small></div><b style="color:${ok ? '#157a43' : '#8a8a90'}">${ok ? 'Instalado' : 'No instalado'}</b></div>`;
  openSheet(`<div class="sh-file"><div class="t">Paquetes</div></div><div class="sh-h">IA EXTRA</div>`
    + row('Orquesta', 'Separa cuerdas, metales, vientos, percusión, piano y arpa', p.orquesta)
    + row('MIDI Pro', 'Piano de alta precisión y voz cantada a MIDI', p.midiPro)
    + `<div class="opt"><div>Transcribir<small>Whisper: la voz a texto y subtítulos (560 MB, se baja desde acá)</small><small>${p.transcribir ? `En ${esc(p.trWhere)}` : `Se guarda en ${esc(p.trDest)}`}</small></div>${p.transcribir ? '<span style="display:flex;gap:8px;align-items:center"><b style="color:#157a43">Instalado</b><button class="btn2" data-tropen="1">Abrir carpeta</button></span>' : `<span style="display:flex;gap:8px">${installPct == null ? '<button class="btn2" data-trdir="1">Cambiar carpeta…</button>' : ''}<button class="btn1" data-trget="1">${installPct != null ? `Bajando… ${Math.round(installPct * 100)}%` : 'Bajar'}</button></span>`}</div>`
    + `<p class="sub" style="white-space:normal;margin:14px 0 0">${where}</p>`
    + `<div style="margin-top:14px;display:flex;justify-content:flex-end"><button class="btn1" data-pack="1">${p.mac ? 'Instalar paquete…' : 'Abrir la carpeta de MIXTAPE'}</button></div>`,
  (b) => {
    if (b.dataset.pack) ruedita.send('hub-install-pack');
    if (b.dataset.tropen) ruedita.send('open-folder', p.trWhere);
    if (b.dataset.trdir) ruedita.invoke('transcribe-pick-dir').then((i) => { st.packs.trDest = i.dest; showPacks(); });
    if (b.dataset.trget && installPct == null) { installPct = 0; showPacks(); ruedita.invoke('hub-install-transcribe').then((r) => { installPct = null; if (!r.ok) toast(r.error || 'No se pudo bajar'); }); }
  });
}
function showSettings() {
  const s = st.settings;
  const K = s.mac ? KEYS_MAC : KEYS;
  const sw = (k, on) => `<button class="sw${on ? ' on' : ''}" data-sw="${k}" aria-pressed="${on}" aria-label="${k}"></button>`;
  openSheet(`<div class="sh-file"><div class="t">Ajustes</div></div><div class="sh-h">GENERAL</div>`
    + `<div class="opt"><div>Tecla para abrir la rueda<small>mientras arrastrás un archivo</small></div><div class="seg">${Object.entries(K).map(([k, l]) => `<button data-key="${k}" class="${s.key === k ? 'on' : ''}">${l}</button>`).join('')}</div></div>`
    + `<div class="opt"><div>Pausar MIXTAPE<small>la rueda no aparece hasta que la vuelvas a activar</small></div>${sw('paused', s.paused)}</div>`
    + `<div class="opt"><div>${s.mac ? 'Abrir al iniciar la Mac' : 'Iniciar con Windows'}</div>${sw('login', s.login)}</div>`
    + (s.mac ? '' : `<div class="opt"><div>Funcionar desde cualquier programa<small>no solo desde el Explorador y el navegador</small></div>${sw('anyApp', s.anyApp)}</div>`)
    + `<div class="opt"><div>Carpeta de descargas<small>${esc(s.dlDir)}</small></div><button class="btn2" data-dldir="1">Cambiar…</button></div>`,
  async (b) => {
    let ch = null;
    if (b.dataset.key) ch = { key: b.dataset.key };
    else if (b.dataset.sw) ch = { [b.dataset.sw]: !b.classList.contains('on') };
    if (ch) { st.settings = await ruedita.invoke('hub-set', ch); paintStatus(); return showSettings(); }
    if (b.dataset.dldir) { st.settings = await ruedita.invoke('hub-dl-dir'); showSettings(); }
  });
}

// ---------------- Living: carrusel de tapas ----------------
// El inicio se puede personalizar: qué tapas aparecen y en qué orden (settings.inicio = lista de ids; null = como venía).
// Ids: las tapas de siempre usan su clave ("stems", "convertir"…); cualquier herramienta de Todas, "Grupo/Nombre".
const titleSvg = (title) => {
  const T = esc(title.toUpperCase());
  if (T.length <= 17) return T;
  const w = title.toUpperCase().split(' '); let best = 1, diff = 1e9;
  for (let i = 1; i < w.length; i++) { const d = Math.abs(w.slice(0, i).join(' ').length - w.slice(i).join(' ').length); if (d < diff) { diff = d; best = i; } }
  return `<tspan x="7" dy="-8">${esc(w.slice(0, best).join(' '))}</tspan><tspan x="7" dy="8">${esc(w.slice(best).join(' '))}</tspan>`;
};
const titled = (svg, title) => svg.replace(/(letter-spacing="0\.4" fill="[^"]+">)<\/text>/, (_m, a) => `${a}${titleSvg(title)}</text>`);
let POOL = null;
function pool() {
  if (POOL) return POOL;
  POOL = new Map();
  const M = SCENES.living.minis || {};
  for (const c of SCENES.living.covers) if (c.tool !== 'all') POOL.set(c.k, { ...c, id: c.k });
  ALL_GROUPS.forEach(([g, items], gi) => items.forEach(([k, label], ii) => {
    const id = `${g}/${label}`;
    if (!POOL.has(id) && M[k]) POOL.set(id, { id, k, title: label, desc: g, gi, ii, svg: titled(M[k], label) });
  }));
  return POOL;
}
const defaultInicio = () => SCENES.living.covers.filter((c) => c.tool !== 'all').map((c) => c.k);
const inicioIds = () => (Array.isArray(st.settings.inicio) ? st.settings.inicio : defaultInicio()).filter((id) => pool().has(id));
let CV = [];
let editing = false, drag = null, curK = 1;
function computeCovers() {
  const P = pool();
  CV = [...inicioIds().map((id) => P.get(id)), { ...SCENES.living.covers.find((c) => c.tool === 'all'), id: 'mas' }];
}
function runCover(c) { if (!c) return; if (c.tool) return runTool(c.tool); if (c.gi != null) return runAllItem(c.gi, c.ii); }
async function saveInicio(ids) {
  st.settings = await ruedita.invoke('hub-set', { inicio: ids });
  buildCovers();
}
function buildCovers() {
  const box = $('.covers');
  if (!box) return;
  computeCovers();
  active = Math.max(0, Math.min(active, CV.length - 1));
  box.innerHTML = CV.map((c, i) => `<button class="cv${c.id === 'mas' ? ' cv-mas' : ''}" data-cv="${i}" aria-label="${esc(c.title)}">${c.svg}`
      + `${c.id === 'mas' ? '' : `<span class="cv-x" data-x="${i}" role="button" aria-label="Sacar ${esc(c.title)} del inicio" title="Sacar del inicio">✕</span>`}</button>`).join('')
    + '<div class="cv-hole" aria-hidden="true"></div>'
    + '<button class="cv-add" data-act="ini-add"><span aria-hidden="true">+</span>Sumar tapas</button>';
  const hint = $('.cap-desc') && $('.cap-desc').nextElementSibling;
  if (hint && !hint.querySelector('.cap-edit')) hint.insertAdjacentHTML('beforeend', ' · <button class="cap-edit" data-act="ini-edit" title="Elegí qué tapas aparecen acá y en qué orden">✎ personalizar</button>');
  layoutCovers();
}
// en modo edición: todas chicas en fila (o en 2-3 filas si son muchas), "Sumar tapas" antes de Todas
function editSlots(n) {
  const GAP = 16, W = 1120, HMAX = 262; // entre la barra de arriba y el estante
  let best = null;
  for (let rows = 1; rows <= 3; rows++) {
    const per = Math.ceil(n / rows);
    const sz = Math.floor(Math.min(148, (W - GAP * (per - 1)) / per, (HMAX - GAP * (rows - 1)) / rows));
    if (!best || sz > best.sz + 6) best = { rows, per, sz };
  }
  const { rows, per, sz } = best, slots = [];
  const top0 = Math.max(4, 118 - (rows * sz + (rows - 1) * GAP) / 2);
  for (let i = 0; i < n; i++) {
    const r = Math.floor(i / per), inRow = r === rows - 1 ? n - r * per : per, c = i % per;
    const x0 = 600 - (inRow * sz + (inRow - 1) * GAP) / 2;
    slots.push({ x: x0 + c * (sz + GAP), y: top0 + r * (sz + GAP), sz });
  }
  return slots;
}
function place(el, x, y, sz, shadow) {
  Object.assign(el.style, { left: `${x}px`, top: `${y}px`, width: `${sz}px`, height: `${sz}px`, ...(shadow != null ? { boxShadow: shadow } : {}) });
}
function layoutCovers() {
  const BIG = 214, SM = 148, GAP = 18, CX = 600, H = 236;
  const els = $$('.covers .cv');
  const hole = $('.cv-hole'), add = $('.cv-add');
  if (editing) {
    const n = CV.length - 1; // sin Todas
    const order = drag ? drag.order : CV.slice(0, n).map((_, i) => i);
    const slots = editSlots(n + 2);
    order.forEach((ci, j) => { if (!drag || ci !== drag.i || !drag.moved) place(els[ci], slots[j].x, slots[j].y, slots[j].sz, '-6px 9px 16px rgba(20,28,45,.26), -1px 2px 3px rgba(20,28,45,.2)'); });
    if (hole) { hole.hidden = !(drag && drag.moved); if (drag) { const j = order.indexOf(drag.i); place(hole, slots[j].x, slots[j].y, slots[j].sz); } }
    place(add, slots[n].x, slots[n].y, slots[n].sz);
    place(els[n], slots[n + 1].x, slots[n + 1].y, slots[n + 1].sz, '-6px 9px 16px rgba(20,28,45,.26), -1px 2px 3px rgba(20,28,45,.2)');
    els.forEach((el) => { el.classList.remove('active'); el.tabIndex = -1; });
    return;
  }
  if (hole) hole.hidden = true;
  els.forEach((el, i) => {
    const off = i - active;
    const sz = off === 0 ? BIG : SM;
    const cx = off === 0 ? CX : CX + Math.sign(off) * (BIG / 2 + GAP + SM / 2 + (Math.abs(off) - 1) * (SM + GAP));
    place(el, cx - sz / 2, (H - sz) / 2, sz, off === 0 ? '-12px 16px 28px rgba(20,28,45,.30), -2px 3px 4px rgba(20,28,45,.22)' : '-9px 12px 20px rgba(20,28,45,.26), -2px 3px 4px rgba(20,28,45,.2)');
    el.classList.toggle('active', off === 0);
    el.tabIndex = off === 0 ? 0 : -1;
  });
  const c = CV[active];
  const t = $('.cap-title'); if (t) t.textContent = c ? c.title : '';
  const d = $('.cap-desc'); if (d) d.textContent = c ? c.desc || '' : '';
}
function moveCover(dir) {
  active = Math.max(0, Math.min(CV.length - 1, active + dir));
  layoutCovers();
}

// ---------------- personalizar el inicio ----------------
function setEditing(on) {
  if (editing === on) return;
  editing = on;
  document.body.classList.toggle('editing', on);
  const cap = $('.cap-title'); if (cap) cap.parentElement.style.visibility = on ? 'hidden' : '';
  let bar = $('#editbar');
  if (on && !bar) {
    bar = document.createElement('div'); bar.id = 'editbar';
    bar.innerHTML = '<i aria-hidden="true"></i><b>Editando el inicio</b><span>Arrastrá las tapas para ordenarlas · ✕ para sacar</span>'
      + '<button class="eb-reset" data-eb="reset">Volver a como venía</button><button class="eb-ok" data-eb="ok">Listo</button>';
    bar.addEventListener('click', (e) => {
      const b = e.target.closest('[data-eb]'); if (!b) return;
      if (b.dataset.eb === 'ok') setEditing(false);
      else saveInicio(null).then(() => toast('Volvió a como venía'));
    });
    document.body.appendChild(bar);
  }
  if (bar) bar.hidden = !on;
  if (!on) active = Math.min(Array.isArray(st.settings.inicio) ? Math.floor((CV.length - 1) / 2) : 2, CV.length - 1);
  layoutCovers();
}
async function removeCover(i) {
  const ids = CV.slice(0, -1).map((c) => c.id);
  ids.splice(i, 1);
  await saveInicio(ids);
}
// arrastrar para ordenar (en coordenadas de la escena: el escenario está escalado)
stage.addEventListener('pointerdown', (e) => {
  if (!editing || e.button !== 0 || e.target.closest('.cv-x')) return;
  const el = e.target.closest('.cv'); if (!el) return;
  const i = +el.dataset.cv; if (CV[i].id === 'mas') return;
  e.preventDefault();
  drag = { i, el, sx: e.clientX, sy: e.clientY, x0: parseFloat(el.style.left), y0: parseFloat(el.style.top), order: CV.slice(0, -1).map((_, j) => j), moved: false };
});
addEventListener('pointermove', (e) => {
  if (!drag) return;
  const dx = (e.clientX - drag.sx) / curK, dy = (e.clientY - drag.sy) / curK;
  if (!drag.moved && Math.hypot(dx, dy) < 5) return;
  if (!drag.moved) { drag.moved = true; drag.el.classList.add('dragging'); layoutCovers(); }
  const sz = parseFloat(drag.el.style.width);
  drag.el.style.left = `${drag.x0 + dx}px`; drag.el.style.top = `${drag.y0 + dy}px`;
  const cx = drag.x0 + dx + sz / 2, cy = drag.y0 + dy + sz / 2;
  const slots = editSlots(CV.length + 1).slice(0, CV.length - 1);
  let bj = 0, bd = 1e9;
  slots.forEach((s, j) => { const d = Math.hypot(s.x + s.sz / 2 - cx, s.y + s.sz / 2 - cy); if (d < bd) { bd = d; bj = j; } });
  const cur = drag.order.indexOf(drag.i);
  if (bj !== cur) { drag.order.splice(cur, 1); drag.order.splice(bj, 0, drag.i); layoutCovers(); }
});
function endDrag() {
  if (!drag) return;
  const d = drag; drag = null;
  d.el.classList.remove('dragging');
  if (!d.moved) return layoutCovers();
  const ids = d.order.map((j) => CV[j].id);
  const same = ids.every((id, j) => id === CV[j].id);
  if (same) return layoutCovers();
  saveInicio(ids);
}
addEventListener('pointerup', endDrag);
addEventListener('pointercancel', endDrag);
addEventListener('blur', endDrag);

// ---------------- eventos ----------------
stage.addEventListener('click', (e) => {
  const x = e.target.closest('.cv-x');
  if (x) { if (editing) removeCover(+x.dataset.x); return; }
  const cv = e.target.closest('.cv');
  if (cv) {
    if (editing) return;
    const i = +cv.dataset.cv;
    if (i !== active) { active = i; return layoutCovers(); }
    return runCover(CV[i]);
  }
  const rv = e.target.closest('[data-reveal]');
  if (rv) return reveal(+rv.dataset.reveal);
  const f = e.target.closest('.fmt');
  if (f) { fmtSel = f.dataset.fmt; $$('.fmt').forEach((x) => x.classList.toggle('on', x === f)); return; }
  const tl = e.target.closest('[data-tool]');
  if (tl) return runTool(tl.dataset.tool);
  const a = e.target.closest('[data-act]');
  if (!a) return;
  const act = a.dataset.act;
  if (act.startsWith('pick:')) { const k = act.slice(5); return pick([k], true, `Elegí ${KIND[k].name === 'Imagen' ? 'imágenes' : KIND[k].name.toLowerCase()}`).then((p) => p.length && sheetForFiles(p)); }
  switch (act) {
    case 'pick-any': return pick(null, true).then((p) => p.length && sheetForFiles(p));
    case 'open-dl': return ruedita.send('hub-open-dl');
    case 'recents': return showRecents();
    case 'packs': return showPacks();
    case 'settings': return showSettings();
    case 'help': return ruedita.send('hub-help');
    case 'pause': return ruedita.invoke('hub-set', { paused: !st.settings.paused }).then((s) => { st.settings = s; paintStatus(); toast(s.paused ? 'MIXTAPE en pausa' : 'MIXTAPE activa'); });
    case 'link-go': return linkGo();
    case 'ini-edit': return setEditing(true);
    case 'ini-add': return showAll(true);
    case 'open-last': return st.recents?.length ? reveal(0) : ruedita.send('hub-open-dl');
    default:
  }
});
stage.addEventListener('contextmenu', (e) => { if (e.target.closest('.covers')) { e.preventDefault(); setEditing(true); } });
stage.addEventListener('keydown', (e) => {
  if (e.target.classList?.contains('hub-link') && e.key === 'Enter') { e.preventDefault(); linkGo(); }
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') { if (!$('#allmenu').hidden) return closeAll(); if (!$('#veil').hidden) return closeSheet(); return setEditing(false); }
  if (!$('#veil').hidden || !$('#allmenu').hidden || e.target.tagName === 'INPUT' || design !== 'living' || editing) return;
  if (e.key === 'ArrowLeft') moveCover(-1);
  else if (e.key === 'ArrowRight') moveCover(1);
  else if (e.key === 'Enter' && !editing) runCover(CV[active]);
});
let wheelLock = 0;
addEventListener('wheel', (e) => {
  if (design !== 'living' || editing || !$('#veil').hidden || !$('#allmenu').hidden || Date.now() < wheelLock) return;
  const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
  if (Math.abs(d) < 8) return;
  moveCover(d > 0 ? 1 : -1);
  wheelLock = Date.now() + 260;
}, { passive: true });

// tooltips del dock
stage.addEventListener('mouseover', (e) => {
  const b = e.target.closest('[data-tip]');
  const tip = $('#tip');
  if (!b) { tip.hidden = true; return; }
  const r = b.getBoundingClientRect();
  tip.textContent = b.dataset.tip; tip.style.left = `${r.left + r.width / 2}px`; tip.style.top = `${r.top - 8}px`; tip.hidden = false;
});
stage.addEventListener('mouseleave', () => { $('#tip').hidden = true; });


// ---------------- soltar archivos o links en la ventana ----------------
let dragDepth = 0;
const isFileDrag = (e) => [...(e.dataTransfer?.types || [])].some((t) => t === 'Files' || t === 'text/uri-list');
addEventListener('dragenter', (e) => { if (!isFileDrag(e)) return; e.preventDefault(); dragDepth++; $('#dropveil').hidden = false; });
addEventListener('dragover', (e) => { if (!isFileDrag(e)) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) $('#dropveil').hidden = true; });
addEventListener('drop', (e) => {
  e.preventDefault();
  dragDepth = 0; $('#dropveil').hidden = true;
  const files = [...(e.dataTransfer?.files || [])];
  const paths = files.map((f) => ruedita.pathFor(f)).filter(Boolean);
  if (paths.length) return sheetForFiles(paths);
  const url = (e.dataTransfer.getData('text/uri-list') || e.dataTransfer.getData('text/plain') || '').split(/\r?\n/).find((l) => /^https?:/i.test(l.trim()));
  if (url) sheetForLink(url.trim());
});

// ---------------- avisos del proceso principal ----------------
ruedita.on('hub-recents', (r) => { st.recents = r; paintRecents(); });
ruedita.on('hub-packs', (p) => { st.packs = p; paintPacks(); if (!$('#veil').hidden && $('[data-trget]')) showPacks(); });
ruedita.on('hub-install-progress', (p) => { installPct = p < 1 ? p : null; const b = $('[data-trget]'); if (b) b.textContent = `Bajando… ${Math.round(p * 100)}%`; });
ruedita.on('hub-settings', (s) => {
  const was = JSON.stringify(st.settings.inicio || null); st.settings = s; paintStatus();
  if (JSON.stringify(s.inicio || null) !== was) buildCovers();
});

// cartelito de versión nueva (arriba al medio); al tocarlo abre la web para bajarla
function paintUpdate(u) {
  // versión que está corriendo, chiquita abajo a la derecha (para saber si ya se actualizó)
  let tag = $('#verTag');
  if (!tag) { tag = document.createElement('div'); tag.id = 'verTag'; document.body.appendChild(tag); }
  tag.textContent = u && u.current ? `MIXTAPE ${u.current}` : '';
  let el = $('#updPill');
  const v = u && u.available;
  if (!v || (u.installing && !u.ready)) { if (el) el.remove(); return; }
  if (!el) {
    el = document.createElement('button'); el.id = 'updPill'; el.className = 'upd-pill';
    el.onclick = () => ruedita.invoke('hub-update-open');
    document.body.appendChild(el);
  }
  el.innerHTML = u.ready ? `<i aria-hidden="true"></i><b>MIXTAPE ${esc(u.ready)} lista</b><span>Reiniciar para usarla ⟳</span>` : `<i aria-hidden="true"></i><b>MIXTAPE ${esc(v.version)} ya está</b><span>Bajar la nueva →</span>`;
  el.title = (v.notes || []).join('\n');
}
ruedita.on('hub-update', paintUpdate);

(async () => {
  st = await ruedita.invoke('hub-init');
  mount('living');
  paintUpdate(st.update);
})();
