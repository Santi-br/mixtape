// Quitar fondo con IA, sin internet: ISNet general use (DIS, licencia Apache 2.0; export ONNX del proyecto rembg).
// El modelo (170 MB) es un paquete aparte: se baja desde la app la primera vez que se usa (packs.installRmbg).
// Se probó también BiRefNet lite (MIT, algo mejor en pelo) pero en procesador usa ~6 GB de memoria y tarda ~13 s.
// Resultado: PNG con transparencia "nombre (sin fondo).png" al lado del original.
const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const M = { file: 'isnet-general-use.onnx', url: 'https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-general-use.onnx', mean: [0.5, 0.5, 0.5], std: [1, 1, 1], sigmoid: false };
const FILE = M.file, URL = M.url;
const SIZE = 1024;
const MEAN = M.mean, STD = M.std;

function dirs() {
  const d = [path.join(__dirname, '..', 'models', 'sinfondo')];
  try { d.push(...require('./bins').packDirs('sinfondo')); } catch {}
  try { d.push(path.join(require('electron').app.getPath('userData'), 'sinfondo')); } catch {}
  if (process.env.MX_RMBG_DIR) d.unshift(process.env.MX_RMBG_DIR);
  return d;
}
const modelPath = () => dirs().map((d) => path.join(d, FILE)).find((p) => fs.existsSync(p)) || null;
const available = () => !!modelPath();
function installDir() { try { return path.join(require('electron').app.getPath('userData'), 'sinfondo'); } catch { return path.join(__dirname, '..', 'models', 'sinfondo'); } }

let sess = null;
async function session() {
  if (sess) return sess;
  const p = modelPath();
  if (!p) throw Object.assign(new Error('Falta el paquete Quitar fondo'), { code: 'NOPACK' });
  sess = await require('./gpu').createSession(p);
  return sess;
}

// máscara (0..255, w*h) de lo que es "frente"
async function mask(file, onProgress) {
  const img = sharp(file, { failOn: 'none' }).rotate();
  const { data: rgb, info } = await img.clone().removeAlpha().resize(SIZE, SIZE, { fit: 'fill', kernel: 'lanczos3' }).raw().toBuffer({ resolveWithObject: true });
  const N = SIZE * SIZE, x = new Float32Array(3 * N);
  for (let i = 0; i < N; i++) for (let c = 0; c < 3; c++) x[c * N + i] = (rgb[i * 3 + c] / 255 - MEAN[c]) / STD[c];
  void info;
  onProgress?.(0.15);
  const s = await session();
  const ort = require('onnxruntime-node');
  const out = await s.run({ input_image: new ort.Tensor('float32', x, [1, 3, SIZE, SIZE]) });
  onProgress?.(0.85);
  const y = out[(s.s || s).outputNames[0]].data;
  // sigmoide + estirar entre el mínimo y el máximo (igual que rembg)
  let mi = Infinity, ma = -Infinity;
  const p = new Float32Array(N);
  for (let i = 0; i < N; i++) { const v = M.sigmoid ? 1 / (1 + Math.exp(-y[i])) : y[i]; p[i] = v; if (v < mi) mi = v; if (v > ma) ma = v; }
  const m = Buffer.alloc(N), k = 255 / Math.max(1e-6, ma - mi);
  for (let i = 0; i < N; i++) m[i] = Math.round((p[i] - mi) * k);
  return m;
}

// Saca el fondo. Para los bordes semitransparentes (pelo, etc.) estima el color del frente sin el fondo,
// así no queda un halo del color de atrás al ponerla sobre otro fondo.
async function removeBackground(file, { onProgress } = {}) {
  const base = sharp(file, { failOn: 'none' }).rotate();
  const meta = await base.metadata();
  const W = meta.autoOrient?.width || meta.width, H = meta.autoOrient?.height || meta.height;
  const m = await mask(file, onProgress);
  const alpha = await sharp(m, { raw: { width: SIZE, height: SIZE, channels: 1 } }).resize(W, H, { fit: 'fill', kernel: 'cubic' }).extractChannel(0).raw().toBuffer();
  const rgb = await base.clone().removeAlpha().raw().toBuffer();
  // fotos grandes: el color del borde se estima en una copia de ~4 MP y se usa solo en los bordes
  let fg;
  const MAXPX = 4e6;
  if (W * H > MAXPX) {
    const k = Math.sqrt(MAXPX / (W * H)), w = Math.max(1, Math.round(W * k)), h = Math.max(1, Math.round(H * k));
    const sRgb = await sharp(rgb, { raw: { width: W, height: H, channels: 3 } }).resize(w, h).raw().toBuffer();
    const sA = await sharp(alpha, { raw: { width: W, height: H, channels: 1 } }).resize(w, h).extractChannel(0).raw().toBuffer();
    const sF = await decontaminate(sRgb, sA, w, h);
    const bigF = await sharp(sF, { raw: { width: w, height: h, channels: 3 } }).resize(W, H).raw().toBuffer();
    fg = Buffer.from(rgb);
    for (let i = 0; i < W * H; i++) if (alpha[i] < 251) { fg[i * 3] = bigF[i * 3]; fg[i * 3 + 1] = bigF[i * 3 + 1]; fg[i * 3 + 2] = bigF[i * 3 + 2]; }
  } else fg = await decontaminate(rgb, alpha, W, H);
  const rgba = Buffer.alloc(W * H * 4);
  for (let i = 0, j = 0; i < W * H; i++, j += 3) { rgba[i * 4] = fg[j]; rgba[i * 4 + 1] = fg[j + 1]; rgba[i * 4 + 2] = fg[j + 2]; rgba[i * 4 + 3] = alpha[i]; }
  onProgress?.(1);
  return sharp(rgba, { raw: { width: W, height: H, channels: 4 } }).png({ compressionLevel: 8 });
}

// Estimación rápida del color del frente ("blur fusion", Forte & Pitié 2020), en dos pasadas:
// F ≈ blur(F·a)/blur(a) + a·(I − a·F̂ − (1−a)·B̂), con B̂ = blur(I·(1−a))/blur(1−a).
async function decontaminate(rgb, alpha, W, H) {
  const n = W * H;
  const a = new Float32Array(n);
  let edge = 0;
  for (let i = 0; i < n; i++) { a[i] = alpha[i] / 255; if (alpha[i] > 4 && alpha[i] < 251) edge++; }
  if (!edge) return rgb;
  const I = new Float32Array(n * 3); for (let i = 0; i < n * 3; i++) I[i] = rgb[i] / 255;
  let F = I, B = I;
  for (const r of [Math.max(16, Math.round(Math.max(W, H) / 40)), 3]) {
    const fa = new Float32Array(n * 3), b1a = new Float32Array(n * 3), aa = new Float32Array(n), na = new Float32Array(n);
    for (let i = 0; i < n; i++) { aa[i] = a[i]; na[i] = 1 - a[i]; for (let c = 0; c < 3; c++) { fa[i * 3 + c] = F[i * 3 + c] * a[i]; b1a[i * 3 + c] = B[i * 3 + c] * (1 - a[i]); } }
    const bfa = boxBlur(fa, W, H, 3, r), bb = boxBlur(b1a, W, H, 3, r), ba = boxBlur(aa, W, H, 1, r), bna = boxBlur(na, W, H, 1, r);
    const nF = new Float32Array(n * 3), nB = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const ai = a[i];
      for (let c = 0; c < 3; c++) {
        const k = i * 3 + c;
        const Fh = bfa[k] / (ba[i] + 1e-5), Bh = bb[k] / (bna[i] + 1e-5);
        const d = I[k] - ai * Fh - (1 - ai) * Bh;
        nF[k] = Math.min(1, Math.max(0, Fh + ai * d));
        nB[k] = Math.min(1, Math.max(0, Bh + (1 - ai) * d));
      }
    }
    F = nF; B = nB;
  }
  const out = Buffer.alloc(n * 3);
  for (let i = 0; i < n; i++) {
    const keep = alpha[i] >= 251; // adentro de la figura queda el color original tal cual
    for (let c = 0; c < 3; c++) out[i * 3 + c] = keep ? rgb[i * 3 + c] : Math.round(F[i * 3 + c] * 255);
  }
  return out;
}

// blur de caja separable (suma acumulada), ch canales intercalados
function boxBlur(src, W, H, ch, r) {
  const tmp = new Float32Array(src.length), dst = new Float32Array(src.length);
  for (let y = 0; y < H; y++) {
    for (let c = 0; c < ch; c++) {
      let s = 0; const row = y * W;
      for (let x = -r; x <= r; x++) s += src[(row + Math.min(W - 1, Math.max(0, x))) * ch + c];
      for (let x = 0; x < W; x++) {
        tmp[(row + x) * ch + c] = s / (2 * r + 1);
        s += src[(row + Math.min(W - 1, x + r + 1)) * ch + c] - src[(row + Math.max(0, x - r)) * ch + c];
      }
    }
  }
  for (let x = 0; x < W; x++) {
    for (let c = 0; c < ch; c++) {
      let s = 0;
      for (let y = -r; y <= r; y++) s += tmp[(Math.min(H - 1, Math.max(0, y)) * W + x) * ch + c];
      for (let y = 0; y < H; y++) {
        dst[(y * W + x) * ch + c] = s / (2 * r + 1);
        s += tmp[(Math.min(H - 1, y + r + 1) * W + x) * ch + c] - tmp[(Math.max(0, y - r) * W + x) * ch + c];
      }
    }
  }
  return dst;
}

module.exports = { removeBackground, mask, available, installDir, modelPath, FILE, URL };
