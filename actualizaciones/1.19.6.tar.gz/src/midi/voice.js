// Voz cantada → MIDI con GAME (openvpi, sucesor de SOME). Modelos ONNX: encoder → segmenter (D3PM, 8 pasos) → estimator.
const path = require('path');
const ort = require('onnxruntime-node');

const { proDir } = require('./paths');
const SR = 44100;
const STEP = 0.01;
const sess = {};
async function s(name) {
  if (!sess[name]) sess[name] = await ort.InferenceSession.create(path.join(proDir(), 'voz', `${name}.onnx`), { graphOptimizationLevel: 'all', logSeverityLevel: 3 });
  return sess[name];
}
const B = (arr, dims) => new ort.Tensor('bool', arr, dims);
const F = (arr, dims) => new ort.Tensor('float32', arr instanceof Float32Array ? arr : Float32Array.from(arr), dims);

async function chunkNotes(wave, { boundaryThresh = 0.2, presenceThresh = 0.2, steps = 8 } = {}) {
  const dur = wave.length / SR;
  const enc = await (await s('encoder')).run({ waveform: F(wave, [1, wave.length]), duration: F([dur], [1]) });
  const maskT = enc.maskT;
  const T = maskT.dims[1];
  const kb = await (await s('dur2bd')).run({ durations: F([dur], [1, 1]), maskT });
  const known = kb.boundaries;
  let prev = known;
  const seg = await s('segmenter');
  for (let i = 0; i < steps; i++) {
    const o = await seg.run({
      x_seg: enc.x_seg, language: new ort.Tensor('int64', BigInt64Array.from([0n]), [1]),
      known_boundaries: known, prev_boundaries: prev, t: F([i / steps], [1]), maskT,
      threshold: new ort.Tensor('float32', Float32Array.from([boundaryThresh]), []),
      radius: new ort.Tensor('int64', BigInt64Array.from([2n]), []),
    });
    prev = o.boundaries;
  }
  const bd = await (await s('bd2dur')).run({ boundaries: prev, maskT });
  const est = await (await s('estimator')).run({
    x_est: enc.x_est, boundaries: prev, maskT, maskN: bd.maskN,
    threshold: new ort.Tensor('float32', Float32Array.from([presenceThresh]), []),
  });
  const durs = bd.durations.data, mN = bd.maskN.data, pres = est.presence.data, sc = est.scores.data;
  const notes = [];
  let t = 0;
  for (let i = 0; i < durs.length; i++) {
    if (!mN[i]) break;
    const d = durs[i];
    if (pres[i] && d > 0) notes.push({ start: t, end: t + d, pitchF: sc[i], pitch: Math.round(sc[i]) });
    t += d;
  }
  void T;
  return notes;
}

// corta en pedazos de ~20 s por los lugares más silenciosos (como el slicer de GAME)
function slices(x) {
  const hop = Math.round(SR * 0.02);
  const n = Math.floor(x.length / hop);
  const rms = new Float32Array(n);
  for (let k = 0; k < n; k++) { let t = 0; for (let i = k * hop; i < (k + 1) * hop; i++) t += x[i] * x[i]; rms[k] = Math.sqrt(t / hop); }
  const out = [];
  let a = 0;
  const minF = Math.round(12 / 0.02), maxF = Math.round(24 / 0.02);
  while (a < n) {
    if (n - a <= maxF) { out.push([a * hop, x.length]); break; }
    let best = a + minF, bv = Infinity;
    for (let k = a + minF; k < a + maxF; k++) if (rms[k] < bv) { bv = rms[k]; best = k; }
    out.push([a * hop, best * hop]);
    a = best;
  }
  return out;
}

// x: voz aislada, mono 44.1 kHz. sensitivity 0..1
async function transcribe(x, { sensitivity = 0.5, onProgress } = {}) {
  const thr = 0.35 - 0.3 * sensitivity; // 0.5 → 0.2 (lo recomendado)
  const parts = slices(x);
  const notes = [];
  // silencio total: nada que transcribir en ese pedazo
  for (let i = 0; i < parts.length; i++) {
    const [a, b] = parts[i];
    let peak = 0; for (let j = a; j < b; j += 4) peak = Math.max(peak, Math.abs(x[j]));
    if (peak > 0.003) {
      const ns = await chunkNotes(x.subarray(a, b), { boundaryThresh: thr, presenceThresh: thr });
      for (const n of ns) notes.push({ ...n, start: n.start + a / SR, end: n.end + a / SR });
    }
    onProgress?.((i + 1) / parts.length);
  }
  // fuerza: volumen de la voz en cada nota
  for (const n of notes) {
    const a = Math.round(n.start * SR), b = Math.min(x.length, Math.round(n.end * SR));
    let t = 0; for (let i = a; i < b; i++) t += x[i] * x[i];
    n.amp = Math.sqrt(t / Math.max(1, b - a));
  }
  const maxA = Math.max(1e-6, ...notes.map((n) => n.amp));
  for (const n of notes) n.velocity = Math.max(30, Math.min(127, Math.round(127 * (n.amp / maxA) ** 0.5)));
  return notes.filter((n) => n.end - n.start >= 0.05);
}

module.exports = { transcribe, SR };
