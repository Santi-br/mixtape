// Basic Pitch (Spotify, Apache 2.0): audio → notas. Modelo chiquito que corre con onnxruntime.
// Port fiel de basic_pitch/inference.py + note_creation.py (sin pitch bends).
const path = require('path');
const ort = require('onnxruntime-node');

const SR = 22050;
const HOP = 256;
const N_SAMPLES = SR * 2 - HOP; // 43844
const ANNOT_FPS = Math.floor(SR / HOP); // 86
const ANNOT_N_FRAMES = ANNOT_FPS * 2; // 172
const N_OVERLAP_FRAMES = 30;
const OVERLAP = N_OVERLAP_FRAMES * HOP;
const WIN_HOP = N_SAMPLES - OVERLAP;
const NP = 88;
const MIDI_OFFSET = 21;

let sess = null;
async function session() {
  if (!sess) sess = await ort.InferenceSession.create(path.join(__dirname, '..', '..', 'models', 'midi', 'basicpitch.onnx'), { graphOptimizationLevel: 'all', logSeverityLevel: 3 });
  return sess;
}

// audio mono 22050 Hz → { note, onset, contour } como matrices planas [frames × 88]
async function infer(audio, onProgress) {
  const s = await session();
  const origLen = audio.length;
  const padded = new Float32Array(origLen + OVERLAP / 2);
  padded.set(audio, OVERLAP / 2);
  const starts = [];
  for (let i = 0; i < padded.length; i += WIN_HOP) starts.push(i);
  const nOl = N_OVERLAP_FRAMES / 2;
  const keep = ANNOT_N_FRAMES - 2 * nOl; // 142
  const nOut = Math.floor(origLen * (ANNOT_FPS / SR));
  const note = new Float32Array(starts.length * keep * NP);
  const onset = new Float32Array(starts.length * keep * NP);
  const BATCH = 4;
  for (let b = 0; b < starts.length; b += BATCH) {
    const nb = Math.min(BATCH, starts.length - b);
    const x = new Float32Array(nb * N_SAMPLES);
    for (let k = 0; k < nb; k++) {
      const st = starts[b + k];
      x.set(padded.subarray(st, Math.min(st + N_SAMPLES, padded.length)), k * N_SAMPLES);
    }
    const out = await s.run({ 'serving_default_input_2:0': new ort.Tensor('float32', x, [nb, N_SAMPLES, 1]) });
    const yN = out['StatefulPartitionedCall:1'].data, yO = out['StatefulPartitionedCall:2'].data;
    for (let k = 0; k < nb; k++) {
      const dst = (b + k) * keep * NP, src = (k * ANNOT_N_FRAMES + nOl) * NP;
      note.set(yN.subarray(src, src + keep * NP), dst);
      onset.set(yO.subarray(src, src + keep * NP), dst);
    }
    onProgress?.(Math.min(1, (b + nb) / starts.length));
  }
  const n = Math.min(nOut, starts.length * keep);
  // el modelo normaliza cada pedazo y "inventa" notas en el silencio: se apaga donde no hay sonido
  const rms = new Float32Array(n);
  let peak = 0;
  for (let k = 0; k < n; k++) {
    let t = 0; const a = k * HOP, b = Math.min(origLen, a + 2 * HOP);
    for (let i = a; i < b; i++) t += audio[i] * audio[i];
    rms[k] = Math.sqrt(t / Math.max(1, b - a)); if (rms[k] > peak) peak = rms[k];
  }
  const gate = Math.max(1e-3, peak * 0.003); // -50 dB del pico o -60 dBFS
  for (let k = 0; k < n; k++) {
    let loud = false;
    for (let j = Math.max(0, k - 3); j <= Math.min(n - 1, k + 1) && !loud; j++) if (rms[j] >= gate) loud = true;
    if (!loud) { note.fill(0, k * NP, (k + 1) * NP); onset.fill(0, k * NP, (k + 1) * NP); }
  }
  return { n, note: note.subarray(0, n * NP), onset: onset.subarray(0, n * NP) };
}

function frameTimes(n) {
  const off = (HOP / SR) * (ANNOT_N_FRAMES - N_SAMPLES / HOP) + 0.0018;
  const t = new Float64Array(n);
  for (let k = 0; k < n; k++) t[k] = (k * HOP) / SR - off * Math.floor(k / ANNOT_N_FRAMES);
  return t;
}

const hzToMidi = (f) => 12 * Math.log2(f / 440) + 69;

// opts: onsetThresh (0.5), frameThresh (0.3), minNoteMs (127.7), minFreq, maxFreq, inferOnsets, melodia
function toNotes({ n, note, onset }, opts = {}) {
  const onT = opts.onsetThresh ?? 0.5, frT = opts.frameThresh ?? 0.3;
  const minLen = Math.round(((opts.minNoteMs ?? 127.7) / 1000) * (SR / HOP));
  const energyTol = 11;
  const frames = Float32Array.from(note);
  let onsets = Float32Array.from(onset);
  // rango de frecuencias
  if (opts.maxFreq) { const m = Math.round(hzToMidi(opts.maxFreq) - MIDI_OFFSET); for (let t = 0; t < n; t++) for (let f = Math.max(0, m); f < NP; f++) { frames[t * NP + f] = 0; onsets[t * NP + f] = 0; } }
  if (opts.minFreq) { const m = Math.round(hzToMidi(opts.minFreq) - MIDI_OFFSET); for (let t = 0; t < n; t++) for (let f = 0; f < Math.min(NP, m); f++) { frames[t * NP + f] = 0; onsets[t * NP + f] = 0; } }
  // onsets inferidos de los saltos de energía
  if (opts.inferOnsets !== false) {
    const diff = new Float32Array(n * NP);
    let maxD = 0, maxO = 0;
    for (let i = 0; i < n * NP; i++) if (onsets[i] > maxO) maxO = onsets[i];
    for (let t = 0; t < n; t++) for (let f = 0; f < NP; f++) {
      const cur = frames[t * NP + f];
      const p1 = t >= 1 ? frames[(t - 1) * NP + f] : 0, p2 = t >= 2 ? frames[(t - 2) * NP + f] : 0;
      let d = Math.min(cur - p1, cur - p2);
      if (d < 0 || t < 2) d = 0;
      diff[t * NP + f] = d; if (d > maxD) maxD = d;
    }
    const sc = maxD > 0 ? maxO / maxD : 0;
    for (let i = 0; i < n * NP; i++) { const v = diff[i] * sc; if (v > onsets[i]) onsets[i] = v; }
  }
  // picos locales en el tiempo
  const peaks = [];
  for (let t = 1; t < n - 1; t++) for (let f = 0; f < NP; f++) {
    const v = onsets[t * NP + f];
    if (v >= onT && v > onsets[(t - 1) * NP + f] && v > onsets[(t + 1) * NP + f]) peaks.push(t * NP + f);
  }
  peaks.reverse();
  const rem = Float32Array.from(frames);
  const events = [];
  const mean = (a, b, f) => { let s = 0; for (let t = a; t < b; t++) s += frames[t * NP + f]; return b > a ? s / (b - a) : 0; };
  for (const idx of peaks) {
    const st = Math.floor(idx / NP), f = idx % NP;
    if (st >= n - 1) continue;
    let i = st + 1, k = 0;
    while (i < n - 1 && k < energyTol) { if (rem[i * NP + f] < frT) k++; else k = 0; i++; }
    i -= k;
    if (i - st <= minLen) continue;
    for (let t = st; t < i; t++) { rem[t * NP + f] = 0; if (f < NP - 1) rem[t * NP + f + 1] = 0; if (f > 0) rem[t * NP + f - 1] = 0; }
    events.push([st, i, f + MIDI_OFFSET, mean(st, i, f)]);
  }
  if (opts.melodia !== false) {
    // equivalente a buscar el máximo cada vez: candidatos ordenados por valor (empates: índice menor)
    const cand = [];
    for (let i = 0; i < n * NP; i++) if (rem[i] > frT) cand.push(i);
    cand.sort((a, b) => rem[b] - rem[a] || a - b);
    const val0 = new Float32Array(cand.length);
    cand.forEach((c, j) => { val0[j] = rem[c]; });
    for (let j = 0; j < cand.length; j++) {
      const c = cand[j];
      if (rem[c] !== val0[j] || rem[c] <= frT) continue; // ya se borró
      const tm = Math.floor(c / NP), f = c % NP;
      rem[c] = 0;
      let i = tm + 1, k = 0;
      while (i < n - 1 && k < energyTol) {
        if (rem[i * NP + f] < frT) k++; else k = 0;
        rem[i * NP + f] = 0; if (f < NP - 1) rem[i * NP + f + 1] = 0; if (f > 0) rem[i * NP + f - 1] = 0;
        i++;
      }
      const iEnd = i - 1 - k;
      i = tm - 1; k = 0;
      while (i > 0 && k < energyTol) {
        if (rem[i * NP + f] < frT) k++; else k = 0;
        rem[i * NP + f] = 0; if (f < NP - 1) rem[i * NP + f + 1] = 0; if (f > 0) rem[i * NP + f - 1] = 0;
        i--;
      }
      const iStart = i + 1 + k;
      if (iEnd - iStart <= minLen) continue;
      events.push([iStart, iEnd, f + MIDI_OFFSET, mean(iStart, iEnd, f)]);
    }
  }
  const T = frameTimes(n);
  return events.map(([a, b, p, amp]) => ({ start: T[a], end: T[Math.min(b, n - 1)], pitch: p, velocity: Math.max(1, Math.min(127, Math.round(127 * amp))), amp }));
}

module.exports = { SR, infer, toNotes, frameTimes, NP, MIDI_OFFSET, FPS: SR / HOP };
