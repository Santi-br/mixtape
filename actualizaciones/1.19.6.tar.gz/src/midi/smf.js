// Escritor de archivos MIDI estándar (tipo 1, 480 ticks por negra).
const PPQ = 480;

function vlq(n) {
  const out = [n & 0x7f];
  n >>= 7;
  while (n > 0) { out.unshift((n & 0x7f) | 0x80); n >>= 7; }
  return out;
}
// los DAW leen los nombres en Latin-1 (Windows-1252): así "Batería" se ve bien
const str = (s) => [...Buffer.from(String(s).replace(/[^\x00-\xff]/g, '?'), 'latin1')];

function track(events) {
  // events: [{ tick, data: [bytes], order }]
  events.sort((a, b) => a.tick - b.tick || (a.order ?? 1) - (b.order ?? 1));
  const bytes = [];
  let last = 0;
  for (const e of events) { bytes.push(...vlq(Math.max(0, e.tick - last)), ...e.data); last = Math.max(last, e.tick); }
  bytes.push(0x00, 0xff, 0x2f, 0x00);
  const head = Buffer.from('MTrk');
  const len = Buffer.alloc(4); len.writeUInt32BE(bytes.length);
  return Buffer.concat([head, len, Buffer.from(bytes)]);
}

// parts: [{ name, program, drums, notes: [{start,end,pitch,velocity}], pedals: [{start,end,cc}] }]
// markers: [{ time, text }]
// key: { tonic 0-11, mode 'major'|'minor' } → armadura (FF 59)
const SF_MAJ = [0, -5, 2, -3, 4, -1, 6, 1, -4, 3, -2, 5];
function write({ bpm = 120, parts, markers = [], key = null }) {
  const toTick = (sec) => Math.round(sec * (bpm / 60) * PPQ);
  const us = Math.round(60000000 / bpm);
  const meta = [
    { tick: 0, order: 0, data: [0xff, 0x03, ...vlq(str('MIXTAPE').length), ...str('MIXTAPE')] },
    { tick: 0, order: 0, data: [0xff, 0x51, 0x03, (us >> 16) & 0xff, (us >> 8) & 0xff, us & 0xff] },
    { tick: 0, order: 0, data: [0xff, 0x58, 0x04, 4, 2, 24, 8] },
  ];
  if (key) {
    const majT = key.mode === 'major' ? key.tonic : (key.tonic + 3) % 12;
    meta.push({ tick: 0, order: 0, data: [0xff, 0x59, 0x02, SF_MAJ[majT] & 0xff, key.mode === 'major' ? 0 : 1] });
  }
  for (const m of markers) { const t = str(m.text); meta.push({ tick: toTick(m.time), order: 1, data: [0xff, 0x06, ...vlq(t.length), ...t] }); }
  const tracks = [track(meta)];
  let next = 0;
  for (const p of parts) {
    let c = 9;
    if (!p.drums) { if (next === 9) next++; c = Math.min(15, next++); }
    const ev = [];
    const nm = str(p.name || 'Pista');
    ev.push({ tick: 0, order: 0, data: [0xff, 0x03, ...vlq(nm.length), ...nm] });
    if (!p.drums) ev.push({ tick: 0, order: 0, data: [0xc0 | c, (p.program ?? 0) & 0x7f] });
    for (const n of p.notes) {
      const a = toTick(n.start), b = Math.max(a + 1, toTick(n.end));
      const v = Math.max(1, Math.min(127, Math.round(n.velocity ?? 100)));
      ev.push({ tick: a, order: 2, data: [0x90 | c, n.pitch & 0x7f, v] });
      ev.push({ tick: b, order: 1, data: [0x80 | c, n.pitch & 0x7f, 0] }); // los "note off" van antes que los "note on" del mismo tick
    }
    for (const pd of p.pedals || []) {
      ev.push({ tick: toTick(pd.start), order: 1, data: [0xb0 | c, pd.cc, 127] });
      ev.push({ tick: toTick(pd.end), order: 0, data: [0xb0 | c, pd.cc, 0] });
    }
    tracks.push(track(ev));
  }
  const hdr = Buffer.alloc(14);
  hdr.write('MThd', 0); hdr.writeUInt32BE(6, 4); hdr.writeUInt16BE(1, 8); hdr.writeUInt16BE(tracks.length, 10); hdr.writeUInt16BE(PPQ, 12);
  return Buffer.concat([hdr, ...tracks]);
}

module.exports = { write, PPQ };
