// Dónde están los modelos del "Paquete MIDI Pro" (piano de alta precisión + voz cantada).
// Va en una carpeta "midi-pro" al lado de MIXTAPE.exe (se instala aparte), o en models/midi-pro.
const fs = require('fs');
const path = require('path');
const MODELS = path.join(__dirname, '..', '..', 'models');
function proDir() {
  const cands = [path.join(MODELS, 'midi-pro'), ...require('../bins').packDirs('midi-pro')];
  return cands.find((d) => fs.existsSync(path.join(d, 'piano', 'piano-main.onnx')) || fs.existsSync(path.join(d, 'voz', 'encoder.onnx'))) || null;
}
const hasPiano = () => { const d = proDir(); return !!d && fs.existsSync(path.join(d, 'piano', 'piano-main.onnx')); };
const hasVoice = () => { const d = proDir(); return !!d && fs.existsSync(path.join(d, 'voz', 'encoder.onnx')); };
module.exports = { MODELS, proDir, hasPiano, hasVoice };
