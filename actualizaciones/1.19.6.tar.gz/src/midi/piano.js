// Piano de alta precisión con Transkun 2.0 (Yujia Yan, MIT): Transformer + semi-CRF por tecla, con pedal.
// Port de transkun/ModelTransformer.transcribe: mel en JS → ONNX (puntajes de intervalos) → Viterbi en JS → ONNX (fuerza y ajuste fino).
const fs = require('fs');
const path = require('path');
const ort = require('onnxruntime-node');
const FFT = require('fft.js');
const { proDir } = require('./paths');

const FS = 44100, HOP = 1024, WIN = 4096, NMEL = 229, NWIN = 6;
const SEG_S = 16, STEP_S = 8;
const PITCHES = [-64, -67, ...Array.from({ length: 88 }, (_, i) => 21 + i)];
const NSYM = PITCHES.length; // 90

let res = null;
async function load() {
  if (res) return res;
  const d = path.join(proDir(), 'piano');
  const rd = (f) => { const b = fs.readFileSync(path.join(d, f)); return new Float32Array(b.buffer.slice(b.byteOffset, b.byteOffset + b.length)); };
  const opt = { graphOptimizationLevel: 'all', logSeverityLevel: 3 };
  const wins = rd('piano-wins.bin'); // [6, 4096]
  const melM = rd('piano-mel.bin'); // [2049, 229]
  // banco mel en forma rala (cada banda: rango de bins con peso)
  const mel = [];
  for (let m = 0; m < NMEL; m++) {
    const idx = [], val = [];
    for (let k = 0; k < WIN / 2 + 1; k++) { const v = melM[k * NMEL + m]; if (v) { idx.push(k); val.push(v); } }
    mel.push({ idx: Int32Array.from(idx), val: Float32Array.from(val) });
  }
  res = {
    wins, mel,
    main: await ort.InferenceSession.create(path.join(d, 'piano-main.onnx'), opt),
    heads: await ort.InferenceSession.create(path.join(d, 'piano-heads.onnx'), opt),
  };
  return res;
}

// frames de un pedazo (como transkun.Util.makeFrame con medio frame a la izquierda)
function nFrames(len) { return Math.ceil(len / HOP) + 1; }

// mel log normalizado [T, 229, 6] de un pedazo estéreo (chs: [Float32Array, ...] de largo SEG)
function features(chs, r) {
  const segLen = chs[0].length;
  const T = nFrames(segLen);
  const lPad = WIN / 2;
  // normalización de ganancia sobre todos los frames (incluye el relleno, igual que el original)
  let sum = 0, sum2 = 0, cnt = 0;
  for (const x of chs) {
    for (let f = 0; f < T; f++) {
      const st = f * HOP - lPad;
      for (let i = 0; i < WIN; i++) { const j = st + i; const v = j >= 0 && j < segLen ? x[j] : 0; sum += v; sum2 += v * v; }
      cnt += WIN;
    }
  }
  const mean = sum / cnt;
  const std = Math.sqrt(Math.max(0, (sum2 - cnt * mean * mean) / (cnt - 1))) + 1e-8;
  const fft = new FFT(WIN);
  const inp = new Array(WIN).fill(0), out = fft.createComplexArray();
  const NB = WIN / 2 + 1;
  const pow = new Float64Array(NB * NWIN); // potencia promediada entre canales [bin, win]
  const feat = new Float32Array(T * NMEL * NWIN);
  const norm = 1 / WIN; // |rfft ortho|² = |X|²/N
  const eps = 1e-5, leps = Math.log(eps);
  const frame = new Float64Array(WIN);
  for (let f = 0; f < T; f++) {
    pow.fill(0);
    for (const x of chs) {
      const st = f * HOP - lPad;
      for (let i = 0; i < WIN; i++) { const j = st + i; frame[i] = ((j >= 0 && j < segLen ? x[j] : 0) - mean) / std; }
      for (let w = 0; w < NWIN; w++) {
        const wo = w * WIN;
        for (let i = 0; i < WIN; i++) inp[i] = frame[i] * r.wins[wo + i];
        fft.realTransform(out, inp);
        for (let k = 0; k < NB; k++) { const re = out[2 * k], im = out[2 * k + 1]; pow[k * NWIN + w] += (re * re + im * im) * norm; }
      }
    }
    const inv = 1 / chs.length;
    for (let m = 0; m < NMEL; m++) {
      const { idx, val } = r.mel[m];
      for (let w = 0; w < NWIN; w++) {
        let s = 0; for (let q = 0; q < idx.length; q++) s += pow[idx[q] * NWIN + w] * val[q];
        s *= inv;
        feat[(f * NMEL + m) * NWIN + w] = (Math.log(s + eps) - leps) / -leps;
      }
    }
  }
  return { feat, T };
}

// Viterbi hacia atrás del semi-CRF (transkun viterbiBackward), un símbolo
function viterbi(S, T, sym, forcedStart) {
  const at = (e, b) => S[(e * T + b) * NSYM + sym];
  const q = new Float64Array(T);
  const ptr = new Int32Array(T); // ptr por posición de inicio p
  const d = at(T - 1, T - 1);
  q[T - 1] = d > 0 ? d : 0;
  for (let p = T - 2; p >= 0; p--) {
    let best = q[p + 1], sel = -1; // saltear
    for (let e = p + 1; e < T; e++) { const v = q[e] + at(e, p); if (v > best) { best = v; sel = e - p - 1; } }
    ptr[p] = sel;
    const dd = at(p, p);
    q[p] = best + (dd > 0 ? dd : 0);
  }
  const outI = [];
  let j = forcedStart;
  while (j < T - 1) {
    const sel = ptr[j];
    if (at(j, j) > 0) outI.push([j, j]);
    if (sel < 0) j += 1;
    else { const i = sel + j + 1; outI.push([j, i]); j = i; }
  }
  if (at(T - 1, T - 1) > 0) outI.push([T - 1, T - 1]);
  return outI;
}

async function segment(chs, startPos, r, lastFrameIdx) {
  const { feat, T } = features(chs, r);
  const o = await r.main.run({ feat: new ort.Tensor('float32', feat, [1, T, NMEL, NWIN]) });
  const S = o.S.data, ctx = o.ctx.data; // ctx [90, T, D]
  const D = o.ctx.dims[2];
  const intervals = [];
  for (let s = 0; s < NSYM; s++) intervals.push(viterbi(S, T, s, startPos[s]));
  const total = intervals.reduce((a, l) => a + l.length, 0);
  if (!total) return { notes: [], lastP: new Array(NSYM).fill(0) };
  const A = new Float32Array(total * D), Bv = new Float32Array(total * D);
  let n = 0;
  for (let s = 0; s < NSYM; s++) for (const [a, b] of intervals[s]) {
    A.set(ctx.subarray((s * T + a) * D, (s * T + a + 1) * D), n * D);
    Bv.set(ctx.subarray((s * T + b) * D, (s * T + b + 1) * D), n * D);
    n++;
  }
  const h = await r.heads.run({ a: new ort.Tensor('float32', A, [total, D]), b: new ort.Tensor('float32', Bv, [total, D]) });
  const vel = h.velocity.data, off = h.offsets.data, pres = h.presence.data;
  const frameDur = HOP / FS;
  const notes = [], lastP = [];
  n = 0;
  for (let s = 0; s < NSYM; s++) {
    let lastEnd = 0, curLastP = 0;
    for (const [a, b] of intervals[s]) {
      let start = (a + off[2 * n]) * frameDur;
      let end = (b + off[2 * n + 1]) * frameDur;
      const hasOnset = a > 0 || !!pres[2 * n];
      const hasOffset = b < lastFrameIdx || !!pres[2 * n + 1];
      start = Math.max(start, lastEnd);
      end = Math.max(end, start + 1e-8);
      lastEnd = end;
      notes.push({ start, end, pitch: PITCHES[s], velocity: Number(vel[n]), hasOnset, hasOffset });
      if (hasOffset) curLastP = b;
      n++;
    }
    lastP.push(curLastP);
  }
  notes.sort((x, y) => x.start - y.start || x.end - y.end || x.pitch - y.pitch);
  return { notes, lastP };
}

// chs: canales a 44.1 kHz (1 o 2). Devuelve { notes, pedals } — pedals: [{start, end, cc: 64|67}]
async function transcribe(chs, { onProgress } = {}) {
  const r = await load();
  const padBegin = SEG_S - STEP_S;
  const padN = Math.ceil(padBegin * FS);
  const len = chs[0].length;
  const nSample = len + 2 * padN;
  const stepSize = Math.ceil((STEP_S * FS) / HOP) * HOP;
  const segSize = Math.ceil(SEG_S * FS);
  const lastFrameIdx = Math.round(segSize / HOP);
  let startPos = new Array(NSYM).fill(Math.floor((padBegin * FS) / HOP));
  const byType = new Map();
  const steps = Math.ceil(nSample / stepSize);
  let k = 0;
  for (let i = 0; i < nSample; i += stepSize) {
    const slice = chs.map((x) => {
      const o = new Float32Array(segSize);
      for (let t = 0; t < segSize; t++) { const src = i + t - padN; if (src >= 0 && src < len && i + t < nSample) o[t] = x[src]; }
      return o;
    });
    const beginTime = i / FS - padBegin;
    const { notes, lastP } = await segment(slice, startPos, r, lastFrameIdx);
    startPos = lastP.map((p) => Math.max(p - Math.floor(stepSize / HOP), 0));
    for (const e of notes) {
      e.start = Math.max(e.start + beginTime, 0);
      e.end = Math.max(e.end + beginTime, e.start);
      const list = byType.get(e.pitch) || [];
      if (!byType.has(e.pitch)) byType.set(e.pitch, list);
      const last = list[list.length - 1];
      if (last && e.start < last.end) {
        if (e.hasOnset) list[list.length - 1] = e;
        else { last.hasOffset = e.hasOffset; last.end = Math.max(e.end, last.end); }
        continue;
      }
      if (e.hasOnset) list.push(e);
    }
    onProgress?.(++k / steps);
  }
  for (const list of byType.values()) if (list.length) list[list.length - 1].hasOffset = true;
  let all = [...byType.values()].flat().filter((e) => e.hasOffset);
  // resolveOverlapping
  all.sort((x, y) => x.start - y.start || x.end - y.end || x.pitch - y.pitch);
  const lastIdx = new Map();
  all.forEach((e, idx) => { if (lastIdx.has(e.pitch)) { const p = all[lastIdx.get(e.pitch)]; if (p.end > e.start) p.end = e.start; } lastIdx.set(e.pitch, idx); });
  const notes = all.filter((e) => e.pitch > 0).map((e) => ({ start: e.start, end: e.end, pitch: e.pitch, velocity: Math.max(1, Math.min(127, e.velocity)) }));
  const pedals = all.filter((e) => e.pitch < 0).map((e) => ({ start: e.start, end: e.end, cc: -e.pitch }));
  return { notes, pedals };
}

module.exports = { transcribe, FS };
