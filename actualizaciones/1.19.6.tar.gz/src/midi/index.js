// Audio → MIDI: melodía, armonía, bajo, batería, piano (paquete Pro) o tema completo multipista.
const fs = require('fs');
const path = require('path');
const av = require('../av');
const bp = require('./basicpitch');
const post = require('./post');
const tempo = require('./tempo');
const chords = require('./chords');
const smf = require('./smf');
const { hasPiano, hasVoice } = require('./paths');

const SR = 44100;
const mono = ([L, R]) => { const o = new Float32Array(L.length); for (let i = 0; i < L.length; i++) o[i] = 0.5 * (L[i] + R[i]); return o; };
const mix = (...st) => {
  const n = st[0][0].length; const L = new Float32Array(n), R = new Float32Array(n);
  for (const [a, b] of st) for (let i = 0; i < n; i++) { L[i] += a[i]; R[i] += b[i]; }
  return [L, R];
};

function uniqueFile(dir, base, ext) {
  let p = path.join(dir, `${base}${ext}`);
  for (let i = 2; fs.existsSync(p); i++) p = path.join(dir, `${base.replace(/\)$/, ` ${i})`)}${ext}`);
  return p;
}

// sensibilidad 0..1 → umbrales de Basic Pitch
const bpOpts = (o, extra = {}) => ({
  onsetThresh: 0.65 - 0.3 * (o.sensitivity ?? 0.5),
  frameThresh: 0.4 - 0.2 * (o.sensitivity ?? 0.5),
  minNoteMs: o.minNoteMs ?? 120,
  ...extra,
});
const hz = (m) => 440 * 2 ** ((m - 69) / 12);

async function bpNotes(x44, o, kind) {
  const x = await av.resampleMono(x44, SR, bp.SR);
  const out = await bp.infer(x, o.onProgress);
  const lo = o.rangeLo ?? (kind === 'bass' ? 28 : 21), hi = o.rangeHi ?? (kind === 'bass' ? 67 : 108);
  let notes = bp.toNotes(out, bpOpts(o, { minFreq: hz(lo) * 0.97, maxFreq: hz(hi + 1) }));
  notes = post.mergeRetriggers(notes);
  if (kind === 'bass') notes = post.monophonic(notes, { preferLow: true });
  else if (kind === 'melody') notes = post.monophonic(notes, { preferHigh: !!o.overChords });
  else notes = post.polyphonic(notes);
  return post.clampRange(notes, lo, hi);
}

async function voiceNotes(x44, o) {
  const v = require('./voice');
  let notes = await v.transcribe(x44, { sensitivity: o.sensitivity ?? 0.5, onProgress: o.onProgress });
  const lo = o.rangeLo ?? 21, hi = o.rangeHi ?? 108;
  notes = notes.filter((n) => n.end - n.start >= (o.minNoteMs ?? 120) / 1000 * 0.6);
  return post.clampRange(notes, lo, hi);
}

// opts: { mode: melody|harmony|bass|drums|piano|full, source: voice|instrument, separate, quantize: 0|4|2|1,
//         sensitivity, minNoteMs, rangeLo, rangeHi, chordNames, onProgress }
async function convert(file, opts = {}) {
  const mode = opts.mode || 'melody';
  const report = opts.onProgress || (() => {});
  const stage = (a, b) => (p) => report(a + (b - a) * Math.max(0, Math.min(1, p)));
  if (mode === 'piano' && !hasPiano()) throw new Error('El piano de alta precisión necesita el "Paquete MIDI Pro" (MIXTAPE-MIDI-Pro.exe).');
  const voice = mode === 'melody' && opts.source !== 'instrument' && hasVoice();

  const st = await av.decodeStereo(file, SR);
  const duration = st[0].length / SR;
  if (duration > 20 * 60) throw new Error('El audio es muy largo (máximo 20 minutos).');

  // 1) separar antes (si se pidió)
  let src = { mix: st };
  let pSep = 0;
  if (opts.separate) {
    const { separateRaw } = require('../stems');
    const want = new Set({
      melody: opts.source === 'instrument' ? ['vocals', 'other'] : ['vocals'],
      harmony: ['other'], bass: ['bass'], drums: ['drums'], piano: ['piano'], full: ['vocals', 'drums', 'bass', 'other'],
    }[mode]);
    pSep = 0.55;
    const q = want.has('vocals') ? 'best' : 'fast';
    const { out } = await separateRaw(st[0], st[1], want, { quality: q, onProgress: stage(0, pSep) });
    src = { ...out, mix: st };
    // "acordes" = todo lo que no es voz, batería ni bajo (guitarra + piano + otros)
    if (out.other && out.guitar && out.piano) src.harmony = mix(out.other, out.guitar, out.piano);
  }
  const pick = (k) => (opts.separate && src[k] ? src[k] : st);
  const rest = (from, to) => stage(pSep + (1 - pSep) * from, pSep + (1 - pSep) * to);

  // 2) tempo (de la mezcla original)
  let tp = null;
  const wantTempo = opts.quantize || opts.tempo !== false;
  if (wantTempo) {
    try { tp = tempo.estimate(await av.resampleMono(mono(st), SR, tempo.SR)); } catch { tp = null; }
  }

  // 3) transcribir
  const parts = [];
  let pedals = [];
  const melodyPart = async (from, to) => {
    const o = { ...opts, onProgress: rest(from, to) };
    if (voice) return { name: 'Voz', program: 54, notes: await voiceNotes(mono(pick('vocals')), o) };
    const s = opts.separate ? (opts.source === 'instrument' ? (src.harmony || src.other || st) : pick('vocals')) : st;
    // si la melodía comparte stem con los acordes, se queda con la voz de arriba
    o.overChords = opts.source === 'instrument';
    return { name: opts.source === 'instrument' ? 'Melodía' : 'Voz', program: opts.source === 'instrument' ? 80 : 54, notes: await bpNotes(mono(s), o, 'melody') };
  };
  const harmonyPart = async (from, to) => ({ name: 'Acordes', program: 0, notes: await bpNotes(mono(opts.separate ? (src.harmony || pick('other')) : st), { ...opts, onProgress: rest(from, to) }, 'harmony') });
  const bassPart = async (from, to) => ({ name: 'Bajo', program: 33, notes: await bpNotes(mono(pick('bass')), { ...opts, onProgress: rest(from, to) }, 'bass') });
  const drumPart = async (from, to) => {
    const dr = require('./drums');
    const notes = await dr.transcribe(mono(pick('drums')), { sensitivity: opts.sensitivity ?? 0.5, onProgress: rest(from, to) });
    return { name: 'Batería', drums: true, notes };
  };

  if (mode === 'melody') parts.push(await melodyPart(0, 1));
  else if (mode === 'harmony') parts.push(await harmonyPart(0, 1));
  else if (mode === 'bass') parts.push(await bassPart(0, 1));
  else if (mode === 'drums') parts.push(await drumPart(0, 1));
  else if (mode === 'piano') {
    const pn = require('./piano');
    const r = await pn.transcribe(pick('piano'), { onProgress: rest(0, 1) });
    parts.push({ name: 'Piano', program: 0, notes: r.notes.filter((n) => n.pitch >= (opts.rangeLo ?? 21) && n.pitch <= (opts.rangeHi ?? 108)), pedals: r.pedals });
    pedals = r.pedals;
  } else {
    parts.push(await drumPart(0, 0.15));
    parts.push(await bassPart(0.15, 0.35));
    parts.push(await harmonyPart(0.35, 0.6));
    parts.push(await melodyPart(0.6, 1));
  }
  void pedals;

  // el bombo marca el pulso: afinar la fase con él
  const drumsPart = parts.find((p) => p.drums);
  if (tp && drumsPart) {
    const kicks = drumsPart.notes.filter((n) => n.pitch === 36).map((n) => n.start);
    if (kicks.length > 8) {
      try { tp = tempo.estimate(await av.resampleMono(mono(st), SR, tempo.SR), { beatTimes: kicks }); } catch {}
    }
  }

  // 4) cuantizar
  if (opts.quantize && tp) {
    for (const p of parts) {
      p.notes = tempo.quantize(p.notes, tp, opts.quantize, { strength: 1 });
      if (p.drums) p.notes = p.notes.map((n) => ({ ...n, end: n.start + 0.1 }));
      else p.notes = dedupe(p.notes);
    }
  }

  // 5) acordes con nombre
  let chordSegs = [];
  const harmonySrc = parts.find((p) => p.name === 'Acordes' || p.name === 'Piano');
  if (opts.chordNames && harmonySrc) {
    const withBass = parts.filter((p) => !p.drums && (p.name === 'Bajo' || p === harmonySrc)).flatMap((p) => p.notes);
    chordSegs = chords.detect(withBass, { bpm: tp?.bpm, phase: tp?.phase || 0, duration });
  }

  // tonalidad (de todo lo que no es batería)
  let key = null;
  try {
    const tonalNotes = parts.filter((p) => !p.drums).flatMap((p) => p.notes);
    if (tonalNotes.length >= 20) {
      const segs = chordSegs.length ? chordSegs : chords.detect(tonalNotes, { bpm: tp?.bpm, phase: tp?.phase || 0, duration });
      const c = require('../keybpm').keyFromNotes(tonalNotes, segs)[0];
      if (c && c.corr >= 0.55) key = c;
    }
  } catch {}

  // 6) escribir
  const base = path.basename(file, path.extname(file));
  const dir = path.dirname(file);
  const label = { melody: voice ? 'voz' : 'melodía', harmony: 'acordes', bass: 'bajo', drums: 'batería', piano: 'piano', full: 'multipista' }[mode];
  const bpm = tp?.bpm || 120;
  const mid = uniqueFile(dir, `${base} (MIDI ${label})`, '.mid');
  fs.writeFileSync(mid, smf.write({ bpm, parts, key, markers: chordSegs.map((c) => ({ time: c.start, text: c.name })) }));
  const outs = [mid];
  if (chordSegs.length) {
    const txt = uniqueFile(dir, `${base} (acordes)`, '.txt');
    fs.writeFileSync(txt, chords.toText(chordSegs, { bpm: tp?.bpm, phase: tp?.phase || 0, title: base, key }), 'utf8');
    outs.push(txt);
  }
  report(1);
  const count = parts.reduce((a, p) => a + p.notes.length, 0);
  if (!count) throw new Error('No encontré notas. Probá con más sensibilidad o activando "Separar antes".');
  return { files: outs, key: key?.name || null, bpm: tp?.bpm || null, notes: count, parts: parts.map((p) => ({ name: p.name, notes: p.notes.length })), chords: chordSegs.length };
}

// después de cuantizar pueden quedar dos notas iguales en el mismo lugar
function dedupe(notes) {
  const seen = new Map();
  for (const n of notes) {
    const k = `${n.pitch}@${n.start.toFixed(4)}`;
    const o = seen.get(k);
    if (!o || n.end - n.start > o.end - o.start) seen.set(k, n);
  }
  const out = [...seen.values()].sort((a, b) => a.start - b.start || a.pitch - b.pitch);
  // misma tecla: que no se pisen
  const last = new Map();
  for (const n of out) { const p = last.get(n.pitch); if (p && p.end > n.start) p.end = n.start; last.set(n.pitch, n); }
  return out.filter((n) => n.end > n.start);
}

module.exports = { convert, hasPiano, hasVoice };
