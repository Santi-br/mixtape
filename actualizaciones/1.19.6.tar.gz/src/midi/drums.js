// Batería → MIDI con ADTOF (Zehren et al., Frame_RNN; port a PyTorch de xavriley, exportado a ONNX).
// Clases: bombo, redoblante, toms, hi-hat, platillos. Espectrograma log-filtrado tipo madmom a 100 fps.
const path = require('path');
const ort = require('onnxruntime-node');
const FFT = require('fft.js');

const SR = 44100, FPS = 100, HOP = 441, NFFT = 2048;
const CLASSES = ['kick', 'snare', 'tom', 'hihat', 'cymbal'];
const THRESH = [0.22, 0.24, 0.32, 0.22, 0.30];
const GM = { kick: 36, snare: 38, tom: 47, hihat: 42, hihatOpen: 46, cymbal: 49 };

let sess = null;
async function session() {
  if (!sess) sess = await ort.InferenceSession.create(path.join(__dirname, '..', '..', 'models', 'midi', 'drums-adtof.onnx'), { graphOptimizationLevel: 'all', logSeverityLevel: 3 });
  return sess;
}

// banco de filtros logarítmico (12 por octava, 20 Hz–20 kHz), igual que madmom/ADTOF
let FB = null;
function filterbank() {
  if (FB) return FB;
  const freqs = [];
  for (let f = 20; f <= 20000 * (1 + 1e-12); f *= 2 ** (1 / 12)) freqs.push(f);
  const nb = NFFT / 2;
  const fftF = (k) => (k * SR) / NFFT;
  const bins = [];
  let last = -1;
  for (const f of freqs) {
    let best = 0, bd = Infinity;
    for (let k = 0; k < nb; k++) { const d = Math.abs(fftF(k) - f); if (d < bd) { bd = d; best = k; } }
    if (best > last) { bins.push(best); last = best; }
  }
  const filters = [];
  for (let i = 0; i < bins.length - 2; i++) {
    const l = bins[i], c = bins[i + 1], r = bins[i + 2];
    const w = new Map();
    if (r - l < 2) { w.set(l, 1); } else {
      for (let b = l; b < c; b++) w.set(b, (b - l) / (c - l));
      w.set(c, 1);
      for (let b = c + 1; b < Math.min(r, nb); b++) w.set(b, (r - b) / (r - c));
    }
    let s = 0; for (const v of w.values()) s += v;
    const idx = [...w.keys()], val = [...w.values()].map((v) => v / (s || 1));
    filters.push({ idx, val });
  }
  FB = filters;
  return FB;
}

function spectrogram(x) {
  const fb = filterbank();
  const NB = fb.length; // 84
  const T = 1 + Math.floor(x.length / HOP);
  const win = new Float64Array(NFFT);
  for (let i = 0; i < NFFT; i++) win[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (NFFT - 1)); // np.hanning
  const f = new FFT(NFFT);
  const inp = new Array(NFFT).fill(0), out = f.createComplexArray();
  const mag = new Float64Array(NFFT / 2);
  const spec = new Float32Array(T * NB);
  for (let t = 0; t < T; t++) {
    const c = t * HOP - NFFT / 2;
    for (let i = 0; i < NFFT; i++) { const j = c + i; inp[i] = j >= 0 && j < x.length ? x[j] * win[i] : 0; }
    f.realTransform(out, inp);
    for (let k = 0; k < NFFT / 2; k++) mag[k] = Math.hypot(out[2 * k], out[2 * k + 1]);
    for (let b = 0; b < NB; b++) {
      const { idx, val } = fb[b];
      let s = 0; for (let q = 0; q < idx.length; q++) s += mag[idx[q]] * val[q];
      spec[t * NB + b] = Math.log10(1 + s);
    }
  }
  return { spec, T, NB };
}

// corre el modelo de a pedazos de 30 s (con 2 s de contexto de cada lado)
async function activations(spec, T, NB, onProgress) {
  const s = await session();
  const CH = 3000, CTX = 200;
  const act = new Float32Array(T * 5);
  for (let a = 0; a < T; a += CH) {
    const b = Math.min(T, a + CH);
    const s0 = Math.max(0, a - CTX), s1 = Math.min(T, b + CTX);
    const len = s1 - s0;
    const x = spec.slice(s0 * NB, s1 * NB);
    const o = await s.run({ spec: new ort.Tensor('float32', x, [1, len, NB, 1]) });
    const y = o.act.data;
    act.set(y.subarray((a - s0) * 5, (b - s0) * 5), a * 5);
    onProgress?.(b / T);
  }
  return act;
}

// picos (port de madmom NotePeakPickingProcessor como lo usa ADTOF)
function pickPeaks(a, thr) {
  const n = a.length, preAvg = 10, postAvg = 1, preMax = 2, postMax = 1, combine = 2;
  const proc = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0;
    for (let k = i - preAvg; k <= i + postAvg; k++) s += a[Math.max(0, Math.min(n - 1, k))];
    proc[i] = Math.max(0, a[i] - s / (preAvg + postAvg + 1));
  }
  const peaks = [];
  for (let i = 0; i < n; i++) {
    let m = -Infinity;
    for (let k = i - preMax; k <= i + postMax; k++) m = Math.max(m, proc[Math.max(0, Math.min(n - 1, k))]);
    if (proc[i] >= m && proc[i] >= thr) peaks.push(i);
  }
  const kept = [];
  let g = [];
  for (const p of peaks) {
    if (g.length && p - g[g.length - 1] > combine) { kept.push(g.reduce((x, y) => (proc[y] > proc[x] ? y : x))); g = []; }
    g.push(p);
  }
  if (g.length) kept.push(g.reduce((x, y) => (proc[y] > proc[x] ? y : x)));
  return kept;
}

// x: audio mono 44.1 kHz de la batería. sensitivity 0..1 (0.5 = como el original)
async function transcribe(x, { sensitivity = 0.5, onProgress } = {}) {
  const { spec, T, NB } = spectrogram(x);
  onProgress?.(0.15);
  const act = await activations(spec, T, NB, (p) => onProgress?.(0.15 + 0.75 * p));
  const scale = 1.6 - 1.2 * sensitivity; // 0 → umbrales ×1.6, 1 → ×0.4
  const notes = [];
  // fuerza del golpe: volumen en una ventana corta después del ataque
  const level = (t) => {
    const a = Math.max(0, Math.round((t - 0.01) * SR)), b = Math.min(x.length, Math.round((t + 0.04) * SR));
    let m = 0; for (let i = a; i < b; i++) m = Math.max(m, Math.abs(x[i]));
    return m;
  };
  // energía aguda (últimas bandas) para distinguir hi-hat abierto/cerrado
  const hiBand = (t) => { let s = 0; for (let b = NB - 14; b < NB; b++) s += spec[t * NB + b]; return s; };
  for (let c = 0; c < 5; c++) {
    const a = new Float32Array(T);
    for (let t = 0; t < T; t++) a[t] = act[t * 5 + c];
    const pk = pickPeaks(a, THRESH[c] * scale);
    const lv = pk.map((t) => level(t / FPS));
    const sorted = lv.slice().sort((p, q) => p - q);
    const ref = sorted[Math.floor(sorted.length * 0.95)] || 1;
    pk.forEach((t, i) => {
      let pitch = GM[CLASSES[c]];
      if (CLASSES[c] === 'hihat' && t + 15 < T) {
        const h0 = hiBand(t), h1 = hiBand(t + 15);
        if (h0 > 0 && h1 / h0 > 0.55) pitch = GM.hihatOpen;
      }
      const v = Math.round(127 * Math.min(1, (lv[i] / ref)) ** 0.6);
      notes.push({ start: t / FPS, end: t / FPS + 0.1, pitch, velocity: Math.max(25, Math.min(127, v)), cls: CLASSES[c] });
    });
  }
  onProgress?.(1);
  return notes.sort((p, q) => p.start - q.start);
}

module.exports = { transcribe, spectrogram, activations, pickPeaks, SR, GM };
