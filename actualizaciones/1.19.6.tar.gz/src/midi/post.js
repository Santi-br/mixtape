// Limpieza de notas según el tipo de parte (melodía, bajo, acordes).
// notes: [{ start, end, pitch, velocity, amp }]

const HARM_UP = new Set([12, 19, 24, 28, 31]); // armónicos típicos (octava, quinta+octava, 2 octavas…)
const dur = (n) => n.end - n.start;
const overlap = (a, b) => Math.max(0, Math.min(a.end, b.end) - Math.max(a.start, b.start));

// Una nota a la vez (melodía / bajo)
function monophonic(notes, { preferLow = false, preferHigh = false, minDur = 0.06 } = {}) {
  const ns = notes.slice().sort((a, b) => a.start - b.start || a.pitch - b.pitch);
  // 1) grupos que arrancan juntos (±60 ms): queda una sola
  const groups = [];
  for (const n of ns) {
    const g = groups[groups.length - 1];
    if (g && n.start - g[0].start < 0.06) g.push(n); else groups.push([n]);
  }
  let picks = groups.map((g) => {
    let best = g.reduce((a, b) => (b.amp * Math.sqrt(dur(b)) > a.amp * Math.sqrt(dur(a)) ? b : a));
    // la fundamental suele ser más débil que su armónico: si hay una nota 1-2 octavas abajo, gana esa
    for (const c of g) {
      const d = best.pitch - c.pitch;
      if (HARM_UP.has(d) && c.amp >= (preferLow ? 0.3 : 0.6) * best.amp) best = c;
    }
    // melodía sobre acordes: la voz de arriba suele ser la melodía
    if (preferHigh) for (const c of g) if (c.pitch > best.pitch && !HARM_UP.has(c.pitch - best.pitch) && c.amp >= 0.55 * best.amp) best = c;
    // el ataque real es el más temprano del grupo (los graves el modelo los marca un poco tarde)
    return { ...best, start: Math.min(...g.map((c) => c.start)) };
  });
  // 2) notas que aparecen mientras suena otra y son su armónico: afuera
  const out = [];
  for (const n of picks) {
    const cur = out[out.length - 1];
    if (cur && n.start < cur.end - 0.04 && HARM_UP.has(n.pitch - cur.pitch) && n.amp < 1.15 * cur.amp) continue;
    if (cur && preferLow && n.start < cur.end - 0.04 && n.pitch - cur.pitch >= 12 && n.amp < 0.8 * cur.amp) continue;
    out.push({ ...n });
  }
  // 3) legato: cada nota termina cuando empieza la siguiente
  for (let i = 0; i < out.length - 1; i++) if (out[i].end > out[i + 1].start) out[i].end = out[i + 1].start;
  return out.filter((n) => dur(n) >= minDur);
}

// Acordes: saca armónicos y "fantasmas" graves que el modelo confunde con notas
function polyphonic(notes, { minDur = 0.05 } = {}) {
  const ns = notes.slice().sort((a, b) => a.start - b.start || a.pitch - b.pitch);
  const drop = new Set();
  for (let i = 0; i < ns.length; i++) {
    const n = ns[i];
    for (let j = 0; j < ns.length; j++) {
      if (i === j) continue;
      const m = ns[j];
      if (m.start > n.end) break;
      const ov = overlap(n, m);
      if (ov < 0.6 * dur(n)) continue;
      // n es armónico de m (más agudo) y bastante más débil
      if (HARM_UP.has(n.pitch - m.pitch) && Math.abs(n.start - m.start) < 0.08 && n.amp < 0.65 * m.amp) { drop.add(i); break; }
    }
  }
  return ns.filter((n, i) => !drop.has(i) && dur(n) >= minDur);
}

// mismo tono re-disparado sin ataque nuevo (cola que el modelo corta en dos): se une
function mergeRetriggers(notes, { gap = 0.035, ampRatio = 0.85 } = {}) {
  const byPitch = new Map();
  for (const n of notes.slice().sort((a, b) => a.start - b.start)) {
    const list = byPitch.get(n.pitch) || [];
    const last = list[list.length - 1];
    if (last && n.start - last.end <= gap && n.amp < ampRatio * last.amp) { last.end = Math.max(last.end, n.end); continue; }
    list.push({ ...n }); byPitch.set(n.pitch, list);
  }
  return [...byPitch.values()].flat().sort((a, b) => a.start - b.start || a.pitch - b.pitch);
}

function clampRange(notes, lo, hi) { return notes.filter((n) => n.pitch >= lo && n.pitch <= hi); }

module.exports = { monophonic, polyphonic, mergeRetriggers, clampRange };
