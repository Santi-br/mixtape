// Nombres de acordes a partir de notas (cromagrama por tiempo + plantillas).
const NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const NAMES_B = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];
const QUAL = [
  ['', [0, 4, 7]], ['m', [0, 3, 7]], ['7', [0, 4, 7, 10]], ['maj7', [0, 4, 7, 11]], ['m7', [0, 3, 7, 10]],
  ['dim', [0, 3, 6]], ['sus4', [0, 5, 7]], ['sus2', [0, 2, 7]],
];
// las tríadas simples ganan ante empates (más comunes)
const BONUS = { '': 0.06, m: 0.06, '7': 0.0, maj7: -0.02, m7: -0.01, dim: -0.05, sus4: -0.04, sus2: -0.05 };

function chromaOf(notes, a, b) {
  const c = new Float64Array(12);
  let bassP = null, bassW = 0;
  for (const n of notes) {
    const ov = Math.min(b, n.end) - Math.max(a, n.start);
    if (ov <= 0) continue;
    // la melodía (registro agudo) pesa menos que el acompañamiento
    const reg = n.pitch >= 76 ? 0.3 : n.pitch >= 69 ? 0.6 : 1;
    const w = ov * ((n.velocity ?? 80) / 127) * reg;
    c[n.pitch % 12] += w;
    // la nota más grave con peso importante (para elegir la tónica)
    if (bassP === null || n.pitch < bassP) { if (w > 0.15 * (b - a)) { bassP = n.pitch; bassW = w; } }
  }
  void bassW;
  return { c, bass: bassP === null ? null : bassP % 12 };
}

// puntaje de cada acorde posible para una ventana (null = silencio)
function scores({ c, bass }) {
  const tot = c.reduce((x, y) => x + y, 0);
  if (tot <= 1e-6) return null;
  const v = Array.from(c, (x) => x / tot);
  const out = [];
  for (let r = 0; r < 12; r++) {
    for (const [q, iv] of QUAL) {
      const set = new Set(iv.map((i) => (r + i) % 12));
      let inS = 0, outS = 0;
      for (let k = 0; k < 12; k++) (set.has(k) ? (inS += v[k]) : (outS += v[k]));
      const missing = iv.filter((i) => v[(r + i) % 12] < 0.04).length;
      out.push(inS - 0.8 * outS - 0.25 * missing + (BONUS[q] || 0) + (bass === r ? 0.2 : 0));
    }
  }
  return out;
}
const CANDS = [];
for (let r = 0; r < 12; r++) for (const [q] of QUAL) CANDS.push({ root: r, q });

// devuelve [{ start, end, name }]: ventanas de un pulso + suavizado (cambiar de acorde "cuesta")
function detect(notes, { bpm, phase = 0, duration }) {
  if (!notes.length) return [];
  const end = duration || Math.max(...notes.map((n) => n.end));
  const win = bpm ? 120 / bpm : 1.0; // medio compás
  const bt = bpm ? 60 / bpm : 0.5;
  let ph = bpm ? phase % bt : 0;
  if (ph > bt * 0.5) ph -= bt;
  const wins = [];
  for (let t = ph; t < end; t += win) wins.push({ start: Math.max(0, t), end: t + win, sc: scores(chromaOf(notes, Math.max(0, t), t + win)) });
  // Viterbi sobre los acordes posibles (+1 estado "sin acorde")
  const K = CANDS.length, NONE = K, PEN = 0.3;
  let prev = new Float64Array(K + 1), back = [];
  for (let i = 0; i < wins.length; i++) {
    const sc = wins[i].sc;
    const cur = new Float64Array(K + 1), bk = new Int32Array(K + 1);
    let bestPrev = 0; for (let k = 1; k <= K; k++) if (prev[k] > prev[bestPrev]) bestPrev = k;
    for (let k = 0; k <= K; k++) {
      const emit = k === NONE ? (sc ? 0.1 : 0.5) : (sc ? sc[k] : -0.5);
      const stay = prev[k], sw = prev[bestPrev] - PEN;
      if (i === 0 || stay >= sw) { cur[k] = stay + emit; bk[k] = k; } else { cur[k] = sw + emit; bk[k] = bestPrev; }
    }
    prev = cur; back.push(bk);
  }
  let k = 0; for (let j = 1; j <= K; j++) if (prev[j] > prev[k]) k = j;
  const path = new Array(wins.length);
  for (let i = wins.length - 1; i >= 0; i--) { path[i] = k; k = back[i][k]; }
  const used = path.filter((p) => p !== NONE).map((p) => CANDS[p].root);
  const useB = used.some((r) => [3, 10].includes(r)) && !used.some((r) => [6].includes(r));
  const out = [];
  wins.forEach((w, i) => {
    const p = path[i];
    const name = p === NONE ? null : (useB ? NAMES_B : NAMES)[CANDS[p].root] + CANDS[p].q;
    const last = out[out.length - 1];
    if (last && last.name === name) { last.end = w.end; return; }
    out.push({ start: w.start, end: w.end, name });
  });
  return out.filter((s) => s.name);
}

function toText(segs, { bpm, phase = 0, title, key }) {
  const lines = [`Acordes — ${title}`, bpm ? `Tempo: ${bpm} BPM (4/4)` : '', key ? `Tonalidad: ${key.name} (${key.label}, Camelot ${key.camelot})` : '', ''];
  for (const s of segs) {
    let where;
    if (bpm) {
      const bt = 60 / bpm;
      let ph = phase % bt; if (ph > bt * 0.5) ph -= bt;
      const beats = Math.max(0, Math.round((s.start - ph) / bt));
      const bar = Math.floor(beats / 4) + 1, beat = (beats % 4) + 1;
      where = `Compás ${String(bar).padStart(3)} · tiempo ${beat}`;
    } else {
      const m = Math.floor(s.start / 60), sec = (s.start % 60).toFixed(1).padStart(4, '0');
      where = `${m}:${sec}`;
    }
    lines.push(`${where}   ${s.name}`);
  }
  return lines.filter((l, i) => l !== '' || i === 3).join('\r\n') + '\r\n';
}

module.exports = { detect, toText };
