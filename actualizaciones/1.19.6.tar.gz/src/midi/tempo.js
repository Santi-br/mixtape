// Tempo (BPM) y fase del pulso a partir del audio: flujo espectral + autocorrelación + peine.
const FFT = require('fft.js');

const SR = 22050, HOP = 256, NFFT = 1024;
const FPS = SR / HOP;

function onsetEnvelope(x) {
  const T = Math.floor(x.length / HOP);
  const f = new FFT(NFFT);
  const inp = new Array(NFFT).fill(0), out = f.createComplexArray();
  const win = new Float64Array(NFFT);
  for (let i = 0; i < NFFT; i++) win[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / NFFT);
  const nb = NFFT / 2;
  let prev = new Float64Array(nb), cur = new Float64Array(nb);
  const env = new Float32Array(T), low = new Float32Array(T);
  for (let t = 0; t < T; t++) {
    const c = t * HOP - NFFT / 2;
    for (let i = 0; i < NFFT; i++) { const j = c + i; inp[i] = j >= 0 && j < x.length ? x[j] * win[i] : 0; }
    f.realTransform(out, inp);
    let s = 0, sl = 0;
    for (let k = 1; k < nb; k++) {
      cur[k] = Math.log1p(1000 * Math.hypot(out[2 * k], out[2 * k + 1]));
      const d = cur[k] - prev[k]; if (d > 0) { s += d; if (k <= 5) sl += d; }
    }
    env[t] = s; low[t] = sl;
    [prev, cur] = [cur, prev];
  }
  return { env: detrend(env), low: detrend(low) };
}
// quitar la tendencia lenta y normalizar
function detrend(env) {
  const T = env.length;
  const w = Math.round(FPS); const o = new Float32Array(T);
  let acc = 0;
  for (let t = 0; t < T; t++) {
    acc += env[t]; if (t >= w) acc -= env[t - w];
    o[t] = Math.max(0, env[t] - acc / Math.min(t + 1, w));
  }
  let m = 0; for (const v of o) m = Math.max(m, v);
  if (m > 0) for (let t = 0; t < T; t++) o[t] /= m;
  return o;
}

// devuelve { bpm, phase (s del primer pulso), confidence }
function estimate(x, { min = 70, max = 180, prior = 105, beatTimes = null } = {}) {
  const { env, low } = onsetEnvelope(x);
  const T = env.length;
  if (T < FPS * 4) return null;
  // autocorrelación pesada con una preferencia suave por ~105 BPM
  let best = null;
  const scores = [];
  for (let bpm = min; bpm <= max; bpm += 0.5) {
    const lag = (60 / bpm) * FPS;
    let s = 0;
    for (const mult of [1, 2, 4]) {
      const L = lag * mult, l0 = Math.floor(L), fr = L - l0;
      let a = 0;
      for (let t = 0; t + l0 + 1 < T; t++) a += env[t] * (env[t + l0] * (1 - fr) + env[t + l0 + 1] * fr);
      s += a / (mult === 1 ? 1 : 2);
    }
    const w = Math.exp(-0.5 * (Math.log2(bpm / prior) / 0.9) ** 2);
    scores.push([bpm, s * w]);
    if (!best || s * w > best[1]) best = [bpm, s * w];
  }
  // afinar con peine: probar ±1.5 BPM en pasos de 0.05 maximizando la energía en la grilla
  const comb = (bpm) => {
    const per = (60 / bpm) * FPS;
    let bestP = 0, bestV = -1;
    for (let ph = 0; ph < per; ph += 0.5) {
      let v = 0;
      for (let t = ph; t < T - 1; t += per) { const i = Math.floor(t), fr = t - i; v += env[i] * (1 - fr) + env[i + 1] * fr; }
      if (v > bestV) { bestV = v; bestP = ph; }
    }
    return [bestV / (T / per), bestP];
  };
  let fine = [best[0], ...comb(best[0])];
  for (let b = best[0] - 1.5; b <= best[0] + 1.5; b += 0.05) {
    const [v, ph] = comb(b);
    if (v > fine[1]) fine = [b, v, ph];
  }
  const bpm = Math.round(fine[0] * 10) / 10;
  // fase: los graves (bombo, bajo) marcan el pulso mejor que los agudos (redoblante del dembow, hi-hat)
  {
    const per = (60 / bpm) * FPS;
    let bestV = -1, bestP = 0;
    for (let ph = 0; ph < per; ph += 0.25) {
      let v = 0;
      for (let t = ph; t < T - 1; t += per) {
        const i = Math.floor(t), fr = t - i;
        v += 2 * (low[i] * (1 - fr) + low[i + 1] * fr) + (env[i] * (1 - fr) + env[i + 1] * fr);
      }
      if (beatTimes) for (const bt of beatTimes) { const d = ((bt * FPS - ph) % per + per) % per; if (Math.min(d, per - d) < 2) v += 3; }
      if (v > bestV) { bestV = v; bestP = ph; }
    }
    fine[2] = bestP;
  }
  const sorted = scores.map((s) => s[1]).sort((a, b) => b - a);
  const confidence = sorted.length > 1 ? 1 - sorted[Math.min(10, sorted.length - 1)] / sorted[0] : 0;
  return { bpm, phase: fine[2] / FPS, confidence };
}

// cuantiza notas a la grilla (division: 4 = semicorcheas, 2 = corcheas, 1 = negras), con fase
function quantize(notes, { bpm, phase = 0 }, division, { strength = 1 } = {}) {
  const g = 60 / bpm / division;
  const snap = (t) => phase + Math.round((t - phase) / g) * g;
  return notes.map((n) => {
    const s = n.start + (snap(n.start) - n.start) * strength;
    let e = n.end + (snap(n.end) - n.end) * strength;
    if (e <= s + 1e-3) e = s + g;
    return { ...n, start: Math.max(0, s), end: e };
  });
}

module.exports = { estimate, quantize, onsetEnvelope, SR };
