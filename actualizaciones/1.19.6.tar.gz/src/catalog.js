// Qué muestra la rueda según el tipo de archivo.
// formats = anillo interior (convertir), actions = anillo exterior (herramientas)

const IMAGE_EXTS = ['jpg', 'jpeg', 'png', 'webp', 'avif', 'gif', 'tif', 'tiff', 'bmp'];
const PDF_EXTS = ['pdf'];
const AUDIO_EXTS = ['mp3', 'wav', 'flac', 'm4a', 'aac', 'ogg', 'opus', 'aif', 'aiff', 'wma', 'mp2', 'mpga', 'm4b', 'oga', 'amr', 'ac3', 'caf', 'mka', 'wv', 'ape', 'au'];
const VIDEO_EXTS = ['mp4', 'mov', 'mkv', 'webm', 'avi', 'm4v', 'wmv', 'flv', '3gp', 'mpeg', 'mpg', 'mpe', 'm2v', 'm1v', 'mts', 'm2ts', 'ts', 'vob', 'ogv', '3g2', 'f4v', 'asf', 'divx', 'dv', 'mxf'];

const catalog = {
  image: {
    formats: [
      { id: 'jpg', label: 'JPG' },
      { id: 'png', label: 'PNG' },
      { id: 'webp', label: 'WEBP' },
      { id: 'avif', label: 'AVIF' },
      { id: 'pdf', label: 'PDF' },
      { id: 'gif', label: 'GIF' },
      { id: 'tiff', label: 'TIFF' },
      { id: 'bmp', label: 'BMP' },
      { id: 'ico', label: 'ICO' },
    ],
    actions: [
      { id: 'compress', label: 'Comprimir', icon: 'compress', dialog: true },
      { id: 'crop', label: 'Recortar', icon: 'crop', dialog: true, single: true },
      { id: 'resize', label: 'Tamaño', icon: 'resize', dialog: true },
      { id: 'rmbg', label: 'Quitar fondo', icon: 'rmbg' },
      { id: 'upscale', label: 'Mejorar', icon: 'upscale', dialog: true },
      { id: 'ocr', label: 'A texto', icon: 'text' },
      { id: 'blur', label: 'Blurear', icon: 'blur', dialog: true, single: true },
      { id: 'background', label: 'Fondo', icon: 'background', dialog: true, single: true },
      { id: 'rotate', label: 'Rotar', icon: 'rotate', dialog: true },
      { id: 'strip', label: 'Metadata', icon: 'strip' },
      { id: 'rename', label: 'Renombrar', icon: 'rename', dialog: true },
    ],
  },
  audio: {
    formats: [
      { id: 'mp3', label: 'MP3' },
      { id: 'wav', label: 'WAV' },
      { id: 'flac', label: 'FLAC' },
      { id: 'm4a', label: 'M4A' },
      { id: 'aiff', label: 'AIFF' },
      { id: 'ogg', label: 'OGG' },
      { id: 'mp4', label: 'MP4' },
    ],
    actions: [
      { id: 'vedit', label: 'Editar / unir', icon: 'vedit', dialog: true },
      { id: 'vtrim', label: 'Recortar', icon: 'trim', dialog: true, single: true },
      { id: 'transcribe', label: 'A texto', icon: 'text', dialog: true, single: true },
      { id: 'stems', label: 'Stems', icon: 'stems', dialog: true, single: true },
      { id: 'stems2', label: 'Voz / Inst', icon: 'vocal' },
      { id: 'midi', label: 'A MIDI', icon: 'midi', dialog: true, single: true },
      { id: 'keybpm', label: 'Key / BPM', icon: 'keybpm' },
      { id: 'normalize', label: 'Normalizar', icon: 'normalize' },
      { id: 'strip', label: 'Metadata', icon: 'strip' },
      { id: 'rename', label: 'Renombrar', icon: 'rename', dialog: true },
    ],
  },
  video: {
    formats: [
      { id: 'mp4', label: 'MP4' },
      { id: 'mov', label: 'MOV' },
      { id: 'webm', label: 'WEBM' },
      { id: 'gif', label: 'GIF' },
      { id: 'mp3', label: 'MP3' },
      { id: 'wav', label: 'WAV' },
    ],
    actions: [
      { id: 'vtrim', label: 'Recortar', icon: 'trim', dialog: true, single: true },
      { id: 'transcribe', label: 'A texto', icon: 'text', dialog: true, single: true },
      { id: 'compress', label: 'Comprimir', icon: 'compress', dialog: true },
      { id: 'mute', label: 'Sin audio', icon: 'mute' },
      { id: 'stems', label: 'Stems', icon: 'stems', dialog: true, single: true },
      { id: 'stems2', label: 'Voz / Inst', icon: 'vocal' },
      { id: 'midi', label: 'A MIDI', icon: 'midi', dialog: true, single: true },
      { id: 'keybpm', label: 'Key / BPM', icon: 'keybpm' },
      { id: 'rename', label: 'Renombrar', icon: 'rename', dialog: true },
    ],
  },
  // video + audio arrastrados juntos
  mix: {
    formats: [
      { id: 'av_replace', label: 'Reemplazar audio' },
      { id: 'av_mix', label: 'Sumar audio' },
    ],
    actions: [
      { id: 'vedit', label: 'Editar / unir', icon: 'vedit', dialog: true },
      { id: 'av_adjust', label: 'Ajustar…', icon: 'sliders', dialog: true },
      { id: 'rename', label: 'Renombrar', icon: 'rename', dialog: true },
    ],
  },
  // link arrastrado desde el navegador
  link: {
    formats: [
      { id: 'dl_video', label: 'Video' },
      { id: 'dl_mp3', label: 'MP3' },
      { id: 'dl_wav', label: 'WAV' },
    ],
    actions: [
      { id: 'dl_options', label: 'Opciones…', icon: 'sliders' },
    ],
  },
  // cualquier otro archivo (o mezclas raras): por ahora solo renombrar
  other: {
    formats: [],
    actions: [
      { id: 'rename', label: 'Renombrar', icon: 'rename', dialog: true },
    ],
  },
  // imágenes y PDFs arrastrados juntos: se unen en un solo PDF, en el orden en que vienen
  docs: {
    formats: [
      { id: 'pdf_join', label: 'PDF' },
    ],
    actions: [
      { id: 'pdf_join', label: 'Unir', icon: 'merge', multi: true },
      { id: 'rename', label: 'Renombrar', icon: 'rename', dialog: true },
    ],
  },
  pdf: {
    formats: [
      { id: 'png', label: 'PNG' },
      { id: 'jpg', label: 'JPG' },
      { id: 'webp', label: 'WEBP' },
      { id: 'txt', label: 'TXT' },
    ],
    actions: [
      { id: 'merge', label: 'Unir', icon: 'merge', multi: true },
      { id: 'split', label: 'Separar', icon: 'split' },
      { id: 'rotate', label: 'Rotar', icon: 'rotate', dialog: true },
      { id: 'strip', label: 'Metadata', icon: 'strip' },
      { id: 'rename', label: 'Renombrar', icon: 'rename', dialog: true },
    ],
  },
};

function kindFromExt(ext) {
  ext = String(ext || '').toLowerCase().replace(/^\./, '');
  if (IMAGE_EXTS.includes(ext)) return 'image';
  if (PDF_EXTS.includes(ext)) return 'pdf';
  if (AUDIO_EXTS.includes(ext)) return 'audio';
  if (VIDEO_EXTS.includes(ext)) return 'video';
  return null;
}

function kindFromMime(mime) {
  mime = String(mime || '').toLowerCase();
  if (mime === 'application/pdf') return 'pdf';
  if (mime.startsWith('image/')) return 'image';
  if (mime.startsWith('audio/')) return 'audio';
  if (mime.startsWith('video/')) return 'video';
  return null;
}

module.exports = { catalog, kindFromExt, kindFromMime, IMAGE_EXTS, PDF_EXTS, AUDIO_EXTS, VIDEO_EXTS };
