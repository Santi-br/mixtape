// Baja e instala un paquete en un hilo aparte (descomprimir bz2 es pesado y no tiene que trabar la app).
const { parentPort, workerData } = require('worker_threads');
const { installWhisper } = require('./packs');
let last = 0;
installWhisper(workerData.dest, { onProgress: (p) => { if (p - last >= 0.005 || p >= 1) { last = p; parentPort.postMessage({ p }); } } })
  .then((dir) => parentPort.postMessage({ done: dir }))
  .catch((e) => parentPort.postMessage({ error: String(e.message || e) }));
