// Editor de video básico: pistas de video (la de arriba tapa a la de abajo) y de audio (se mezclan).
// El editor (editor/vedit.js) arma el proyecto y acá se exporta a MP4 con un solo ffmpeg (filter_complex).
//
// proyecto = {
//   format: 'first' | '16:9' | '9:16' | '1:1',
//   tracks: [{ id, kind: 'v' | 'a', hidden, muted }],   // V1 es la de abajo de todo
//   clips: [{ file, kind: 'video' | 'image' | 'audio', track, start, in, out, volume, mute, fadeIn, fadeOut,
//             box: 'full' | 'tl' | 'tr' | 'bl' | 'br', w, h, hasAudio }]
// }
const fs = require('fs');
const os = require('os');
const path = require('path');
const av = require('./av');

const FPS = 30;
const FADE = 0.6;
const even = (n) => Math.max(2, Math.round(n / 2) * 2);
const fx = (n) => Number(n).toFixed(3);

function outputSize(p) {
  if (p.format === '16:9') return [1920, 1080];
  if (p.format === '9:16') return [1080, 1920];
  if (p.format === '1:1') return [1080, 1080];
  const vt = p.tracks.filter((t) => t.kind === 'v').map((t) => t.id);
  const first = p.clips.filter((c) => c.kind !== 'audio' && c.w && c.h)
    .sort((a, b) => vt.indexOf(a.track) - vt.indexOf(b.track) || a.start - b.start)[0];
  if (!first) return [1920, 1080];
  const k = Math.min(1, 1920 / Math.max(first.w, first.h));
  return [even(first.w * k), even(first.h * k)];
}

// dónde y de qué tamaño va un clip de video en el cuadro final
function placement(c, W, H) {
  const ar = c.w && c.h ? c.w / c.h : W / H;
  if (!c.box || c.box === 'full') {
    let w = W, h = W / ar;
    if (h > H) { h = H; w = H * ar; }
    w = even(w); h = even(h);
    return { w, h, x: Math.round((W - w) / 2), y: Math.round((H - h) / 2) };
  }
  const m = Math.round(Math.min(W, H) * 0.04);
  let w = W * 0.34, h = w / ar;
  if (h > H * 0.45) { h = H * 0.45; w = h * ar; }
  w = even(w); h = even(h);
  const x = c.box.endsWith('l') ? m : W - w - m;
  const y = c.box.startsWith('t') ? m : H - h - m;
  return { w, h, x, y };
}

function duration(p) {
  return Math.max(0, ...p.clips.map((c) => c.start + (c.out - c.in)));
}

function buildArgs(p, outFile) {
  const tracks = new Map(p.tracks.map((t, i) => [t.id, { ...t, order: i }]));
  const vOrder = p.tracks.filter((t) => t.kind === 'v').map((t) => t.id); // V1 primero
  const [W, H] = outputSize(p);
  const T = duration(p);
  if (!(T > 0)) throw new Error('No hay nada en la línea de tiempo');
  const args = ['-f', 'lavfi', '-i', `color=c=black:s=${W}x${H}:r=${FPS}:d=${fx(T)}`, '-f', 'lavfi', '-i', `anullsrc=r=48000:cl=stereo:d=${fx(T)}`];
  const f = [];
  let base = '[0:v]', n = 2, k = 0;
  const audios = ['[1:a]'];
  const vis = p.clips.filter((c) => { const t = tracks.get(c.track); return t && !t.hidden && c.out > c.in; });
  const vclips = vis.filter((c) => c.kind !== 'audio').sort((a, b) => vOrder.indexOf(a.track) - vOrder.indexOf(b.track) || a.start - b.start);
  const aclips = vis.filter((c) => (c.kind === 'audio' || (c.kind === 'video' && c.hasAudio)) && !c.mute && !tracks.get(c.track).muted && (c.volume ?? 1) > 0);
  const inputOf = new Map();
  const addInput = (c) => {
    if (inputOf.has(c)) return inputOf.get(c);
    const d = c.out - c.in;
    if (c.kind === 'image') args.push('-loop', '1', '-framerate', String(FPS), '-t', fx(d), '-i', c.file);
    else args.push('-ss', fx(c.in), '-t', fx(d), '-i', c.file);
    inputOf.set(c, n);
    return n++;
  };
  for (const c of vclips) {
    const i = addInput(c), d = c.out - c.in, pl = placement(c, W, H);
    const fadeD = Math.min(FADE, d / 3);
    let chain = `[${i}:v]setpts=PTS-STARTPTS,fps=${FPS},scale=${pl.w}:${pl.h}:flags=bicubic,setsar=1,format=yuva420p`;
    if (c.fadeIn) chain += `,fade=t=in:st=0:d=${fx(fadeD)}:alpha=1`;
    if (c.fadeOut) chain += `,fade=t=out:st=${fx(Math.max(0, d - fadeD))}:d=${fx(fadeD)}:alpha=1`;
    chain += `,setpts=PTS+${fx(c.start)}/TB[c${k}]`;
    f.push(chain);
    f.push(`${base}[c${k}]overlay=x=${pl.x}:y=${pl.y}:eof_action=pass:enable='between(t,${fx(c.start)},${fx(c.start + d)})'[b${k}]`);
    base = `[b${k}]`; k++;
  }
  f.push(`${base}format=yuv420p[vout]`);
  let j = 0;
  for (const c of aclips) {
    const i = addInput(c), d = c.out - c.in, fadeD = Math.min(FADE, d / 3), ms = Math.round(c.start * 1000);
    let chain = `[${i}:a]asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=stereo,volume=${fx(c.volume ?? 1)}`;
    if (c.fadeIn) chain += `,afade=t=in:st=0:d=${fx(fadeD)}`;
    if (c.fadeOut) chain += `,afade=t=out:st=${fx(Math.max(0, d - fadeD))}:d=${fx(fadeD)}`;
    chain += `,adelay=${ms}|${ms}[a${j}]`;
    f.push(chain); audios.push(`[a${j}]`); j++;
  }
  f.push(`${audios.join('')}amix=inputs=${audios.length}:duration=first:dropout_transition=0:normalize=0,alimiter=limit=0.97[aout]`);
  const script = path.join(os.tmpdir(), `mixtape-edit-${process.pid}-${Date.now()}.txt`);
  fs.writeFileSync(script, f.join(';\n'));
  args.push('-filter_complex_script', script, '-map', '[vout]', '-map', '[aout]',
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', '-r', String(FPS),
    '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', '-t', fx(T), outFile);
  return { args, script, T, W, H };
}

async function exportProject(p, { onProgress } = {}) {
  const first = p.clips.find((c) => c.kind === 'video') || p.clips[0];
  const dir = path.dirname(first.file);
  const name = path.basename(first.file, path.extname(first.file));
  let out = path.join(dir, `${name} (editado).mp4`);
  for (let i = 2; fs.existsSync(out); i++) out = path.join(dir, `${name} (editado ${i}).mp4`);
  const { args, script, T } = buildArgs(p, out);
  try { await av.ffmpeg(args, { duration: T, onProgress }); }
  finally { try { fs.unlinkSync(script); } catch {} }
  return out;
}

module.exports = { exportProject, buildArgs, outputSize, placement, duration };
