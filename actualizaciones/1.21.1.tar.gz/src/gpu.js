// Sesiones de onnxruntime con placa de video "verificada".
// Algunas placas/drivers dan resultados erróneos con DirectML (ruido a todo volumen en los stems).
// La primera vez que un modelo corre en la placa, el mismo pedazo se calcula también con el
// procesador y se comparan. Si no coinciden, la placa se deja de usar (y se recuerda).
const fs = require('fs');
const os = require('os');
const path = require('path');
const ort = require('onnxruntime-node');

const STATE_FILE = path.join(process.env.RUEDITA_USERDATA || os.tmpdir(), 'gpu-estado.json');
// 1.21.1: la placa se desactiva por modelo (o grupo, ej. "stems"), no para todo: que los stems hayan salido
// con ruido no tiene por qué apagar la placa para Mejorar. Cada modelo igual se verifica contra el procesador.
let state = { broken: false, checked: {}, bad: {} };
try { state = { ...state, ...JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')) }; } catch {}
if (!state.bad || typeof state.bad !== 'object') state.bad = {};
const save = () => { try { fs.writeFileSync(STATE_FILE, JSON.stringify(state)); } catch {} };
// lo de antes (desactivada para todo) se pasa a los stems, que es donde se vio el problema
if (state.broken) { state.bad.stems = state.bad.stems || 'desactivada antes de 1.21.1'; state.broken = false; save(); }

const BASE = { graphOptimizationLevel: 'all', logSeverityLevel: 3, enableCpuMemArena: false, enableMemPattern: false };

// Windows: DirectML. Mac: CoreML (Neural Engine / GPU). En los dos se verifica contra el procesador.
const GPU_EP = process.platform === 'win32' ? 'dml' : 'coreml';
function gpuAllowed(key, group) {
  if (!(process.platform === 'win32' || process.platform === 'darwin') || state.broken) return false;
  return !(key && state.bad[key]) && !(group && state.bad[group]);
}
// scope: nombre del modelo o grupo ("stems"); sin scope = toda la placa
function markBroken(reason, scope) {
  console.error(`[gpu] placa de video desactivada${scope ? ` para ${scope}` : ''}:`, reason);
  if (scope) state.bad[scope] = String(reason || 'error').slice(0, 200); else state.broken = true;
  save();
}

function maxRelDiff(a, b) {
  let maxRef = 0, maxD = 0;
  for (let i = 0; i < a.length; i++) {
    const x = a[i], y = b[i];
    if (!Number.isFinite(x)) return Infinity;
    maxRef = Math.max(maxRef, Math.abs(y));
    maxD = Math.max(maxD, Math.abs(x - y));
  }
  return maxD / (maxRef || 1);
}

class SafeSession {
  constructor(file, group) { this.file = file; this.key = path.basename(file); this.group = group || null; this.s = null; this.provider = 'cpu'; this.verified = false; }

  async init() {
    if (gpuAllowed(this.key, this.group)) {
      try {
        this.s = await ort.InferenceSession.create(this.file, { ...BASE, executionProviders: [GPU_EP] });
        this.provider = GPU_EP;
        this.verified = !!state.checked[path.basename(this.file)];
        return this;
      } catch (e) { markBroken(e.message, this.key); }
    }
    this.s = await ort.InferenceSession.create(this.file, { ...BASE, executionProviders: ['cpu'] });
    this.provider = 'cpu';
    return this;
  }

  async toCpu() {
    try { await this.s.release(); } catch {}
    this.s = await ort.InferenceSession.create(this.file, { ...BASE, executionProviders: ['cpu'] });
    this.provider = 'cpu';
  }

  async run(feeds) {
    if (this.provider === 'cpu') return this.s.run(feeds);
    let out;
    try { out = await this.s.run(feeds); } catch (e) {
      markBroken(e.message, this.key); await this.toCpu(); return this.s.run(feeds);
    }
    if (!this.verified) {
      // comparar con el procesador una vez por modelo
      const cpu = await ort.InferenceSession.create(this.file, { ...BASE, executionProviders: ['cpu'] });
      const ref = await cpu.run(feeds);
      let worst = 0;
      for (const k of Object.keys(ref)) worst = Math.max(worst, maxRelDiff(out[k].data, ref[k].data));
      if (worst > 0.02) {
        markBroken(`resultado distinto al del procesador (${worst.toFixed(3)}) en ${this.key}`, this.key);
        try { await this.s.release(); } catch {}
        this.s = cpu; this.provider = 'cpu';
        return ref;
      }
      try { await cpu.release(); } catch {}
      this.verified = true;
      state.checked[path.basename(this.file)] = true; save();
    }
    return out;
  }

  async release() { try { await this.s.release(); } catch {} }
}

async function createSession(file, group) { return new SafeSession(file, group).init(); }

module.exports = { createSession, gpuAllowed, markBroken, resetGpu: () => { state = { broken: false, checked: {}, bad: {} }; save(); } };
