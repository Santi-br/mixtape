// Batería → MIDI con dettato-drums (KobiMusic / Nathan Mills, 2026, Apache-2.0: código y pesos).
// Se usa solo el modelo "drum-kit" (189K parámetros, entrenado únicamente con audio sintético propio del autor).
// Exportado a ONNX en dos partes (src/models-midi): embed (CNN + GRU por bandas, local) y trunk (GRUs + atención
// sobre toda la canción + cabezas por familia), igual que DrumNet.embed / DrumNet.trunk.
// Escribe golpes en las teclas GM 27–87 con velocidad. Necesita una fuente grabada a 40 kHz o más: lee la banda 7,8–20 kHz.
//
// Features (port de dettato/drums/features.py, solo lo que usa el drum-kit: 160 bandas a 100 cuadros por segundo):
//   lo (128) mel 20 Hz–7,8 kHz  de la señal a 16 kHz, STFT 512, salto 160
//   hi (32)  mel 7,8–20 kHz     de la señal a 44,1 kHz, STFT 1411, salto 441
//   todo con el nivel llevado a RMS −18 dBFS y log(potencia + 1e-5); Hann periódica, centrado con ceros (torch.stft).
const path = require('path');
const ort = require('onnxruntime-node');
const FFT = require('fft.js');

const SR = 44100, FPS_OUT = 50, FLOOR = 1e-5;
const MIN_SOURCE_RATE = 40000;
const KEYS = Array.from({ length: 61 }, (_, i) => 27 + i);
const MODELS = path.join(__dirname, '..', 'models-midi');

let sEmbed = null, sTrunk = null;
async function sessions() {
  const o = { graphOptimizationLevel: 'all', logSeverityLevel: 3 };
  if (!sEmbed) sEmbed = await ort.InferenceSession.create(path.join(MODELS, 'drums-dettato-embed.onnx'), o);
  if (!sTrunk) sTrunk = await ort.InferenceSession.create(path.join(MODELS, 'drums-dettato-trunk.onnx'), o);
  return { sEmbed, sTrunk };
}

// --- bancos de filtros (iguales a mel_filterbank de dettato: mel HTK, triangulares, normalizados Slaney) ---
const hzToMel = (f) => 2595 * Math.log10(1 + f / 700);
const melToHz = (m) => 700 * (10 ** (m / 2595) - 1);
function melFilterbank(sr, nFft, nMels, fmin, fmax) {
  const nBins = Math.floor(nFft / 2) + 1;
  const freqs = Float64Array.from({ length: nBins }, (_, k) => (k * (sr / 2)) / (nBins - 1));
  const m0 = hzToMel(fmin), m1 = hzToMel(fmax);
  const pts = Array.from({ length: nMels + 2 }, (_, i) => melToHz(m0 + ((m1 - m0) * i) / (nMels + 1)));
  const fb = [];
  for (let i = 0; i < nMels; i++) {
    const lo = pts[i], c = pts[i + 1], hi = pts[i + 2];
    const norm = 2 / (pts[i + 2] - pts[i]);
    const idx = [], val = [];
    for (let k = 0; k < nBins; k++) {
      const up = (freqs[k] - lo) / Math.max(c - lo, 1e-9), down = (hi - freqs[k]) / Math.max(hi - c, 1e-9);
      const w = Math.max(0, Math.min(up, down));
      if (w > 0) { idx.push(k); val.push(Math.fround(Math.fround(w) * Math.fround(norm))); }
    }
    fb.push({ idx, val });
  }
  return fb;
}

// Hann periódica (torch.hann_window)
const hann = (n) => Float64Array.from({ length: n }, (_, i) => 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / n));

// FFT real de largo N cualquiera: potencia de 2 con fft.js; si no (1411 = 17 × 83), Bluestein con una FFT de 4096
function makePowerSpectrum(N) {
  const nBins = Math.floor(N / 2) + 1;
  if ((N & (N - 1)) === 0) {
    const f = new FFT(N), out = f.createComplexArray(), inp = new Array(N);
    return (frame, pow) => {
      for (let i = 0; i < N; i++) inp[i] = frame[i];
      f.realTransform(out, inp);
      for (let k = 0; k < nBins; k++) pow[k] = out[2 * k] * out[2 * k] + out[2 * k + 1] * out[2 * k + 1];
    };
  }
  let M = 1; while (M < 2 * N - 1) M <<= 1;
  const f = new FFT(M);
  // chirp: w_n = exp(-iπ n²/N)
  const cr = new Float64Array(N), ci = new Float64Array(N);
  for (let n = 0; n < N; n++) { const a = (Math.PI * ((n * n) % (2 * N))) / N; cr[n] = Math.cos(a); ci[n] = -Math.sin(a); }
  const b = f.createComplexArray();
  for (let i = 0; i < 2 * M; i++) b[i] = 0;
  for (let n = 0; n < N; n++) { b[2 * n] = cr[n]; b[2 * n + 1] = -ci[n]; if (n) { b[2 * (M - n)] = cr[n]; b[2 * (M - n) + 1] = -ci[n]; } }
  const B = f.createComplexArray(); f.transform(B, b);
  const a = f.createComplexArray(), A = f.createComplexArray(), c = f.createComplexArray();
  return (frame, pow) => {
    for (let i = 0; i < 2 * M; i++) a[i] = 0;
    for (let n = 0; n < N; n++) { a[2 * n] = frame[n] * cr[n]; a[2 * n + 1] = frame[n] * ci[n]; }
    f.transform(A, a);
    for (let k = 0; k < M; k++) {
      const re = A[2 * k] * B[2 * k] - A[2 * k + 1] * B[2 * k + 1], im = A[2 * k] * B[2 * k + 1] + A[2 * k + 1] * B[2 * k];
      A[2 * k] = re; A[2 * k + 1] = im;
    }
    f.inverseTransform(c, A);
    for (let k = 0; k < nBins; k++) {
      const re = c[2 * k] * cr[k] - c[2 * k + 1] * ci[k], im = c[2 * k] * ci[k] + c[2 * k + 1] * cr[k];
      pow[k] = re * re + im * im;
    }
  };
}

// log-mel de x (centrado con ceros) → escribe en out[t*stride + off + b] para t < T
function logMel(x, nFft, hop, fb, T, out, stride, off) {
  const win = hann(nFft), half = Math.floor(nFft / 2), nBins = half + 1;
  const spec = makePowerSpectrum(nFft);
  const frame = new Float64Array(nFft), pow = new Float64Array(nBins);
  for (let t = 0; t < T; t++) {
    const c = t * hop - half;
    for (let i = 0; i < nFft; i++) { const j = c + i; frame[i] = j >= 0 && j < x.length ? x[j] * win[i] : 0; }
    spec(frame, pow);
    for (let b = 0; b < fb.length; b++) {
      const { idx, val } = fb[b];
      let s = 0; for (let q = 0; q < idx.length; q++) s += pow[idx[q]] * val[q];
      out[t * stride + off + b] = Math.log(s + FLOOR);
    }
  }
}

let FB = null;
// x44: mono 44,1 kHz; x16: la misma señal a 16 kHz (sin normalizar: se normaliza acá con la ganancia de x44)
function features(x44, x16) {
  if (!FB) FB = { lo: melFilterbank(16000, 512, 128, 20, 7800), hi: melFilterbank(SR, 1411, 32, 7800, 20000) };
  let ss = 0; for (let i = 0; i < x44.length; i++) ss += x44[i] * x44[i];
  const g = 10 ** (-18 / 20) / (Math.sqrt(ss / Math.max(1, x44.length)) + 1e-9);
  const a44 = new Float32Array(x44.length), a16 = new Float32Array(x16.length);
  for (let i = 0; i < x44.length; i++) a44[i] = x44[i] * g;
  for (let i = 0; i < x16.length; i++) a16[i] = x16[i] * g;
  // cuadros: los de lo (1 + len/160) y hi (1 + len/441) y len16/160 → el menor
  const T = Math.min(Math.floor(a16.length / 160), 1 + Math.floor(a16.length / 160), 1 + Math.floor(a44.length / 441));
  const F = new Float32Array(T * 160);
  logMel(a16, 512, 160, FB.lo, T, F, 160, 0);
  logMel(a44, 1411, 441, FB.hi, T, F, 160, 128);
  return { F, T };
}

// embed por ventanas de 8000 cuadros con 200 de contexto (DrumNet.embed_long), trunk sobre toda la canción
async function probabilities(F, T0, onProgress) {
  const { sEmbed: se, sTrunk: st } = await sessions();
  const T = Math.floor(T0 / 2) * 2;
  const W = 88, N = T / 2;
  const emb = new Float32Array(N * W);
  const CH = 8000, MG = 200;
  const long = T > 9000;
  for (let s = 0; s < T; s += long ? CH : T) {
    const a = long ? Math.max(0, s - MG) : 0, b = long ? Math.min(T, s + CH + MG) : T;
    const len = b - a;
    const o = await se.run({ feats: new ort.Tensor('float32', F.subarray(a * 160, b * 160), [1, len, 160]) });
    const h = o.emb.data;
    const lo = Math.floor((s - a) / 2), n = Math.floor(((long ? Math.min(s + CH, T) : T) - s) / 2);
    emb.set(h.subarray(lo * W, (lo + n) * W), (s / 2) * W);
    onProgress?.(0.8 * Math.min(1, (s + (long ? CH : T)) / T));
  }
  const r = await st.run({ emb: new ort.Tensor('float32', emb, [1, N, W]) });
  onProgress?.(1);
  return { onset: r.onset.data, vel: r.vel.data, N };
}

// picos ≥ th, máximos locales, al menos `gap` cuadros entre golpes de la misma tecla (dettato peaks)
function peaks(P, N, L, th, gap = 3) {
  const out = [];
  const last = new Int32Array(L).fill(-10);
  for (let t = 0; t < N; t++) {
    for (let l = 0; l < L; l++) {
      const v = P[t * L + l];
      if (v < th) continue;
      const left = t ? P[(t - 1) * L + l] : v, right = t < N - 1 ? P[(t + 1) * L + l] : v;
      if (v >= left && v >= right && t - last[l] > gap - 1) { out.push([t, l]); last[l] = t; }
    }
  }
  return out;
}

// familias para no escribir el mismo golpe dos veces (ej. redoblante 38 y 40 juntos)
const FAMILY = {};
for (const k of [35, 36]) FAMILY[k] = 'bombo';
for (const k of [37, 38, 39, 40]) FAMILY[k] = 'redoblante';
for (const k of [41, 43, 45, 47, 48, 50]) FAMILY[k] = 'toms';
for (const k of [42, 44, 46]) FAMILY[k] = 'hihat';
for (const k of [49, 51, 52, 53, 55, 57, 59]) FAMILY[k] = 'platillos';

// Ajustes medidos en MDB Drums++ (23 baterías reales, solo para medir): umbral 0.4 (0.5 en el original), un golpe
// por familia cada 30 ms (el más probable) y un hi-hat cerrado con algo de probabilidad de ride (≥ 0.15) se escribe
// ride: el modelo confunde el ride con el hi-hat en grabaciones reales. F1 por tipo de golpe: 0.67 → 0.78.
const TH = 0.4, RIDE_FROM_HH = 0.15, SAME_HIT_S = 0.03;
const I42 = KEYS.indexOf(42), I51 = KEYS.indexOf(51);

// x44 y x16: audio mono de la batería (o la mezcla). sensitivity 0..1 (0.5 = lo medido)
async function transcribe(x44, x16, { sensitivity = 0.5, onProgress } = {}) {
  if (x44.length < SR / 10) return [];
  const { F, T } = features(x44, x16);
  onProgress?.(0.2);
  const { onset, vel, N } = await probabilities(F, T, (p) => onProgress?.(0.2 + 0.75 * p));
  const L = KEYS.length;
  const th = Math.max(0.1, Math.min(0.9, TH * (1.6 - 1.2 * sensitivity)));
  const hits = peaks(onset, N, L, th).map(([t, l]) => {
    let key = KEYS[l];
    if (l === I42 && onset[t * L + I51] >= RIDE_FROM_HH) key = 51;
    return { t, key, p: onset[t * L + l], v: vel[t * L + l] };
  });
  // un golpe por familia en 30 ms: gana el más probable
  hits.sort((a, b) => b.p - a.p);
  const kept = [], seen = {};
  for (const h of hits) {
    const fam = FAMILY[h.key] || h.key;
    const s = h.t / FPS_OUT, list = (seen[fam] ||= []);
    if (list.some((q) => Math.abs(q - s) <= SAME_HIT_S)) continue;
    list.push(s);
    kept.push(h);
  }
  const notes = kept.map((h) => {
    const v = Math.max(0.05, Math.min(1, h.v));
    return { start: h.t / FPS_OUT, end: h.t / FPS_OUT + 0.1, pitch: h.key, velocity: Math.max(1, Math.min(127, Math.round(v * 127))) };
  });
  onProgress?.(1);
  return notes.sort((p, q) => p.start - q.start || p.pitch - q.pitch);
}

module.exports = { transcribe, features, probabilities, peaks, KEYS, SR, MIN_SOURCE_RATE };
