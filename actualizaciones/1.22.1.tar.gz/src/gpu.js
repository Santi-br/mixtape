// Sesiones de onnxruntime con placa de video "verificada".
// Algunas placas/drivers dan resultados erróneos con DirectML (ruido a todo volumen en los stems).
// La primera vez que un modelo corre en la placa, el mismo pedazo se calcula también con el
// procesador y se comparan. Si no coinciden, la placa se deja de usar (y se recuerda).
const fs = require('fs');
const os = require('os');
const path = require('path');
const ort = require('onnxruntime-node');

const STATE_FILE = path.join(process.env.RUEDITA_USERDATA || os.tmpdir(), 'gpu-estado.json');
// 1.21.1: la placa se desactiva por modelo (o grupo, ej. "stems"), no para todo: que los stems hayan salido
// con ruido no tiene por qué apagar la placa para Mejorar. Cada modelo igual se verifica contra el procesador.
let state = { broken: false, checked: {}, bad: {} };
try { state = { ...state, ...JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')) }; } catch {}
if (!state.bad || typeof state.bad !== 'object') state.bad = {};
const save = () => { try { fs.writeFileSync(STATE_FILE, JSON.stringify(state)); } catch {} };
// lo de antes (desactivada para todo) se pasa a los stems, que es donde se vio el problema
if (state.broken) { state.bad.stems = state.bad.stems || 'desactivada antes de 1.21.1'; state.broken = false; save(); }

const BASE = { graphOptimizationLevel: 'all', logSeverityLevel: 3, enableCpuMemArena: false, enableMemPattern: false };

// Windows: DirectML. Mac: CoreML (Neural Engine / GPU). En los dos se verifica contra el procesador.
const GPU_EP = process.platform === 'win32' ? 'dml' : 'coreml';
function gpuAllowed(key, group) {
  if (!(process.platform === 'win32' || process.platform === 'darwin') || state.broken) return false;
  return !(key && state.bad[key]) && !(group && state.bad[group]);
}
// scope: nombre del modelo o grupo ("stems"); sin scope = toda la placa
function markBroken(reason, scope) {
  console.error(`[gpu] placa de video desactivada${scope ? ` para ${scope}` : ''}:`, reason);
  if (scope) state.bad[scope] = String(reason || 'error').slice(0, 200); else state.broken = true;
  save();
}

function maxRelDiff(a, b) {
  let maxRef = 0, maxD = 0;
  for (let i = 0; i < a.length; i++) {
    const x = a[i], y = b[i];
    if (!Number.isFinite(x)) return Infinity;
    maxRef = Math.max(maxRef, Math.abs(y));
    maxD = Math.max(maxD, Math.abs(x - y));
  }
  return maxD / (maxRef || 1);
}

// Windows: las notebooks suelen tener dos placas (Intel integrada + NVIDIA/AMD). DirectML usa la 0 si no se le dice,
// y esa suele ser la integrada (lenta). pickDml() prueba cada una con un modelo y se queda con la más rápida que
// da bien (comparada con el procesador). Se recuerda en gpu-estado.json (dmlDevice).
const gpuEp = () => (GPU_EP === 'dml' && Number.isInteger(state.dmlDevice) && state.dmlDevice >= 0 ? { name: 'dml', deviceId: state.dmlDevice } : GPU_EP);
let picking = null;
async function pickDml(file, feeds) {
  if (process.platform !== 'win32' || state.broken || Number.isInteger(state.dmlDevice)) return;
  if (picking) return picking;
  picking = (async () => {
    let ref = null;
    try { const cpu = await ort.InferenceSession.create(file, { ...BASE, executionProviders: ['cpu'] }); ref = await cpu.run(feeds); await cpu.release(); } catch { return; }
    const found = [];
    for (let d = 0; d < 4; d++) {
      let s = null;
      try {
        s = await ort.InferenceSession.create(file, { ...BASE, executionProviders: [{ name: 'dml', deviceId: d }] });
        const out = await s.run(feeds);
        let worst = 0;
        for (const k of Object.keys(ref)) worst = Math.max(worst, maxRelDiff(out[k].data, ref[k].data));
        const t0 = Date.now();
        await s.run(feeds); await s.run(feeds);
        const ms = (Date.now() - t0) / 2;
        found.push({ d, ms, ok: worst <= 0.02 });
        console.log(`[gpu] placa ${d}: ${ms.toFixed(0)} ms, ${worst <= 0.02 ? 'da bien' : `da distinto (${worst.toFixed(3)})`}`);
      } catch (e) { if (d > 0) { try { await s?.release(); } catch {} break; } }
      try { await s?.release(); } catch {}
    }
    const best = found.filter((f) => f.ok).sort((a, b) => a.ms - b.ms)[0];
    state.dmlDevice = best ? best.d : 0;
    state.dmlTried = found;
    // con otra placa, lo verificado y lo desactivado antes (con la 0) se vuelve a probar
    if (best && best.d !== 0) { state.checked = {}; state.bad = {}; }
    save();
  })();
  try { await picking; } finally { picking = null; }
}

class SafeSession {
  constructor(file, group) { this.file = file; this.key = path.basename(file); this.group = group || null; this.s = null; this.provider = 'cpu'; this.verified = false; }

  async init() {
    if (gpuAllowed(this.key, this.group)) {
      try {
        this.s = await ort.InferenceSession.create(this.file, { ...BASE, executionProviders: [gpuEp()] });
        this.provider = GPU_EP;
        this.verified = !!state.checked[path.basename(this.file)];
        return this;
      } catch (e) { markBroken(e.message, this.key); }
    }
    this.s = await ort.InferenceSession.create(this.file, { ...BASE, executionProviders: ['cpu'] });
    this.provider = 'cpu';
    return this;
  }

  async toCpu() {
    try { await this.s.release(); } catch {}
    this.s = await ort.InferenceSession.create(this.file, { ...BASE, executionProviders: ['cpu'] });
    this.provider = 'cpu';
  }

  async run(feeds) {
    if (this.provider === 'cpu') return this.s.run(feeds);
    let out;
    try { out = await this.s.run(feeds); } catch (e) {
      markBroken(e.message, this.key); await this.toCpu(); return this.s.run(feeds);
    }
    if (!this.verified) {
      // comparar con el procesador una vez por modelo
      const cpu = await ort.InferenceSession.create(this.file, { ...BASE, executionProviders: ['cpu'] });
      const ref = await cpu.run(feeds);
      let worst = 0;
      for (const k of Object.keys(ref)) worst = Math.max(worst, maxRelDiff(out[k].data, ref[k].data));
      if (worst > 0.02) {
        markBroken(`resultado distinto al del procesador (${worst.toFixed(3)}) en ${this.key}`, this.key);
        try { await this.s.release(); } catch {}
        this.s = cpu; this.provider = 'cpu';
        return ref;
      }
      try { await cpu.release(); } catch {}
      this.verified = true;
      state.checked[path.basename(this.file)] = true; save();
    }
    return out;
  }

  async release() { try { await this.s.release(); } catch {} }
}

async function createSession(file, group) { return new SafeSession(file, group).init(); }

const gpuInfo = () => ({ dmlDevice: state.dmlDevice, dmlTried: state.dmlTried || [] });
module.exports = { createSession, pickDml, gpuAllowed, markBroken, gpuInfo, resetGpu: () => { state = { broken: false, checked: {}, bad: {} }; save(); } };
