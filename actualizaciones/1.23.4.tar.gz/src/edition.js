// Edición de MIXTAPE: "amigos" (la de la web privada, con todo) o "venta" (la que se vende).
// La de venta no trae lo que no se puede vender: el descargador (YouTube/Spotify: choca con sus términos),
// la voz cantada de MIDI Pro (GAME, licencia no comercial) y Orquesta (MVSep, sin licencia pública).
// Se lee del package.json de la INSTALACIÓN (no del de una actualización chica), así un parche no la cambia.
const fs = require('fs');
const path = require('path');

const OFF = { venta: ['download', 'orquesta', 'voz'] };

function read() {
  if (process.env.MX_EDITION) return process.env.MX_EDITION;
  const roots = [global.MX && global.MX.bundledRoot, path.join(__dirname, '..')].filter(Boolean);
  for (const r of roots) {
    try { const p = JSON.parse(fs.readFileSync(path.join(r, 'package.json'), 'utf8')); if (p.mixtape && p.mixtape.edition) return p.mixtape.edition; } catch {}
  }
  return 'amigos';
}
const EDITION = read();
const has = (feature) => !(OFF[EDITION] || []).includes(feature);
module.exports = { EDITION, has, flags: () => ({ edition: EDITION, download: has('download'), orquesta: has('orquesta'), voz: has('voz') }) };
