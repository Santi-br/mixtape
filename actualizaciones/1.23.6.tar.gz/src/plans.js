// Qué trae cada versión de SHIX (solo en la edición "venta"; la de amigos trae todo).
// Gratis (USD 0) · Pro (USD 19,99) · Premium (USD 39,99; 29,99 lanzamiento) · Estudio (USD 59,99) · Prueba (7 días de Premium)
// Una sola tabla para la rueda, el inicio, Todas y las ventanas. Cada herramienta dice desde qué versión está.
// Reglas de textos: nunca la palabra "pagar"; se dice "comprar", "activar", "una sola vez".

const PLANS = ['free', 'pro', 'premium', 'studio'];
const RANK = { free: 0, pro: 1, premium: 2, trial: 2, studio: 3 };
const NAMES = { free: 'Gratis', pro: 'Pro', premium: 'Premium', trial: 'Prueba de Premium', studio: 'Estudio' };

// archivos a la vez por versión (Infinity = sin límite)
const BATCH = { free: 1, pro: 5, premium: Infinity, trial: Infinity, studio: Infinity };
// compus por clave
const SEATS = { free: 1, pro: 1, premium: 2, studio: 5 };
// Pro: solo la versión 1 (las actualizaciones a 2.x piden Premium o comprar Pro 2)
const PRO_MAX_MAJOR = 1;

// formatos de Gratis (convertir): pocos y comunes
const FREE_FORMATS = {
  image: ['jpg', 'png'],
  audio: ['mp3', 'wav'],
  video: ['mp4', 'mp3'],
};

// herramienta → versión mínima. Clave: "<tipo>:<id>" o "*:<id>" (cualquier tipo). Lo que no figura → premium.
const TOOLS = {
  // imagen
  'image:compress': 'free', 'image:crop': 'free', 'image:rotate': 'free', 'image:resize': 'free',
  'image:rmbg': 'pro', 'image:background': 'pro', 'image:strip': 'pro',
  'image:upscale': 'premium', 'image:ocr': 'premium', 'image:blur': 'premium',
  // audio
  'audio:vtrim': 'pro', 'audio:stems2': 'pro', 'audio:normalize': 'pro', 'audio:strip': 'pro',
  'audio:vedit': 'premium', 'audio:transcribe': 'premium', 'audio:stems': 'premium', 'audio:midi': 'premium', 'audio:keybpm': 'premium',
  // video
  'video:compress': 'free',
  'video:vtrim': 'pro', 'video:rotate': 'pro', 'video:mute': 'pro', 'video:stems2': 'pro',
  'video:vupscale': 'premium', 'video:transcribe': 'premium', 'video:stems': 'premium', 'video:midi': 'premium', 'video:keybpm': 'premium',
  // audio + video juntos
  'mix:av_replace': 'pro', 'mix:av_mix': 'pro', 'mix:av_adjust': 'pro', 'mix:vedit': 'premium',
  // PDF (todo PDF solo en Premium y Estudio)
  'pdf:merge': 'premium', 'pdf:split': 'premium', 'pdf:rotate': 'premium', 'pdf:strip': 'premium',
  'docs:pdf_join': 'premium',
  // renombrar en tanda
  '*:rename': 'premium',
};
// extras dentro de una herramienta
const EXTRAS = {
  'vtrim-crop': 'premium', // encuadrar (9:16, 1:1, 4:5, 16:9) al cortar video
  'resize-ai': 'premium', // agrandar con IA en "Tamaño"
  'convert-all': 'pro', // todos los formatos de salida
  'convert-pdf': 'premium', // imagen → PDF y PDF → imagen/texto
};

// versión mínima para una acción de la rueda / Todas
function required({ kind, ring, id }) {
  if (ring === 'format') {
    if (kind === 'pdf' || kind === 'docs' || id === 'pdf' || id === 'pdf_join') return EXTRAS['convert-pdf'];
    if (kind === 'audio' && id === 'mp4') return 'pro'; // A MP4 con la tapa
    if (kind === 'mix') return TOOLS[`mix:${id}`] || 'pro';
    if (kind === 'link') return 'premium';
    return (FREE_FORMATS[kind] || []).includes(id) ? 'free' : EXTRAS['convert-all'];
  }
  return TOOLS[`${kind}:${id}`] || TOOLS[`*:${id}`] || 'premium';
}

const allows = (plan, need) => (RANK[plan] ?? 0) >= RANK[need];

module.exports = { PLANS, RANK, NAMES, BATCH, SEATS, PRO_MAX_MAJOR, FREE_FORMATS, TOOLS, EXTRAS, required, allows };
