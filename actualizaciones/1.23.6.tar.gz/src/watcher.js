// Detecta "arrastrando un archivo + Shift" leyendo el estado del mouse/teclado.
// Windows: user32 (GetAsyncKeyState...). Mac: CoreGraphics (CGEventSource...State).
const { EventEmitter } = require('events');

// Explorador, escritorio y navegadores (para arrastrar links). La rueda igual solo se muestra
// si lo que se arrastra es un archivo o un link.
const ALLOWED_ROOTS = new Set(['CabinetWClass', 'ExploreWClass', 'Progman', 'WorkerW', 'Chrome_WidgetWin_1', 'MozillaWindowClass']);

class DragWatcher extends EventEmitter {
  constructor() {
    super();
    this.enabled = true;
    this.anyApp = false;
    this.timer = null;
    this.state = { down: false, start: null, allowed: false, fired: false };
    this.mac = process.platform === 'darwin';
    if (this.mac) { this.initMac(); return; }
    if (process.platform !== 'win32') return;

    const koffi = require('koffi');
    const user32 = koffi.load('user32.dll');
    const POINT = koffi.struct('RUEDITA_POINT', { x: 'long', y: 'long' });
    this.GetAsyncKeyState = user32.func('short __stdcall GetAsyncKeyState(int vKey)');
    this.GetCursorPos = user32.func('bool __stdcall GetCursorPos(_Out_ RUEDITA_POINT *pt)');
    this.WindowFromPoint = user32.func('void * __stdcall WindowFromPoint(RUEDITA_POINT pt)');
    this.GetAncestor = user32.func('void * __stdcall GetAncestor(void *hwnd, uint32_t flags)');
    this.GetClassNameW = user32.func('int __stdcall GetClassNameW(void *hwnd, void *buf, int max)');
    this.GetSystemMetrics = user32.func('int __stdcall GetSystemMetrics(int index)');
    this.SetCursorPos = user32.func('bool __stdcall SetCursorPos(int x, int y)');
  }

  // Windows: la rueda aparece debajo del mouse, pero el arrastre recién "entra" en ella cuando el mouse se mueve.
  // Si la persona lo tiene quieto, no aparece. Un empujoncito de 1 px (y vuelta) hace que Windows lo note ya.
  nudge() {
    if (this.mac || !this.SetCursorPos || !this.state.down) return;
    try {
      const p = this.cursor();
      this.SetCursorPos(p.x + 1, p.y);
      setTimeout(() => { try { const q = this.cursor(); if (q.x === p.x + 1 && q.y === p.y) this.SetCursorPos(p.x, p.y); } catch {} }, 25);
    } catch {}
  }

  // ---------- Mac ----------
  initMac() {
    const koffi = require('koffi');
    const cg = koffi.load('/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics');
    // estado combinado de la sesión (0): no hace falta escuchar eventos, solo preguntar
    this.CGEventSourceFlagsState = cg.func('uint64_t CGEventSourceFlagsState(int32_t state)');
    this.CGEventSourceButtonState = cg.func('bool CGEventSourceButtonState(int32_t state, uint32_t button)');
    this.CGEventSourceKeyState = cg.func('bool CGEventSourceKeyState(int32_t state, uint16_t key)');
    try {
      this.CGPreflightListenEventAccess = cg.func('bool CGPreflightListenEventAccess()');
      this.CGRequestListenEventAccess = cg.func('bool CGRequestListenEventAccess()');
    } catch {}
  }

  // pide el permiso de "Monitoreo de entrada" si hace falta (macOS 10.15+); devuelve si ya está dado
  ensureMacAccess() {
    if (!this.mac || !this.CGPreflightListenEventAccess) return true;
    try {
      if (this.CGPreflightListenEventAccess()) return true;
      this.CGRequestListenEventAccess();
    } catch {}
    return false;
  }

  macFlags() { try { return Number(this.CGEventSourceFlagsState(0)); } catch { return 0; } }

  isDown(vk) {
    if (this.mac) {
      if (vk === 0x01) return this.CGEventSourceButtonState(0, 0);
      if (vk === 0x1b) return this.CGEventSourceKeyState(0, 53); // Esc
      const f = this.macFlags();
      if (vk === 0x10) return (f & 0x20000) !== 0;  // Shift
      if (vk === 0x11) return (f & 0x40000) !== 0;  // Control
      if (vk === 0x12) return (f & 0x80000) !== 0;  // Option
      return false;
    }
    if (vk === 0x10 && this.guardShift) return true; // Shift escondido al Explorador (ver shiftguard.js)
    return (this.GetAsyncKeyState(vk) & 0x8000) !== 0;
  }

  // Windows: que el Explorador no reciba el Shift mientras hay un archivo agarrado (si no, selecciona
  // todo lo que hay entre los archivos elegidos). Corre en un proceso aparte: si falla, no rompe nada.
  syncGuard() {
    if (this.mac || process.platform !== 'win32' || this.noGuard) return;
    const want = this.enabled && this.usesShift() ? (this.anyApp ? '1' : '0') : null;
    if (want === this.guardCfg) return;
    this.guardCfg = want;
    this.guardShift = false;
    if (this.guard) { try { this.guard.kill(); } catch {} this.guard = null; }
    if (want === null) return;
    try {
      const { spawn } = require('child_process');
      const path = require('path');
      const g = spawn(process.execPath, [path.join(__dirname, 'shiftguard.js'), want], {
        env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }, stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true,
      });
      this.guard = g; this.guardOk = false;
      let buf = '';
      g.stdout.on('data', (d) => {
        buf += d;
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          if (line === 'S1') this.guardShift = true;
          else if (line === 'S0') this.guardShift = false;
          else if (line === 'OK') this.guardOk = true;
        }
      });
      g.on('exit', (code) => {
        if (this.guard !== g) return;
        this.guard = null; this.guardShift = false;
        // si se cayó apenas arrancó, no se reintenta (queda como antes: el Shift llega al Explorador)
        this.guardRestarts = (this.guardRestarts || 0) + 1;
        if (!this.guardOk || this.guardRestarts > 5) { this.noGuard = true; this.emit('guard-failed', code); } else this.guardCfg = undefined;
      });
    } catch (e) { this.noGuard = true; this.emit('guard-failed', String(e.message || e)); }
  }

  stopGuard() {
    if (this.guard) { try { this.guard.kill(); } catch {} this.guard = null; }
    this.guardShift = false; this.guardCfg = undefined;
  }

  // ¿la tecla elegida usa Shift? (solo entonces hace falta esconderle el Shift al Explorador)
  usesShift() {
    if (this.key === 'custom') {
      const c = this.custom || {};
      if (this.mac) return false;
      if (Array.isArray(c.combo)) return c.combo.some((g) => g.some((v) => v === 0x10 || v === 0xa0 || v === 0xa1));
      return (c.vks || []).some((v) => v === 0x10 || v === 0xa0 || v === 0xa1);
    }
    return this.key !== 'alt';
  }

  // tecla elegida: 'shift' | 'alt' | 'ctrlshift' | 'custom' (cualquier otra, guardada en this.custom = { vks, mks })
  keyHeld() {
    if (this.key === 'custom') {
      const c = this.custom || {};
      const macDown = (k) => { try { return this.CGEventSourceKeyState(0, k); } catch { return false; } };
      const down = this.mac ? macDown : (v) => this.isDown(v);
      // combinación: tienen que estar apretadas todas (cada grupo = izquierda/derecha de la misma tecla)
      if (Array.isArray(c.combo) && c.combo.length) return c.combo.every((g) => g.some(down));
      if (this.mac) return (c.mks || []).some(macDown);
      return (c.vks || []).some((v) => this.isDown(v));
    }
    const shift = this.isDown(0x10), ctrl = this.isDown(0x11), alt = this.isDown(0x12);
    if (this.key === 'alt') return alt && !ctrl;
    if (this.key === 'ctrlshift') return ctrl && shift;
    return shift && !ctrl && !alt;
  }

  // "Elegir otra tecla": espera hasta `ms` a que se apriete una tecla nueva (no del mouse) y devuelve cuál.
  // Lee el estado físico del teclado (no depende del idioma del teclado). Windows: códigos VK; Mac: keycodes.
  captureKey(ms = 10000) {
    return new Promise((resolve) => {
      const scan = () => {
        const down = new Set();
        if (this.mac) { for (let k = 0; k < 128; k++) { try { if (this.CGEventSourceKeyState(0, k)) down.add(k); } catch {} } }
        else if (this.GetAsyncKeyState) { for (let v = 0x08; v <= 0xfe; v++) { if (v >= 0x10 && v <= 0x12) continue; if ((this.GetAsyncKeyState(v) & 0x8000) !== 0) down.add(v); } }
        return down;
      };
      const base = scan(), t0 = Date.now();
      const iv = setInterval(() => {
        const now = scan();
        const fresh = [...now].filter((k) => !base.has(k));
        for (const k of base) if (!now.has(k)) base.delete(k); // si se soltó, puede volver a contar
        if (fresh.length) { clearInterval(iv); resolve(this.mac ? { mk: fresh[0] } : { vk: fresh[0] }); }
        else if (Date.now() - t0 > ms) { clearInterval(iv); resolve(null); }
      }, 30);
    });
  }

  // "Elegir combinación": junta todas las teclas que se aprietan (en cualquier orden, hasta 4) y termina cuando se
  // sueltan todas. Devuelve la lista de códigos físicos (Windows: VK izquierda/derecha; Mac: keycodes).
  captureCombo(ms = 15000) {
    return new Promise((resolve) => {
      const scan = () => {
        const down = new Set();
        if (this.mac) { for (let k = 0; k < 128; k++) { try { if (this.CGEventSourceKeyState(0, k)) down.add(k); } catch {} } }
        else if (this.GetAsyncKeyState) { for (let v = 0x08; v <= 0xfe; v++) { if (v >= 0x10 && v <= 0x12) continue; if (v <= 0x06) continue; if ((this.GetAsyncKeyState(v) & 0x8000) !== 0) down.add(v); } }
        return down;
      };
      const base = scan(), t0 = Date.now(), got = [];
      let started = false;
      const iv = setInterval(() => {
        const now = scan();
        for (const k of base) if (!now.has(k)) base.delete(k);
        const fresh = [...now].filter((k) => !base.has(k));
        for (const k of fresh) if (!got.includes(k) && got.length < 6) got.push(k);
        if (fresh.length) started = true;
        if (started && !fresh.length) { clearInterval(iv); resolve(this.mac ? { mks: got } : { vks: got }); }
        else if (!started && Date.now() - t0 > ms) { clearInterval(iv); resolve(null); }
      }, 25);
    });
  }

  cursor() {
    if (this.mac) { const p = require('electron').screen.getCursorScreenPoint(); return { x: p.x, y: p.y }; }
    const pt = {};
    this.GetCursorPos(pt);
    return pt;
  }

  rootClassAt(pt) {
    if (this.mac) return '';
    try {
      const hwnd = this.WindowFromPoint(pt);
      if (!hwnd) return '';
      const root = this.GetAncestor(hwnd, 2 /* GA_ROOT */) || hwnd;
      const buf = Buffer.alloc(512);
      const n = this.GetClassNameW(root, buf, 256);
      return buf.toString('utf16le', 0, n * 2);
    } catch {
      return '';
    }
  }

  start() {
    if ((process.platform !== 'win32' && !this.mac) || this.timer) return;
    this.timer = setInterval(() => this.tick(), 30);
  }

  stop() {
    clearInterval(this.timer);
    this.timer = null;
    this.stopGuard();
  }

  tick() {
    // medición (1.22.2): cuánto se atrasa el vigía (si la app está trabada, los ticks de 30 ms se separan)
    const now = Date.now();
    if (this.state.down && this.lastTick) this.state.maxGap = Math.max(this.state.maxGap || 0, now - this.lastTick);
    this.lastTick = now;
    this.syncGuard();
    if (!this.enabled) return;
    const swapped = !this.mac && this.GetSystemMetrics(23 /* SM_SWAPBUTTON */) !== 0;
    const lDown = this.isDown(swapped ? 0x02 : 0x01);
    const s = this.state;

    if (lDown && !s.down) {
      const pt = this.cursor();
      const cls = this.rootClassAt(pt);
      // en Mac no hay forma barata de saber la app de abajo: se permite siempre y la rueda
      // igual queda invisible si lo que se arrastra no es un archivo o un link
      this.state = { down: true, start: pt, allowed: !this.paused && (this.mac || this.anyApp || ALLOWED_ROOTS.has(cls)), fired: false, cls, downAt: now, maxGap: 0 };
      return;
    }

    if (!lDown && s.down) {
      const fired = s.fired;
      this.state = { down: false, start: null, allowed: false, fired: false };
      if (fired) this.emit('release');
      return;
    }

    if (lDown && s.down && !s.fired && s.allowed) {
      if (!this.keyHeld()) return;
      if (!s.keyAt) s.keyAt = now;
      const pt = this.cursor();
      const dist = Math.hypot(pt.x - s.start.x, pt.y - s.start.y);
      if (dist < 24) return;
      s.fired = true;
      this.lastTiming = { downAt: s.downAt, keyAt: s.keyAt, firedAt: now, gap: s.maxGap, guard: !!this.guardShift, cls: s.cls };
      this.emit('trigger', pt);
    }

    if (s.fired && this.isDown(0x1b /* VK_ESCAPE */)) this.emit('cancel');
  }
}

module.exports = { DragWatcher };
