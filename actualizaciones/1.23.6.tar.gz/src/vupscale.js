// Mejorar video con IA (1.21.0): el mismo modelo de "Mejorar" de las fotos (Real-ESRGAN), cuadro por cuadro.
// Corre en un proceso aparte (el mismo ejecutable de la app con ELECTRON_RUN_AS_NODE) así la app no se traba
// mientras trabaja, y "Cancelar" lo corta en el acto.
//   ffmpeg (decodifica a RGB) → IA ×4 → achica con lanczos al tamaño final → ffmpeg (H.264 + el audio original)
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// Lado más largo que entra a la IA (más grande se achica antes). El modelo agranda ×4, así que con 960 ya sale 4K.
//   rápida: 720 y hasta 30 cuadros por segundo (≈8 veces menos trabajo que un 1080p entero, ×2 más si era de 60 fps)
//   normal: 960 y hasta 30 cuadros por segundo
//   máxima: 1920 y todos los cuadros
// sin placa de video (procesador) rápida y normal trabajan más chico todavía
const MAX_AI = { fast: 720, normal: 960, max: 1920 };
const MAX_AI_CPU = { fast: 540, normal: 640, max: 1920 };
const MAX_FPS = { fast: 30, normal: 30, max: 240 };
const Q = (q) => (q === 'max' || q === 'normal' ? q : 'fast');
const MAX_OUT = 3840; // lado más largo del resultado (4K)
const TILE_GPU = 1024; // en la placa, un cuadro de video chico entra entero
const even = (n) => Math.max(2, Math.floor(n / 2) * 2);

// Tamaños: lo que entra a la IA y lo que sale. scale: 1 (mismo tamaño, solo limpia) | 2 | 4
function plan(w, h, scale, quality = 'fast', gpu = true) {
  scale = [1, 2, 4].includes(+scale) ? +scale : 2;
  const q = Q(quality), long = Math.max(w, h), cap = (gpu ? MAX_AI : MAX_AI_CPU)[q];
  const kIn = long > cap ? cap / long : 1;
  const aiW = even(w * kIn), aiH = even(h * kIn);
  let tw = w * scale, th = h * scale;
  const kOut = Math.max(tw, th) > MAX_OUT ? MAX_OUT / Math.max(tw, th) : 1;
  tw = even(tw * kOut); th = even(th * kOut);
  return { aiW, aiH, tw, th, capped: kOut < 1 };
}

// ---------------- dentro del proceso aparte ----------------
// Lee de un stream pedazos de exactamente n bytes
function frameReader(stream, n) {
  let chunks = [], have = 0, ended = false, waiting = null, error = null;
  stream.on('data', (d) => {
    chunks.push(d); have += d.length;
    if (have >= n * 3) stream.pause();
    if (waiting && have >= n) { const w = waiting; waiting = null; w(); }
  });
  stream.on('end', () => { ended = true; if (waiting) { const w = waiting; waiting = null; w(); } });
  stream.on('error', (e) => { error = e; ended = true; if (waiting) { const w = waiting; waiting = null; w(); } });
  return async function next() {
    while (have < n && !ended) await new Promise((r) => { waiting = r; stream.resume(); });
    if (error) throw error;
    if (have < n) return null;
    const all = chunks.length === 1 ? chunks[0] : Buffer.concat(chunks);
    const frame = Buffer.from(all.subarray(0, n));
    const rest = all.subarray(n);
    chunks = rest.length ? [rest] : []; have = rest.length;
    if (have < n * 3) stream.resume();
    return frame;
  };
}

const writeAsync = (stream, buf) => new Promise((resolve, reject) => {
  const ok = stream.write(buf, (e) => { if (e) reject(e); });
  if (ok) resolve(); else stream.once('drain', resolve);
});

async function work(a, send) {
  const { videoRunner, upscaleProvider } = require('./ai');
  const sharp = require('sharp');
  const BIN = require('./bins').FFMPEG;
  const q = Q(a.quality);
  const gpu = (await upscaleProvider(a.style)) !== 'cpu';
  const { aiW, aiH, tw, th } = plan(a.width, a.height, a.scale, q, gpu);
  const fps = Math.min(a.fps > 0 && a.fps < 241 ? a.fps : 30, MAX_FPS[q]);
  const total = Math.max(1, Math.round((a.duration || 0) * fps));

  // 1.22.3: si el video ya es más grande que lo que ve la IA y no se agranda (ej. 1440×2560 → mismo tamaño), la IA
  // trabaja con una copia achicada y pierde detalle real (se ve "pintado"). Entonces se lee al tamaño final y el
  // resultado se mezcla con el original: la IA aporta la limpieza y el original, el detalle.
  const blend = tw <= a.width && th <= a.height && aiW * 1.25 < tw;
  const BLEND = 0.5; // parte de la IA
  const rw = blend ? tw : aiW, rh = blend ? th : aiH;
  const dec = spawn(BIN, ['-hide_banner', '-nostdin', '-loglevel', 'error', '-i', a.file, '-map', '0:v:0',
    '-vf', `fps=${fps},scale=${rw}:${rh}:flags=lanczos`, '-pix_fmt', 'rgb24', '-f', 'rawvideo', '-'], { windowsHide: true });
  const copyA = ['aac', 'mp3'].includes(a.acodec);
  const enc = spawn(BIN, ['-hide_banner', '-nostdin', '-y', '-loglevel', 'error',
    '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', `${tw}x${th}`, '-framerate', String(fps), '-i', '-',
    '-i', a.file, '-map', '0:v:0', '-map', '1:a:0?',
    '-c:v', 'libx264', '-preset', q === 'max' ? 'medium' : 'veryfast', '-crf', q === 'max' ? '16' : '18', '-pix_fmt', 'yuv420p',
    '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
    ...(copyA ? ['-c:a', 'copy'] : ['-c:a', 'aac', '-b:a', '256k']),
    '-movflags', '+faststart', a.out], { windowsHide: true });
  let decErr = '', encErr = '';
  dec.stderr.on('data', (d) => { decErr = (decErr + d).slice(-3000); });
  enc.stderr.on('data', (d) => { encErr = (encErr + d).slice(-3000); });
  const encDone = new Promise((resolve) => enc.on('close', resolve));
  const decDone = new Promise((resolve) => dec.on('close', resolve));
  enc.stdin.on('error', () => {});
  const kill = () => { for (const c of [dec, enc]) { try { c.stdin.destroy(); c.stdout.destroy(); } catch {} try { c.kill('SIGKILL'); } catch {} } };
  process.on('exit', kill);
  // "Cancelar" (o la app que se cerró): cortar los dos ffmpeg, esperar que suelten el archivo y borrarlo
  stopHook = async () => {
    kill();
    await Promise.race([Promise.all([decDone, encDone]), new Promise((r) => setTimeout(r, 4000))]);
    for (let k = 0; k < 10; k++) { try { fs.unlinkSync(a.out); break; } catch (e) { if (e.code === 'ENOENT') break; await new Promise((r) => setTimeout(r, 300)); } }
  };

  const readRaw = frameReader(dec.stdout, rw * rh * 3);
  // devuelve { ai (lo que entra a la IA), orig (el cuadro al tamaño final, solo si se mezcla) }
  const next = async () => {
    const f = await readRaw();
    if (!f) return null;
    if (!blend) return { ai: f, orig: null };
    const ai = await sharp(f, { raw: { width: rw, height: rh, channels: 3 }, limitInputPixels: false }).resize(aiW, aiH, { kernel: 'lanczos3', fit: 'fill' }).raw().toBuffer();
    return { ai, orig: f };
  };
  let i = 0, done = 0, pending = Promise.resolve();
  // si el resultado entra en ×2, la placa ya lo devuelve achicado (menos datos que copiar y achicar).
  // En Rápida también cuando falta poco (hasta ×2,67): se agranda el resto con lanczos, que es casi gratis.
  const k2 = q === 'fast' ? 2.67 : 2;
  const factor = tw <= aiW * k2 && th <= aiH * k2 ? 2 : 4;
  const runner = await videoRunner(a.style, factor);
  const A = Math.round(BLEND * 256);
  const post = async (up, orig) => {
    const outFrame = up.w === tw && up.h === th ? up.data : await sharp(up.data, { raw: { width: up.w, height: up.h, channels: 3 }, limitInputPixels: false })
      .resize(tw, th, { kernel: 'lanczos3', fit: 'fill' }).raw().toBuffer();
    if (orig) for (let k = 0; k < outFrame.length; k++) outFrame[k] = (outFrame[k] * A + orig[k] * (256 - A) + 128) >> 8;
    await writeAsync(enc.stdin, outFrame);
    done++;
    send(`P ${Math.min(0.995, done / total).toFixed(5)}`);
  };
  try {
    if (runner.pipelined) {
      // placa: mientras trabaja con el cuadro i+1, acá se pasa a RGB, se achica y se manda el cuadro i
      let cur = await next();
      let running = cur ? runner.start(cur.ai, aiW, aiH) : null;
      while (running) {
        const res = await running, orig = cur.orig;
        cur = await next();
        running = cur ? runner.start(cur.ai, aiW, aiH) : null;
        const up = runner.finish(res);
        await pending;
        pending = post(up, orig);
        i++;
      }
    } else {
      for (;;) {
        const fr = await next();
        if (!fr) break;
        const rgb = fr.ai;
        const up = { data: await runner.process(rgb, aiW, aiH, (p) => send(`P ${Math.min(0.995, (i + p) / total).toFixed(5)}`)), w: aiW * runner.F, h: aiH * runner.F };
        await pending;
        pending = post(up, fr.orig);
        i++;
      }
    }
    await pending;
  } catch (e) { kill(); throw e; }
  enc.stdin.end();
  const [dc, ec] = await Promise.all([decDone, encDone]);
  if (!i) throw new Error(decErr.trim().split('\n').pop() || 'No pude leer los cuadros del video');
  if (dc !== 0) throw new Error(decErr.trim().split('\n').pop() || 'Se cortó la lectura del video');
  if (ec !== 0) throw new Error(encErr.trim().split('\n').pop() || 'No pude armar el video final');
  return a.out;
}

// Muestra: un pedazo de un cuadro, antes y con IA, y cuánto tarda la IA por cuadro (en este equipo)
async function sample(a, send) {
  const { upscale4x, upscaleProvider, videoRunner } = require('./ai');
  const sharp = require('sharp');
  const BIN = require('./bins').FFMPEG;
  const { aiW, aiH } = plan(a.width, a.height, 2, 'normal');
  const at = Math.max(0, (a.duration || 0) * 0.35);
  const png = await new Promise((resolve, reject) => {
    const p = spawn(BIN, ['-hide_banner', '-nostdin', '-loglevel', 'error', '-ss', String(at), '-i', a.file, '-frames:v', '1',
      '-vf', `scale=${aiW}:${aiH}:flags=lanczos`, '-f', 'image2pipe', '-c:v', 'png', '-'], { windowsHide: true });
    const ch = []; let err = '';
    p.stdout.on('data', (d) => ch.push(d));
    p.stderr.on('data', (d) => { err += d; });
    p.on('error', reject);
    p.on('close', () => (ch.length ? resolve(Buffer.concat(ch)) : reject(new Error(err.trim().split('\n').pop() || 'No pude sacar un cuadro'))));
  });
  // pedazo del medio: un cuadrado de ~1/3 del lado corto (mínimo 96 px)
  const side = Math.max(96, Math.min(240, Math.round(Math.min(aiW, aiH) / 3)));
  const cw = Math.min(side, aiW), ch = Math.min(side, aiH);
  const left = Math.round((aiW - cw) / 2), top = Math.round((aiH - ch) / 2);
  const crop = await sharp(png).extract({ left, top, width: cw, height: ch }).removeAlpha().raw().toBuffer();
  const style = a.style === 'smooth' ? 'smooth' : 'detail';
  const run = () => upscale4x(crop, cw, ch, null, style, { tile: TILE_GPU });
  await run(); // la primera vez carga el modelo (y verifica la placa de video)
  const t0 = Date.now();
  const up = await run();
  let secPx = (Date.now() - t0) / 1000 / (cw * ch);
  const provider = await upscaleProvider(style);
  // lo que se suma por cuadro: achicar el cuadro ×4 (y, con el procesador, que el ffmpeg compite por los núcleos)
  const big = Buffer.allocUnsafe(aiW * 4 * aiH * 4 * 3);
  const t2 = Date.now();
  await sharp(big, { raw: { width: aiW * 4, height: aiH * 4, channels: 3 }, limitInputPixels: false }).resize(aiW * 2, aiH * 2, { kernel: 'lanczos3', fit: 'fill' }).raw().toBuffer();
  const extra = (Date.now() - t2) / 1000;
  // con placa de video, un pedazo chico no dice mucho (lo fijo pesa más): se mide un cuadro entero
  let detail = provider === 'cpu' ? 'procesador' : '';
  if (provider !== 'cpu') {
    // como en el video de verdad: cuadro entero, de a varios seguidos, pasando a RGB mientras la placa sigue
    const runner = await videoRunner(style, 2);
    const full = await sharp(png).removeAlpha().raw().toBuffer();
    runner.finish(await runner.start(full, aiW, aiH)); // la primera carga y verifica
    const N = 4, t1 = Date.now();
    let running = runner.start(full, aiW, aiH);
    for (let k = 0; k < N; k++) {
      const res = await running;
      running = k < N - 1 ? runner.start(full, aiW, aiH) : null;
      runner.finish(res);
    }
    const ms = (Date.now() - t1) / N;
    secPx = ms / 1000 / (aiW * aiH);
    const gi = require('./gpu').gpuInfo();
    detail = `placa ${gi.dmlDevice ?? 0}${runner.provider === 'dml-fp16' ? ' · fp16' : ''} · ${Math.round(ms)} ms por cuadro de ${aiW}×${aiH}`
      + (gi.dmlTried.length > 1 ? ` · probadas: ${gi.dmlTried.map((t) => `${t.d}=${Math.round(t.ms)}ms${t.ok ? '' : '✗'}`).join(' ')}` : '');
  }
  const D = 480; // cómo se muestra: los dos al mismo tamaño
  const after = await sharp(up, { raw: { width: cw * 4, height: ch * 4, channels: 3 } }).resize(D, D, { kernel: 'lanczos3', fit: 'fill' }).jpeg({ quality: 90 }).toBuffer();
  const before = await sharp(crop, { raw: { width: cw, height: ch, channels: 3 } }).resize(D, D, { kernel: 'cubic', fit: 'fill' }).jpeg({ quality: 90 }).toBuffer();
  const frame = await sharp(png).resize(640, 360, { fit: 'inside' }).jpeg({ quality: 82 }).toBuffer();
  const url = (b) => `data:image/jpeg;base64,${b.toString('base64')}`;
  // la IA trabaja por pedazos de 192-320 px: el tiempo crece más o menos con los píxeles (+ ~15% de armar el video)
  send(`J ${JSON.stringify({ before: url(before), after: url(after), frame: url(frame), crop: { x: left / aiW, y: top / aiH, w: cw / aiW, h: ch / aiH }, secPx: secPx * (provider === 'cpu' ? 1.4 : 1.1), extra, gpu: provider !== 'cpu', detail })}`);
}

let stopHook = null;
if (require.main === module) {
  // la app manda "STOP" por stdin para cancelar; si la app se cierra, stdin se corta y también se para
  let stopping = false;
  const stop = async () => { if (stopping) return; stopping = true; try { await stopHook?.(); } catch {} process.exit(2); };
  process.stdin.on('data', (d) => { if (String(d).includes('STOP')) stop(); });
  process.stdin.on('end', stop);
  process.stdin.on('error', stop);
  const send = (line) => { try { process.stdout.write(`${line}\n`); } catch {} };
  // salir recién cuando la última línea terminó de salir (con un pipe, process.exit la puede cortar)
  const finish = (line, code) => { try { process.stdout.write(`${line}\n`, () => process.exit(code)); } catch { process.exit(code); } };
  const a = JSON.parse(process.argv[2]);
  (a.mode === 'sample' ? sample(a, send).then(() => 'DONE') : work(a, send).then((o) => `OK ${o}`))
    .then((line) => finish(line, 0))
    .catch((e) => finish(`ERR ${String(e && e.message || e).replace(/\s+/g, ' ')}`, 1));
}

// ---------------- desde la app ----------------
// Lanza el proceso aparte. Devuelve { promise, cancel }. onLine(tipo, valor) para P (progreso) y J (muestra).
function launch(args, onLine) {
  const child = spawn(process.execPath, [__filename, JSON.stringify(args)], {
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true,
  });
  child.stdin.on('error', () => {});
  let buf = '', err = '', result = null, fail = null, canceled = false;
  child.stdout.on('data', (d) => {
    buf += d;
    let k;
    while ((k = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, k); buf = buf.slice(k + 1);
      const sp = line.indexOf(' ');
      const t = sp < 0 ? line : line.slice(0, sp), v = sp < 0 ? '' : line.slice(sp + 1);
      if (t === 'P') onLine?.('P', +v);
      else if (t === 'J') { try { result = JSON.parse(v); } catch {} }
      else if (t === 'OK') result = v;
      else if (t === 'ERR') fail = v;
    }
  });
  child.stderr.on('data', (d) => { err = (err + d).slice(-3000); });
  const promise = new Promise((resolve, reject) => {
    child.on('error', reject);
    child.on('close', (code) => {
      if (canceled) { const e = new Error('Cancelado'); e.canceled = true; return reject(e); }
      if (code === 0 && result != null) return resolve(result);
      reject(new Error(fail || err.trim().split('\n').pop() || `El proceso terminó con código ${code}`));
    });
  });
  const cancel = () => {
    if (canceled) return;
    canceled = true;
    try { child.stdin.write('STOP\n'); } catch {}
    setTimeout(() => { try { child.kill(); } catch {} }, 8000).unref?.();
  };
  return { promise, cancel };
}

function uniquePath(dir, name, ext) {
  let p = path.join(dir, `${name}.${ext}`);
  for (let i = 2; fs.existsSync(p); i++) p = path.join(dir, `${name} (${i}).${ext}`);
  return p;
}

// opts: { scale: 1|2|4, style: 'detail'|'smooth' }  ctx: { onProgress, onCancel(fn) }
async function upscaleVideo(file, opts = {}, ctx = {}) {
  const info = await require('./av').probe(file);
  if (!info.hasVideo || !info.width) throw new Error('Ese archivo no tiene video');
  const scale = [1, 2, 4].includes(+opts.scale) ? +opts.scale : 2;
  const base = path.basename(file, path.extname(file));
  const out = uniquePath(path.dirname(file), `${base} (mejorado${scale > 1 ? ` x${scale}` : ''})`, 'mp4');
  const job = launch({ file, out, scale, quality: Q(opts.quality), style: opts.style === 'smooth' ? 'smooth' : 'detail',
    width: info.width, height: info.height, fps: info.fps, duration: info.duration, acodec: info.acodecs[0] || '' },
  (t, v) => { if (t === 'P') ctx.onProgress?.(v); });
  ctx.onCancel?.(job.cancel);
  try {
    return await job.promise;
  } catch (e) {
    // sin dejar un video a medias (el proceso aparte ya lo borra al cancelar; esto es por si se cayó)
    try { fs.unlinkSync(out); } catch {}
    throw e;
  }
}

function sampleVideo(file, info, style) {
  return launch({ mode: 'sample', file, style, width: info.width, height: info.height, duration: info.duration }).promise;
}

module.exports = { plan, upscaleVideo, sampleVideo, MAX_OUT, MAX_AI, MAX_FPS };
