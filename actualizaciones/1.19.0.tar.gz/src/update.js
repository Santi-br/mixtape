// Actualizaciones. La web privada (GitHub Pages) publica version.json:
//   { version, date, notes: [...], page, windows: { url, size }, mac: { url, size },
//     patch: { url, size, sha256, base } }   ← actualización chica (solo el código, .tar.gz de src/ + package.json)
// La app lo consulta al rato de arrancar y cada 6 horas.
//  - Si hay "patch" y la instalación es compatible (versión instalada ≥ base, y arranca con boot.js) la baja sola,
//    la deja lista en <userData>/actualizaciones/<versión> y avisa "Reiniciá para usar la X". boot.js la usa al arrancar.
//  - Si no (cambió algo pesado: módulos, modelos), avisa como antes y abre la página para bajar la app completa.
const { app, net, Notification, shell } = require('electron');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');

const pkg = require('../package.json');
const FEED = process.env.MX_UPDATE_FEED || (pkg.mixtape && pkg.mixtape.updateFeed) || '';
const enabled = () => !!FEED && !/USUARIO/i.test(FEED);
const MX = global.MX || null; // lo pone boot.js (versiones viejas arrancaban directo en main.js)
const current = () => (MX ? MX.version : app.getVersion());

let state = { latest: null, checkedAt: 0, error: null, ready: null, installing: null };
let hooks = { onChange: () => {}, settings: () => ({}), save: () => {}, icon: '' };

function newer(a, b) { // ¿a > b? (1.16.1 > 1.16)
  const pa = String(a).split('.').map((x) => parseInt(x, 10) || 0), pb = String(b).split('.').map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0; }
  return false;
}

async function fetchBuf(url, ms = 60000) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await net.fetch(`${url}${url.includes('?') ? '&' : '?'}t=${Date.now()}`, { signal: ctl.signal, cache: 'no-store' });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return Buffer.from(await r.arrayBuffer());
  } finally { clearTimeout(t); }
}
const fetchJson = async (url) => JSON.parse((await fetchBuf(url, 15000)).toString('utf8'));

const pageOf = (v) => (v && (v.page || FEED.replace(/version\.json.*$/, ''))) || FEED;
function available() { return state.latest && newer(state.latest.version, current()) ? state.latest : null; }
function open() { const v = available() || state.latest; shell.openExternal(pageOf(v)); }
const canPatch = (v) => !!(MX && v && v.patch && v.patch.url && v.patch.sha256 && !newer(v.patch.base || '0', MX.bundled));

// ---------- actualización chica ----------
function readState() { try { return JSON.parse(fs.readFileSync(path.join(MX.updatesDir, 'actual.json'), 'utf8')); } catch { return {}; } }
// borra una carpeta de actualización sin seguir los accesos directos (node_modules, models… son de la instalación)
function safeRemove(dir) {
  if (!fs.existsSync(dir)) return;
  for (const d of ['node_modules', 'models', 'bin', 'assets']) {
    const l = path.join(dir, d);
    try { if (fs.lstatSync(l).isSymbolicLink()) { try { fs.unlinkSync(l); } catch { fs.rmdirSync(l); } } } catch {}
  }
  fs.rmSync(dir, { recursive: true, force: true });
}
function writeState(st) { fs.mkdirSync(MX.updatesDir, { recursive: true }); fs.writeFileSync(path.join(MX.updatesDir, 'actual.json'), JSON.stringify(st)); }

async function installPatch(v) {
  const dir = MX.updatesDir, dest = path.join(dir, v.version), tmp = `${dest}.bajando`;
  const buf = await fetchBuf(v.patch.url, 120000);
  if (crypto.createHash('sha256').update(buf).digest('hex') !== v.patch.sha256) throw new Error('la actualización vino fallada');
  safeRemove(tmp);
  fs.mkdirSync(tmp, { recursive: true });
  await new Promise((resolve, reject) => {
    const { _test: { untar } } = require('./packs');
    const sink = untar((name) => {
      const rel = name.replace(/^\.?\//, '');
      if (!rel || rel.includes('..') || !/^(src\/|package\.json$)/.test(rel)) return null; // solo código
      const f = path.join(tmp, rel);
      fs.mkdirSync(path.dirname(f), { recursive: true });
      return fs.createWriteStream(f);
    });
    sink.on('finish', resolve); sink.on('error', reject);
    const gz = zlib.createGunzip(); gz.on('error', reject);
    gz.pipe(sink); gz.end(buf);
  });
  if (!fs.existsSync(path.join(tmp, 'src', 'main.js')) || !fs.existsSync(path.join(tmp, 'package.json'))) throw new Error('la actualización está incompleta');
  // lo pesado se usa de la instalación (accesos directos de carpeta)
  for (const d of ['node_modules', 'models', 'bin', 'assets']) {
    const target = path.join(MX.bundledRoot, d);
    if (fs.existsSync(target)) fs.symlinkSync(target, path.join(tmp, d), process.platform === 'win32' ? 'junction' : 'dir');
  }
  if (dest === MX.root) throw new Error('esa versión es la que está corriendo');
  safeRemove(dest);
  fs.renameSync(tmp, dest);
  writeState({ version: v.version, estado: 'nueva', at: Date.now() });
  // borrar versiones viejas bajadas (menos la que está corriendo)
  for (const d of fs.readdirSync(dir)) {
    const full = path.join(dir, d);
    if (d === v.version || d === 'actual.json' || full === MX.root) continue;
    try { if (fs.statSync(full).isDirectory()) safeRemove(full); } catch {}
  }
  return dest;
}

function restart() { app.relaunch(); app.exit(0); }

// manual = el usuario tocó "Buscar actualizaciones": avisa también si ya está al día o si falló
async function check({ manual = false } = {}) {
  if (!enabled()) { if (manual) toast('Buscar actualizaciones', 'Todavía no está configurada la página de MIXTAPE.'); return null; }
  try {
    const v = await fetchJson(FEED);
    if (!v || !v.version) throw new Error('version.json sin versión');
    state = { ...state, latest: v, checkedAt: Date.now(), error: null };
  } catch (err) {
    state.error = String(err.message || err);
    if (manual) toast('No pude buscar actualizaciones', 'Fijate que haya internet y probá de nuevo.');
    hooks.onChange(); return null;
  }
  const v = available();
  if (v && canPatch(v)) {
    if (state.ready === v.version) { if (manual) readyToast(v); hooks.onChange(); return v; }
    const st = readState();
    if (st.version === v.version && st.estado === 'mala') { fallback(v, manual); return v; } // ya falló una vez: que baje la completa
    if (!state.installing) {
      state.installing = installPatch(v).then(() => {
        state.ready = v.version;
        readyToast(v);
      }).catch((err) => {
        try { fs.appendFileSync(path.join(app.getPath('userData'), 'mixtape-errores.txt'), `[${new Date().toISOString()}] actualizar a ${v.version}\n${err && err.stack}\n\n`); } catch {}
        fallback(v, manual);
      }).finally(() => { state.installing = null; hooks.onChange(); });
    }
    if (manual) toast('Bajando la actualización', `MIXTAPE ${v.version}: en un ratito te aviso para reiniciar.`);
  } else if (v) fallback(v, manual);
  else if (manual) toast('Estás al día', `Tenés la última versión (${current()}).`);
  hooks.onChange();
  return v;
}
function readyToast(v) {
  const n = new Notification({ title: `MIXTAPE ${v.version} lista`, body: `${(v.notes && v.notes[0]) || 'Se bajó la versión nueva.'}\nTocá acá para reiniciar y usarla.`, icon: hooks.icon });
  n.on('click', restart); n.show();
}
function fallback(v, manual) {
  const s = hooks.settings();
  if (manual || s.updNotified !== v.version) {
    const n = new Notification({ title: `MIXTAPE ${v.version} ya está`, body: `${(v.notes && v.notes[0]) || 'Hay una versión nueva.'}\nEsta hay que bajarla completa: tocá acá.`, icon: hooks.icon });
    n.on('click', open); n.show();
    hooks.save({ updNotified: v.version });
  }
}

function toast(title, body) { try { new Notification({ title, body, icon: hooks.icon }).show(); } catch {} }

function start(h) {
  hooks = { ...hooks, ...h };
  // si arrancó una actualización y llegó hasta acá sin caerse, queda confirmada
  if (MX && MX.version !== MX.bundled) setTimeout(() => { const st = readState(); if (st.version === MX.version && st.estado === 'probando') writeState({ ...st, estado: 'ok' }); }, 20000).unref?.();
  if (!enabled() || process.env.RUEDITA_TEST) return;
  setTimeout(() => check().catch(() => {}), 25000);
  setInterval(() => check().catch(() => {}), 6 * 3600 * 1000).unref?.();
}

const info = () => ({ enabled: enabled(), current: current(), available: available(), ready: state.ready, installing: !!state.installing, checkedAt: state.checkedAt });

module.exports = { start, check, open, restart, info, available, newer, current, installPatch };
