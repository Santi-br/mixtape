/* global ruedita */
const q = new URLSearchParams(location.search);
const MODE = q.get('mode');
const WIN = q.get('id');
if (q.get('glass') === '1') document.body.classList.add('native-glass');
const $ = (id) => document.getElementById(id);

let info = null; // { width, height, dataUrl } del original
let getResult = () => null;

const TITLES = { vedit: 'Unir y editar video', ocr: 'Foto a texto', rename: 'Renombrar', order: 'Unir en un PDF', transcribe: 'A texto', vtrim: 'Recortar', crop: 'Recortar', resize: 'Cambiar tamaño', background: 'Agregar fondo', upscale: 'Mejorar calidad', blur: 'Blurear', rotate: 'Rotar', compress: 'Comprimir', stems: 'Separar stems', midi: 'Pasar a MIDI', keybpm: 'Key y BPM', av_adjust: 'Poner audio al video', download: 'Descargar' };

function done(val) { ruedita.send(`editor-done-${WIN}`, val); }
$('cancel').onclick = () => done(null);
$('ok').onclick = () => { const r = getResult(); if (r) done(r); };
document.addEventListener('keydown', (e) => {
  if (e.defaultPrevented || e.target.tagName === 'TEXTAREA') return;
  if (e.key === 'Escape') done(null);
  if (e.key === 'Enter') $('ok').click();
});

function chips(container, onPick) {
  container.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    container.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
    onPick(b.dataset);
  });
}

// ---------------- RECORTAR ----------------
function setupCrop() {
  const img = $('cropImg'), box = $('cropBox'), stage = $('cropStage');
  let ratio = null; // ancho/alto en píxeles reales; null = libre
  let r = { x: 0.1, y: 0.1, w: 0.8, h: 0.8 }; // fracciones de la imagen
  const W = info.width, H = info.height;

  function fit() {
    img.style.maxWidth = `${stage.clientWidth - 40}px`;
    img.style.maxHeight = `${stage.clientHeight - 40}px`;
    draw();
  }
  // vista previa real del pixelado (con la imagen de vista previa)
  function pixelPreview(fx, m, dw, dh) {
    const cw = Math.max(1, Math.round(m.w * dw)), ch = Math.max(1, Math.round(m.h * dh));
    const block = Math.max(2, fxBlock(Math.min(m.w * W, m.h * H), m.strength) * (dw / W));
    const sw = Math.max(1, Math.round(cw / block)), sh = Math.max(1, Math.round(ch / block));
    const small = document.createElement('canvas'); small.width = sw; small.height = sh;
    const nx = img.naturalWidth, ny = img.naturalHeight;
    small.getContext('2d').drawImage(img, m.x * nx, m.y * ny, m.w * nx, m.h * ny, 0, 0, sw, sh);
    const cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
    const ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = false;
    ctx.drawImage(small, 0, 0, cw, ch);
    fx.appendChild(cv);
  }

  function draw() {
    const dw = img.clientWidth, dh = img.clientHeight;
    Object.assign(box.style, { left: `${r.x * dw}px`, top: `${r.y * dh}px`, width: `${r.w * dw}px`, height: `${r.h * dh}px` });
    $('cropInfo').textContent = `${Math.round(r.w * W)} × ${Math.round(r.h * H)} px`;
  }
  function applyRatio() {
    if (!ratio) return draw();
    // fracción equivalente: (w*W)/(h*H) = ratio
    const cx = r.x + r.w / 2, cy = r.y + r.h / 2;
    let w = r.w, h = (w * W) / ratio / H;
    if (h > 1) { h = 1; w = (h * H * ratio) / W; }
    if (w > 1) { w = 1; h = (w * W) / ratio / H; }
    r = { w, h, x: Math.min(Math.max(0, cx - w / 2), 1 - w), y: Math.min(Math.max(0, cy - h / 2), 1 - h) };
    draw();
  }
  chips($('ratios'), (d) => {
    ratio = d.r === 'free' ? null : d.r === 'orig' ? W / H : parseFloat(d.r);
    if (ratio) r = { x: 0, y: 0, w: 1, h: 1 };
    applyRatio();
  });

  let drag = null;
  box.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    box.setPointerCapture(e.pointerId);
    drag = { h: e.target.dataset.h || 'move', sx: e.clientX, sy: e.clientY, r0: { ...r } };
  });
  box.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const dw = img.clientWidth, dh = img.clientHeight;
    const dx = (e.clientX - drag.sx) / dw, dy = (e.clientY - drag.sy) / dh;
    const o = drag.r0;
    const MIN = 0.02;
    if (drag.h === 'move') {
      r.x = Math.min(Math.max(0, o.x + dx), 1 - o.w);
      r.y = Math.min(Math.max(0, o.y + dy), 1 - o.h);
    } else {
      let x0 = o.x, y0 = o.y, x1 = o.x + o.w, y1 = o.y + o.h;
      if (drag.h.includes('w')) x0 = Math.min(Math.max(0, o.x + dx), x1 - MIN);
      if (drag.h.includes('e')) x1 = Math.max(Math.min(1, x1 + dx), x0 + MIN);
      if (drag.h.includes('n')) y0 = Math.min(Math.max(0, o.y + dy), y1 - MIN);
      if (drag.h.includes('s')) y1 = Math.max(Math.min(1, y1 + dy), y0 + MIN);
      if (ratio) {
        // ajusta el alto según el ancho manteniendo la esquina opuesta fija
        const w = x1 - x0;
        let h = (w * W) / ratio / H;
        if (drag.h.includes('n')) { y0 = y1 - h; if (y0 < 0) { y0 = 0; h = y1; } }
        else { y1 = y0 + h; if (y1 > 1) { y1 = 1; h = 1 - y0; } }
        const w2 = (h * H * ratio) / W;
        if (drag.h.includes('w')) x0 = x1 - w2; else x1 = x0 + w2;
      }
      r = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
    }
    draw();
  });
  box.addEventListener('pointerup', () => { drag = null; });

  img.draggable = false;
  img.addEventListener('dragstart', (e) => e.preventDefault());
  box.addEventListener('pointercancel', () => { drag = null; });
  img.onload = fit;
  img.src = info.dataUrl;
  window.addEventListener('resize', fit);

  getResult = () => ({
    x: Math.round(r.x * W), y: Math.round(r.y * H),
    width: Math.min(W, Math.round(r.w * W)), height: Math.min(H, Math.round(r.h * H)),
  });
}

// ---------------- TAMAÑO ----------------
function setupResize(files) {
  const W = info.width, H = info.height;
  const rw = $('rw'), rh = $('rh'), lock = $('rlock');
  let mode = { percent: 50 };
  $('resizeOrig').textContent = files.length > 1
    ? `${files.length} imágenes · la primera mide ${W} × ${H} px`
    : `Tamaño actual: ${W} × ${H} px`;

  function show() {
    if (mode.percent) {
      rw.value = Math.round((W * mode.percent) / 100);
      rh.value = Math.round((H * mode.percent) / 100);
      $('resizeNote').textContent = files.length > 1 ? `Cada imagen queda al ${mode.percent}% de su tamaño.` : '';
    } else {
      $('resizeNote').textContent = files.length > 1 ? 'Se aplica el mismo ancho a todas (el alto se ajusta solo).' : '';
    }
  }
  chips($('pcts'), (d) => {
    if (d.p) mode = { percent: +d.p };
    else { mode = { width: +d.w }; rw.value = d.w; rh.value = Math.round((d.w * H) / W); }
    show();
  });
  const clearChips = () => $('pcts').querySelectorAll('button').forEach((b) => b.classList.remove('on'));
  rw.oninput = () => { clearChips(); if (lock.checked) rh.value = Math.round((rw.value * H) / W); mode = { width: +rw.value, height: lock.checked ? null : +rh.value }; show(); };
  rh.oninput = () => { clearChips(); if (lock.checked) rw.value = Math.round((rh.value * W) / H); mode = lock.checked ? { height: +rh.value } : { width: +rw.value, height: +rh.value }; show(); };
  show();
  getResult = () => {
    const ai = $('rai').checked;
    if (mode.percent) return { percent: mode.percent, ai };
    if (files.length > 1 && lock.checked) return { width: +rw.value || null, ai };
    return { width: +rw.value || null, height: lock.checked ? null : (+rh.value || null), ai };
  };
}

// ---------------- MEJORAR ----------------
function setupUpscale(files) {
  const W = info.width, H = info.height;
  let scale = 2;
  const show = () => {
    const mp = (W * H * scale * scale) / 1e6;
    let txt = `${W} × ${H}  →  ${W * scale} × ${H * scale} px`;
    if (files.length > 1) txt += `  ·  ${files.length} imágenes`;
    if (W * H > 1.5e6) txt += '\nEs una imagen grande: puede tardar un rato.';
    if (mp > 80) txt += '\nOjo: el resultado va a ser enorme.';
    $('upsInfo').textContent = txt;
  };
  $('upsInfo').style.whiteSpace = 'pre-line';
  let style = 'detail';
  chips($('ups'), (d) => { scale = +d.s; show(); });
  chips($('upsStyle'), (d) => { style = d.st; });
  show();
  getResult = () => ({ scale, style });
}

// ---------------- BLUREAR ----------------
// Cada máscara tiene sus propios ajustes. Las fórmulas coinciden con blurImage() en ops.js.
const fxSigma = (minSide, st) => minSide * (0.04 + st * 0.22);
const fxBlock = (minSide, st) => Math.max(3, minSide * (0.06 + st * 0.2));
const fxFeather = (minSide, f) => f * minSide * 0.2;

function setupBlur(file) {
  const W = info.width, H = info.height;
  const img = $('blurImg'), wrap = $('blurWrap'), stage = $('blurStage'), layer = $('masks');
  // ajustes para las máscaras nuevas (cuando no hay ninguna elegida)
  const defaults = { shape: 'ellipse', style: 'blur', strength: 0.7, feather: 0.35 };
  let masks = []; // {id, shape, style, strength, feather, x, y, w, h} (posición en fracciones 0..1)
  let seq = 0, sel = null;
  const selected = () => masks.find((m) => m.id === sel) || null;

  const status = (txt, ms) => {
    const el = $('blurStatus');
    el.textContent = txt;
    el.classList.remove('hide');
    clearTimeout(status.t);
    if (ms) status.t = setTimeout(() => el.classList.add('hide'), ms);
  };

  function fit() {
    img.style.maxWidth = `${stage.clientWidth - 40}px`;
    img.style.maxHeight = `${stage.clientHeight - 40}px`;
    draw();
  }

  function styleMask(d, m) {
    const k = img.clientWidth / W; // escala de pantalla
    const minSide = Math.min(m.w * W, m.h * H);
    d.style.setProperty('--b', `${fxSigma(minSide, m.strength) * k * 0.7}px`);
    d.style.setProperty('--px', `${Math.max(2, fxBlock(minSide, m.strength) * k)}px`);
    d.style.setProperty('--f', `${m.style === 'blur' ? fxFeather(minSide, m.feather) * k : 0}px`);
  }

  // vista previa real del pixelado (con la imagen de vista previa)
  function pixelPreview(fx, m, dw, dh) {
    const cw = Math.max(1, Math.round(m.w * dw)), ch = Math.max(1, Math.round(m.h * dh));
    const block = Math.max(2, fxBlock(Math.min(m.w * W, m.h * H), m.strength) * (dw / W));
    const sw = Math.max(1, Math.round(cw / block)), sh = Math.max(1, Math.round(ch / block));
    const small = document.createElement('canvas'); small.width = sw; small.height = sh;
    const nx = img.naturalWidth, ny = img.naturalHeight;
    small.getContext('2d').drawImage(img, m.x * nx, m.y * ny, m.w * nx, m.h * ny, 0, 0, sw, sh);
    const cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
    const ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = false;
    ctx.drawImage(small, 0, 0, cw, ch);
    fx.appendChild(cv);
  }

  function draw() {
    const dw = img.clientWidth, dh = img.clientHeight;
    layer.textContent = '';
    for (const m of masks) {
      const d = document.createElement('div');
      d.className = `mask ${m.shape} ${m.style}${sel === m.id ? ' sel' : ''}${m.found ? ' found' : ''}`;
      Object.assign(d.style, { left: `${m.x * dw}px`, top: `${m.y * dh}px`, width: `${m.w * dw}px`, height: `${m.h * dh}px` });
      d.dataset.id = m.id;
      d.innerHTML = '<div class="fx"></div><div class="outline"></div><span class="x" title="Sacar">×</span><span class="rs"></span>';
      styleMask(d, m);
      if (m.style === 'pixel') pixelPreview(d.firstChild, m, dw, dh);
      layer.appendChild(d);
    }
    $('ok').disabled = !masks.length;
    $('ok').textContent = masks.length ? `Blurear ${masks.length === 1 ? '1 zona' : `${masks.length} zonas`}` : 'Blurear';
  }

  // los controles muestran los ajustes de la máscara elegida (o los de las nuevas)
  function syncControls() {
    const m = selected();
    const src = m || defaults;
    const idx = m ? masks.indexOf(m) + 1 : 0;
    $('maskInfo').textContent = m ? `Máscara ${idx} de ${masks.length}` : 'Nuevas máscaras';
    const pick = (box, attr, val) => box.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset[attr] === val));
    pick($('blurTool'), 't', src.shape);
    pick($('blurStyle'), 's', src.style);
    $('blurStrength').value = src.strength;
    $('blurFeather').value = src.feather;
    $('strengthVal').textContent = Math.round(src.strength * 100);
    $('featherVal').textContent = Math.round(src.feather * 100);
    $('featherWrap').style.opacity = src.style === 'blur' ? 1 : 0.4;
    $('removeMask').hidden = !m;
    $('applyAll').disabled = !m || masks.length < 2;
  }

  // cambia un ajuste: en la máscara elegida, o en los de las nuevas
  function setParam(key, val) {
    const m = selected();
    if (m) m[key] = val; else defaults[key] = val;
    if (m) defaults[key] = val; // la próxima que dibujes arranca igual
    draw(); syncControls();
  }

  function select(id) { sel = id; draw(); syncControls(); }

  // arrastrar: crear, mover o agrandar
  let drag = null;
  let detecting = false;
  wrap.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    if (detecting) { e.preventDefault(); status('Esperá un segundo, estoy buscando caras…'); return; }
    e.preventDefault();
    if (drag) endDrag();
    const r = img.getBoundingClientRect();
    const fx = (e.clientX - r.left) / r.width, fy = (e.clientY - r.top) / r.height;
    const md = e.target.closest('.mask');
    if (e.target.classList.contains('x') && md) {
      masks = masks.filter((m) => m.id !== +md.dataset.id);
      if (sel === +md.dataset.id) sel = null;
      draw(); syncControls(); return;
    }
    wrap.setPointerCapture(e.pointerId);
    if (md) {
      const m = masks.find((k) => k.id === +md.dataset.id);
      drag = { m, kind: e.target.classList.contains('rs') ? 'resize' : 'move', fx, fy, o: { ...m }, moved: false };
      select(m.id);
    } else {
      drag = { m: null, kind: 'new', fx, fy, moved: false, prevSel: sel };
    }
  });
  wrap.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const r = img.getBoundingClientRect();
    const fx = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    const fy = Math.min(1, Math.max(0, (e.clientY - r.top) / r.height));
    if (!drag.moved && Math.hypot((fx - drag.fx) * r.width, (fy - drag.fy) * r.height) < 4) return;
    drag.moved = true;
    if (drag.kind === 'new' && !drag.m) {
      const base = selected() ? { ...defaults, ...pickParams(selected()) } : defaults;
      drag.m = { id: ++seq, ...pickParams(base), x: drag.fx, y: drag.fy, w: 0, h: 0 };
      masks.push(drag.m); sel = drag.m.id;
    }
    const { m, o } = drag;
    if (drag.kind === 'move') {
      m.x = Math.min(1 - o.w, Math.max(0, o.x + fx - drag.fx));
      m.y = Math.min(1 - o.h, Math.max(0, o.y + fy - drag.fy));
    } else if (drag.kind === 'resize') {
      m.w = Math.max(0.01, fx - o.x); m.h = Math.max(0.01, fy - o.y);
    } else {
      m.x = Math.min(fx, drag.fx); m.y = Math.min(fy, drag.fy);
      m.w = Math.abs(fx - drag.fx); m.h = Math.abs(fy - drag.fy);
    }
    draw();
  });
  // Windows: arrastrar sobre la <img> puede arrancar el "drag" nativo de la imagen y cortar el gesto
  // (llega pointercancel en vez de pointerup). Se bloquea y, si pasa igual, se cierra el gesto bien.
  img.draggable = false;
  wrap.addEventListener('dragstart', (e) => e.preventDefault());
  wrap.addEventListener('pointercancel', () => endDrag());
  wrap.addEventListener('lostpointercapture', () => endDrag());
  wrap.addEventListener('pointerup', () => endDrag());
  function endDrag() {
    if (!drag) return;
    if (drag.kind === 'new') {
      if (!drag.m) sel = null; // click en un lugar vacío = deseleccionar
      else if (drag.m.w < 0.01 || drag.m.h < 0.01) { masks = masks.filter((m) => m !== drag.m); sel = null; }
    }
    drag = null;
    draw(); syncControls();
  }
  document.addEventListener('keydown', (e) => {
    if ((e.key === 'Delete' || e.key === 'Backspace') && sel) { masks = masks.filter((m) => m.id !== sel); sel = null; draw(); syncControls(); }
    if (e.key === 'Escape' && sel) { e.stopImmediatePropagation(); select(null); }
  }, true);

  const pickParams = (m) => ({ shape: m.shape, style: m.style, strength: m.strength, feather: m.feather });

  const onChip = (box, fn) => box.addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) fn(b.dataset); });
  onChip($('blurTool'), (d) => setParam('shape', d.t));
  onChip($('blurStyle'), (d) => setParam('style', d.s));
  $('blurStrength').addEventListener('input', (e) => setParam('strength', +e.target.value));
  $('blurFeather').addEventListener('input', (e) => setParam('feather', +e.target.value));
  $('applyAll').onclick = () => {
    const m = selected(); if (!m) return;
    const p = pickParams(m);
    masks.forEach((k) => { k.style = p.style; k.strength = p.strength; k.feather = p.feather; });
    draw(); status(`Ajustes copiados a las ${masks.length} máscaras`, 2500);
  };
  $('removeMask').onclick = () => { masks = masks.filter((m) => m.id !== sel); sel = null; draw(); syncControls(); };
  $('clearMasks').onclick = () => { masks = []; sel = null; draw(); syncControls(); };

  // cuánto de la más chica de las dos queda tapado por la otra (0..1)
  const overlap = (a, b) => {
    const ix = Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x));
    const iy = Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
    return (ix * iy) / Math.max(1e-9, Math.min(a.w * a.h, b.w * b.h));
  };

  async function detect() {
    status('Buscando caras…');
    $('detect').disabled = true;
    detecting = true;
    wrap.classList.add('busy');
    let res;
    try { res = await ruedita.invoke('detect-faces', file); } finally {
      detecting = false;
      wrap.classList.remove('busy');
      $('detect').disabled = false;
    }
    if (res.error) { status('No pude buscar caras: ' + res.error, 5000); return; }
    let added = 0;
    for (const f of res.faces) {
      // un poco más grande que la cara (frente, pelo y mentón)
      const w = f.w * 1.3, h = f.h * 1.4;
      const m = { id: ++seq, ...pickParams(defaults), shape: 'ellipse', x: (f.x + f.w / 2 - w / 2) / W, y: (f.y + f.h * 0.45 - h / 2) / H, w: w / W, h: h / H };
      m.x = Math.max(0, m.x); m.y = Math.max(0, m.y);
      m.w = Math.min(1 - m.x, m.w); m.h = Math.min(1 - m.y, m.h);
      // si ya hay una máscara tapando (aunque sea en parte) esa cara, no se agrega otra encima
      if (![m.x, m.y, m.w, m.h].every(Number.isFinite) || m.w < 0.004 || m.h < 0.004) continue;
      if (masks.some((k) => overlap(m, k) > 0.15)) continue;
      m.found = true;
      masks.push(m); added++;
    }
    draw(); syncControls();
    setTimeout(() => { masks.forEach((k) => { k.found = false; }); }, 1200);
    const n = res.faces.length;
    status(n ? `Encontré ${n === 1 ? '1 cara' : `${n} caras`}${added < n ? ` (${added} nuevas)` : ''} · tocá una para ajustarla sola` : 'No encontré caras · arrastrá sobre la imagen para marcar zonas', 5000);
  }
  $('detect').onclick = detect;

  img.onload = () => { fit(); syncControls(); status('Arrastrá sobre la imagen para marcar una zona', 5000); };
  img.src = info.dataUrl;
  window.addEventListener('resize', fit);

  getResult = () => masks.length ? ({
    masks: masks.map((m) => ({ shape: m.shape, style: m.style, strength: m.strength, feather: m.feather, x: m.x * W, y: m.y * H, w: m.w * W, h: m.h * H })),
  }) : null;
}

// ---------------- ROTAR ----------------
function setupRotate(kind) {
  const W = info?.width || 1, H = info?.height || 1;
  const img = $('rotImg'), box = $('rotBox'), stage = $('rotStage');
  const pdf = kind === 'pdf';
  let base = 0, fine = 0, flipH = false, flipV = false, bg = 'crop';
  if (pdf) { $('rotFlips').hidden = true; $('rotFineWrap').hidden = true; }

  const total = () => base + fine;
  function draw() {
    const a = total();
    const right = Math.abs(fine) < 1e-6;
    // escala para que la imagen rotada entre en el escenario
    const th = (a * Math.PI) / 180, c = Math.abs(Math.cos(th)), sn = Math.abs(Math.sin(th));
    const dw = img.clientWidth || 1, dh = img.clientHeight || 1;
    const bw = dw * c + dh * sn, bh = dw * sn + dh * c;
    const k = Math.min(1, (stage.clientWidth - 40) / bw, (stage.clientHeight - 40) / bh);
    box.style.transform = `scale(${k}) rotate(${a}deg) scale(${flipH ? -1 : 1}, ${flipV ? -1 : 1})`;
    box.classList.toggle('fine', !right);
    $('rotBg').hidden = right || pdf;
    // marco de recorte (solo con ajuste fino y "Recortar bordes")
    let fr = $('cropFrame');
    if (!right && bg === 'crop') {
      // el recorte se calcula sobre la imagen ya girada en pasos de 90° (si quedó parada, se invierten lados)
      const odd = Math.abs(Math.round(base / 90)) % 2 === 1;
      const w0 = odd ? H : W, h0 = odd ? W : H, d0w = odd ? dh : dw, d0h = odd ? dw : dh;
      const tf = (fine * Math.PI) / 180, cf = Math.abs(Math.cos(tf)), sf = Math.abs(Math.sin(tf));
      const ff = Math.min(w0 / (w0 * cf + h0 * sf), h0 / (w0 * sf + h0 * cf));
      if (!fr) { fr = document.createElement('div'); fr.id = 'cropFrame'; stage.appendChild(fr); }
      const fw = d0w * ff * k, fh = d0h * ff * k;
      Object.assign(fr.style, { width: `${fw}px`, height: `${fh}px`, left: `${(stage.clientWidth - fw) / 2}px`, top: `${(stage.clientHeight - fh) / 2}px` });
    } else if (fr) fr.remove();
    const norm = ((a % 360) + 360) % 360;
    $('rotInfo').textContent = `${Math.round(norm * 10) / 10}°${flipH ? ' · espejo' : ''}${flipV ? ' · dada vuelta' : ''}`;
    $('rotFineVal').textContent = `${fine > 0 ? '+' : ''}${fine}°`;
    $('ok').disabled = norm === 0 && !flipH && !flipV;
  }
  $('rotSteps').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) { base += +b.dataset.a; draw(); } });
  $('rotFlips').addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.f === 'h') flipH = !flipH; else flipV = !flipV;
    b.classList.toggle('on', b.dataset.f === 'h' ? flipH : flipV);
    draw();
  });
  $('rotFine').addEventListener('input', (e) => { fine = +e.target.value; draw(); });
  $('rotFine').addEventListener('dblclick', (e) => { e.target.value = 0; fine = 0; draw(); });
  chips($('rotBg'), (d) => { bg = d.b; draw(); });
  img.draggable = false;
  if (info?.dataUrl) { img.onload = () => { img.style.maxWidth = `${stage.clientWidth - 60}px`; img.style.maxHeight = `${stage.clientHeight - 60}px`; draw(); }; img.src = info.dataUrl; }
  else { img.hidden = true; $('rotNoPreview').hidden = false; }
  window.addEventListener('resize', draw);
  draw();
  getResult = () => ({ angle: total(), flipH, flipV, bg });
}

// ---------------- COMPRIMIR ----------------
const fmtBytes = (b) => b >= 1e9 ? `${(b / 1e9).toFixed(2)} GB` : b >= 1e6 ? `${(b / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1e3))} KB`;
function setupCompress(data) {
  const video = data.kind === 'video';
  const file = data.files[0];
  let quality = 70, maxSide = 0, format = 'same', seq = 0;
  if (video) {
    quality = 50;
    $('cmpQ').value = 50;
    $('cmpPresets').innerHTML = '<button data-q="80">Alta</button><button data-q="50" class="on">Media</button><button data-q="30">Liviana</button><button data-q="10">Mínima</button>';
    $('cmpFmtRow').hidden = true;
    $('cmpLead').textContent = 'Comprimir video (MP4)';
    const m = data.media;
    $('cmpOrig').textContent = `${fmtBytes(m.size)} · ${Math.floor(m.duration / 60)}:${String(Math.round(m.duration % 60)).padStart(2, '0')} min`;
    $('cmpSize').innerHTML = '<button data-s="0" class="on">Original</button><button data-s="1080">1080p</button><button data-s="720">720p</button><button data-s="480">480p</button>';
  } else {
    $('cmpLead').textContent = data.files.length > 1 ? `Comprimir ${data.files.length} imágenes` : 'Comprimir imagen';
    $('cmpOrig').textContent = `${info.width} × ${info.height} px`;
    $('cmpThumb').src = info.dataUrl; $('cmpThumb').hidden = false;
    const big = Math.max(info.width, info.height);
    $('cmpSize').innerHTML = '<button data-s="0" class="on">Original</button>' + [3840, 2560, 1920, 1280, 800].filter((v) => v < big).map((v) => `<button data-s="${v}">${v} px</button>`).join('');
  }
  const opts = () => (video ? { quality, height: maxSide } : { quality, maxSide, format });
  async function estimate() {
    const my = ++seq;
    $('cmpEst').textContent = 'Calculando…';
    const r = await ruedita.invoke('compress-estimate', file, opts());
    if (my !== seq) return;
    if (r.error) { $('cmpEst').textContent = 'No pude estimar el tamaño'; return; }
    const pct = Math.round((1 - r.after / r.before) * 100);
    const cls = pct >= 0 ? 'down' : 'up';
    $('cmpEst').innerHTML = `${fmtBytes(r.before)} → <b>${video ? '≈ ' : ''}${fmtBytes(r.after)}</b> <span class="${cls}">(${pct >= 0 ? '−' : '+'}${Math.abs(pct)}%)</span>`;
  }
  let t;
  const later = () => { clearTimeout(t); t = setTimeout(estimate, video ? 500 : 200); };
  const setQ = (q) => { quality = q; $('cmpQ').value = q; $('cmpQVal').textContent = `${q}%`; };
  $('cmpQ').addEventListener('input', (e) => {
    setQ(+e.target.value);
    $('cmpPresets').querySelectorAll('button').forEach((b) => b.classList.toggle('on', +b.dataset.q === quality));
    later();
  });
  chips($('cmpPresets'), (d) => { setQ(+d.q); later(); });
  chips($('cmpSize'), (d) => { maxSide = +d.s; later(); });
  chips($('cmpFmt'), (d) => { format = d.f; later(); });
  setQ(quality);
  estimate();
  getResult = () => opts();
}

// ---------------- STEMS ----------------
const STEMS = [
  { id: 'vocals', label: 'Voz', em: '🎤', on: true },
  { id: 'drums', label: 'Batería', em: '🥁', on: true },
  { id: 'bass', label: 'Bajo', em: '🎸', on: true },
  { id: 'guitar', label: 'Guitarra', em: '🎸' },
  { id: 'piano', label: 'Piano / teclas', em: '🎹' },
  { id: 'other', label: 'Otros', em: '🎛️', sub: 'sintes, cuerdas, vientos…', on: true },
  { id: 'instrumental', label: 'Instrumental', em: '🎶', sub: 'todo menos la voz' },
];
const ORQ = [
  { id: 'orq:bowed_strings', key: 'bowed_strings', label: 'Cuerdas', em: '🎻', sub: 'violines, violas, cellos' },
  { id: 'orq:brass', key: 'brass', label: 'Metales', em: '🎺', sub: 'trompetas, cornos, trombones' },
  { id: 'orq:woodwind', key: 'woodwind', label: 'Vientos madera', em: '🪈', sub: 'flautas, oboes, clarinetes' },
  { id: 'orq:percussion', key: 'percussion', label: 'Percusión', em: '🥁', sub: 'timbales, platillos…' },
  { id: 'orq:piano', key: 'piano', label: 'Piano', em: '🎹' },
  { id: 'orq:harp', key: 'harp', label: 'Arpa', em: '🪕' },
  { id: 'orq:rest', key: 'rest', label: 'Resto', em: '➕', sub: 'lo que no sea nada de esto' },
];
function setupStems(data) {
  const m = data.media || {};
  $('stemsInfo').textContent = `${data.name} · ${Math.floor((m.duration || 0) / 60)}:${String(Math.round((m.duration || 0) % 60)).padStart(2, '0')} min`;
  let quality = 'best';
  const list = $('stemList');
  const have = new Set(data.orq || []);
  const orqList = $('orqList');
  for (const st of ORQ) {
    const ok = st.key === 'rest' ? have.size > 0 : have.has(st.key);
    const l = document.createElement('label');
    l.className = `stem${ok ? '' : ' dis'}`;
    l.dataset.id = st.id;
    l.innerHTML = `<input type="checkbox" ${ok ? '' : 'disabled'}><span class="em">${st.em}</span><span>${st.label}${st.sub ? `<small>${st.sub}</small>` : ''}</span>`;
    orqList.appendChild(l);
  }
  $('orqNote').textContent = have.size
    ? 'Separa por familias de instrumentos (modelo MVSep Mega). Tarda bastante más que los stems de arriba.'
    : (navigator.platform.startsWith('Mac')
      ? 'Falta el paquete Orquesta: bajá "MIXTAPE-Mac-Orquesta.zip", descomprimilo y en el ícono de MIXTAPE (barra de arriba) tocá "Instalar paquete…".'
      : 'Falta el paquete Orquesta: descomprimí "MIXTAPE-Orquesta.zip" en la carpeta de MIXTAPE (al lado de MIXTAPE.exe).');
  for (const st of STEMS) {
    const l = document.createElement('label');
    l.className = `stem${st.disabled ? ' dis' : ''}`;
    l.dataset.id = st.id;
    l.innerHTML = `<input type="checkbox" ${st.on ? 'checked' : ''} ${st.disabled ? 'disabled' : ''}><span class="em">${st.em}</span><span>${st.label}${st.sub ? `<small>${st.sub}</small>` : ''}</span>`;
    list.appendChild(l);
  }
  function refresh() {
    list.querySelectorAll('.stem').forEach((l) => {
      const st = STEMS.find((x) => x.id === l.dataset.id);
      if (!st) return;
      const off = !!(st.disabled || (st.best && quality === 'fast'));
      l.classList.toggle('dis', off);
      l.querySelector('input').disabled = off;
    });
    const sel = picked();
    $('ok').disabled = !sel.length;
    $('ok').textContent = sel.length ? `Separar ${sel.length} ${sel.length === 1 ? 'stem' : 'stems'}` : 'Separar';
    const dur = m.duration || 180;
    const len = dur < 90 ? `${Math.round(dur)} s` : `${Math.round(dur / 60)} min`;
    const needsDemucs = sel.some((x) => !['vocals', 'instrumental'].includes(x) && !x.startsWith('orq:'));
    const orqSel = sel.filter((x) => x.startsWith('orq:') && x !== 'orq:rest').length;
    $('stemsNote').textContent = quality === 'best'
      ? `Mejor: voz con UVR + Demucs 6 stems para el resto. Más lento (este tema de ${len} puede tardar ${needsDemucs ? 'varios minutos' : 'un par de minutos'} sin placa de video).`
      : 'Rápida: una sola pasada de Demucs (la voz sale un poco menos limpia que en "Mejor").';
    if (orqSel) $('stemsNote').textContent += ` Orquesta: con placa de video unos minutos; sin placa puede tardar ${dur < 90 ? 'varios minutos' : 'bastante (15 min o más)'}.`;
  }
  const picked = () => [...list.querySelectorAll('.stem'), ...orqList.querySelectorAll('.stem')].filter((l) => !l.querySelector('input').disabled && l.querySelector('input').checked).map((l) => l.dataset.id);
  list.addEventListener('change', refresh);
  orqList.addEventListener('change', refresh);
  chips($('stemQuality'), (d) => { quality = d.q; refresh(); });
  refresh();
  getResult = () => ({ stems: picked(), quality });
}


// ---------------- A MIDI ----------------
const NOTE_N = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const noteName = (m) => `${NOTE_N[m % 12]}${Math.floor(m / 12) - 1}`;
const MIDI_MODES = [
  { id: 'melody', em: '🎤', label: 'Melodía', sub: 'voz o instrumento principal' },
  { id: 'harmony', em: '🎹', label: 'Armonía', sub: 'acordes' },
  { id: 'bass', em: '🎸', label: 'Bajo', sub: 'la línea de bajo' },
  { id: 'drums', em: '🥁', label: 'Batería', sub: 'bombo, redo, hi-hat…' },
  { id: 'piano', em: '🎼', label: 'Piano HQ', sub: 'alta precisión + pedal' },
  { id: 'full', em: '🎛️', label: 'Tema completo', sub: 'batería, bajo, acordes y melodía' },
];
const RANGES = { melody: [36, 96], harmony: [21, 108], bass: [28, 67], drums: null, piano: [21, 108], full: null };
function setupMidi(data) {
  const m = data.media || {};
  const pro = data.pro || {};
  const dur = m.duration || 0;
  $('midiInfo').textContent = `${data.name} · ${Math.floor(dur / 60)}:${String(Math.round(dur % 60)).padStart(2, '0')} min`;
  let mode = 'melody', src = 'voice', sep = 1, quant = 0, minMs = 120, chordsOn = 1;
  const grid = $('midiModes');
  for (const md of MIDI_MODES) {
    const l = document.createElement('label');
    const off = md.id === 'piano' && !pro.piano;
    l.className = `stem mode-tile${off ? ' dis' : ''}${md.id === mode ? ' on' : ''}`;
    l.dataset.id = md.id;
    l.innerHTML = `<input type="radio" name="midimode" ${off ? 'disabled' : ''}><span class="em">${md.em}</span><span>${md.label}<small>${off ? 'necesita el Paquete MIDI Pro' : md.sub}</small></span>`;
    grid.appendChild(l);
  }
  const lo = $('midiLo'), hi = $('midiHi');
  for (let n = 21; n <= 108; n++) {
    lo.add(new Option(noteName(n), n)); hi.add(new Option(noteName(n), n));
  }
  function setRange() {
    const r = RANGES[mode];
    lo.disabled = hi.disabled = !r;
    $('midiRangeRow').hidden = !r;
    if (r) { lo.value = r[0]; hi.value = r[1]; }
  }
  function refresh() {
    grid.querySelectorAll('.mode-tile').forEach((t) => t.classList.toggle('on', t.dataset.id === mode));
    $('midiSrcRow').hidden = !(mode === 'melody' || mode === 'full');
    $('midiChordRow').hidden = !['harmony', 'piano', 'full'].includes(mode);
    const notes = [];
    const len = dur < 90 ? `${Math.round(dur)} s` : `${Math.round(dur / 60)} min`;
    if ((mode === 'melody' || mode === 'full') && src === 'voice') {
      notes.push(pro.voice ? 'Voz: modelo GAME, hecho para canto (maneja vibrato y arrastres).' : 'Voz: sin el Paquete MIDI Pro se usa el modelo general (Basic Pitch); con el paquete sale mucho mejor.');
    }
    if (mode === 'piano') notes.push('Piano: modelo Transkun, el más preciso para piano solo. Incluye el pedal.');
    if (mode === 'drums') notes.push('Batería: bombo, redoblante, hi-hat (cerrado y abierto), toms y platillos en las notas estándar General MIDI, así cae directo en un Drum Rack de Ableton o el FPC de FL.');
    if (sep) notes.push(`Separar antes usa los stems de MIXTAPE: mucho más preciso con temas completos, pero tarda más (este de ${len} puede llevar varios minutos sin placa de video).`);
    else notes.push('Sin separar: ideal si el audio ya es un instrumento solo.');
    notes.push('El MIDI queda al lado del archivo, con el tempo detectado.');
    $('midiNote').textContent = notes.join(' ');
    $('ok').textContent = 'Pasar a MIDI';
  }
  grid.addEventListener('click', (e) => {
    const t = e.target.closest('.mode-tile');
    if (!t || t.classList.contains('dis')) return;
    e.preventDefault();
    mode = t.dataset.id;
    // si el audio ya es una sola cosa, separar no hace falta; para tema completo sí
    setRange(); refresh();
  });
  chips($('midiSrc'), (d) => { src = d.s; refresh(); });
  chips($('midiSep'), (d) => { sep = +d.v; refresh(); });
  chips($('midiQ'), (d) => { quant = +d.v; });
  chips($('midiMin'), (d) => { minMs = +d.v; });
  chips($('midiChords'), (d) => { chordsOn = +d.v; });
  setRange(); refresh();
  getResult = () => {
    const r = RANGES[mode];
    let a = +lo.value, b = +hi.value; if (a > b) [a, b] = [b, a];
    return {
      mode, source: src, separate: !!sep, quantize: quant, minNoteMs: minMs,
      sensitivity: +$('midiSens').value / 100, chordNames: !!chordsOn,
      ...(r ? { rangeLo: a, rangeHi: b } : {}),
    };
  };
}


// ---------------- KEY / BPM ----------------
// color de la rueda de Camelot (1 a 12, como Mixed In Key)
const camColor = (c) => `hsl(${((parseInt(c, 10) - 1) * 30 + 140) % 360} 70% 45%)`;
function setupKeyBpm(data) {
  let results = data.results || [];
  const list = $('kbList');
  function render() {
    list.innerHTML = '';
    for (const r of results) {
      const row = document.createElement('div');
      row.className = 'kb-row';
      const fn = document.createElement('div'); fn.className = 'fname'; fn.textContent = r.name; row.appendChild(fn);
      if (r.error) { const e = document.createElement('div'); e.className = 'kb-err'; e.textContent = r.error; row.appendChild(e); list.appendChild(row); continue; }
      const main = document.createElement('div'); main.className = 'kb-main';
      const k = document.createElement('div');
      if (r.key) {
        k.innerHTML = '<span class="kb-big"></span><span class="kb-cam"></span>';
        k.querySelector('.kb-big').textContent = r.key.name;
        const cam = k.querySelector('.kb-cam'); cam.textContent = r.key.camelot; cam.style.background = camColor(r.key.camelot);
      } else { k.innerHTML = '<span class="kb-big">—</span>'; }
      const sep = document.createElement('div'); sep.className = 'kb-sep';
      const b = document.createElement('div');
      b.innerHTML = '<span class="kb-big"></span> <span class="muted">BPM</span>';
      b.querySelector('.kb-big').textContent = r.bpm ?? '—';
      main.append(k, sep, b);
      row.appendChild(main);
      const sub = document.createElement('div'); sub.className = 'kb-sub';
      const bits = [];
      if (r.key) {
        bits.push(`${r.key.label} (confianza ${r.keyConfidence})`);
        if (r.relative) bits.push(`relativa: ${r.relative.name} (${r.relative.camelot}), mezcla igual de bien`);
        if (r.keyAlt) bits.push(`también podría ser ${r.keyAlt.name} (${r.keyAlt.camelot})`);
      } else bits.push('no tiene notas claras para sacar la tonalidad (¿es solo batería?)');
      if (r.bpmAlt) bits.push(`tempo: ${r.bpm} o ${r.bpmAlt} si lo contás ${r.bpmAlt > r.bpm ? 'al doble' : 'a la mitad'}`);
      sub.textContent = bits.join(' · ');
      row.appendChild(sub);
      list.appendChild(row);
    }
  }
  render();
  const ok = () => results.filter((r) => !r.error);
  const tagOk = ok().filter((r) => /\.(mp3|flac|ogg|opus|m4a)$/i.test(r.file));
  $('kbTags').disabled = !tagOk.length;
  $('kbNote').textContent = (tagOk.length ? 'Las etiquetas (BPM y key) las leen Rekordbox, Serato, Traktor y VirtualDJ. ' : 'Este formato no guarda BPM/key en las etiquetas: usá "Poner en el nombre". ')
    + 'Ponerlo en el nombre deja algo así: "Tema (8A - Am - 95 BPM)".';
  const text = () => ok().map((r) => `${r.name}: ${r.key ? `${r.key.name} (${r.key.camelot})` : 'sin tonalidad'} · ${r.bpm ? `${r.bpm} BPM` : 'sin tempo'}`).join('\n');
  $('kbCopy').onclick = async () => { try { await navigator.clipboard.writeText(text()); $('kbNote').textContent = 'Copiado ✓'; } catch { $('kbNote').textContent = 'No pude copiar'; } };
  const apply = async (what, items) => {
    const res = await ruedita.invoke('kb-apply', { what, items: items.map((r) => ({ file: r.file, bpm: r.bpm, key: r.key })) });
    const n = res.filter((x) => x.ok).length;
    if (what === 'rename') res.forEach((x, i) => { if (x.ok) { items[i].file = x.file; items[i].name = x.file.split(/[\\/]/).pop(); } });
    render();
    $('kbNote').textContent = what === 'rename' ? `Listo: ${n} ${n === 1 ? 'archivo renombrado' : 'archivos renombrados'} ✓` : `Listo: guardado en ${n} ${n === 1 ? 'archivo' : 'archivos'} ✓${n < items.length ? ` (${items.length - n} no se pudieron)` : ''}`;
  };
  $('kbRename').onclick = () => apply('rename', ok());
  $('kbTags').onclick = () => apply('tags', tagOk);
  $('ok').textContent = 'Listo';
  $('cancel').hidden = true;
  getResult = () => ({ done: true });
}

// ---------------- FOTO A TEXTO ----------------
function setupOcr(data) {
  const results = data.results || [];
  const list = $('ocList');
  const good = results.filter((r) => !r.error && r.text);
  for (const r of results) {
    const row = document.createElement('div'); row.className = 'oc-row';
    const head = document.createElement('div'); head.className = 'oc-head';
    const img = document.createElement('img'); img.className = 'oc-thumb'; img.alt = ''; if (r.thumb) img.src = r.thumb; else img.hidden = true;
    const fn = document.createElement('div'); fn.className = 'fname'; fn.textContent = r.name;
    const meta = document.createElement('span'); meta.className = 'oc-meta';
    head.append(img, fn, meta); row.appendChild(head);
    if (r.error || !r.text) {
      const e = document.createElement('div'); e.className = 'kb-err';
      e.textContent = r.error ? `No se pudo leer: ${r.error}` : 'No encontré texto en esta foto.';
      row.appendChild(e); list.appendChild(row); continue;
    }
    meta.textContent = `${r.words} ${r.words === 1 ? 'palabra' : 'palabras'}${r.confidence < 60 ? ' · revisalo, la foto se lee difícil' : ''}`;
    if (r.confidence < 60) meta.classList.add('warn');
    const ta = document.createElement('textarea'); ta.className = 'oc-text'; ta.value = r.text; ta.spellcheck = true; ta.lang = 'es';
    ta.setAttribute('aria-label', `Texto de ${r.name}`);
    const fit = () => { ta.style.height = 'auto'; ta.style.height = Math.min(420, ta.scrollHeight + 4) + 'px'; };
    ta.addEventListener('input', () => { r.text = ta.value; fit(); });
    const cp = document.createElement('button'); cp.className = 'oc-cp'; cp.textContent = 'Copiar';
    cp.onclick = async () => { try { await navigator.clipboard.writeText(r.text); cp.textContent = 'Copiado ✓'; setTimeout(() => { cp.textContent = 'Copiar'; }, 1500); } catch {} };
    head.appendChild(cp);
    row.appendChild(ta); list.appendChild(row); requestAnimationFrame(fit);
  }
  const note = $('ocNote');
  const all = () => good.map((r) => (good.length > 1 ? `── ${r.name} ──\n${r.text}` : r.text)).join('\n\n');
  $('ocJoin').hidden = good.length < 2;
  $('ocSave').textContent = good.length > 1 ? 'Guardar un .txt al lado de cada foto' : 'Guardar .txt al lado de la foto';
  for (const id of ['ocCopy', 'ocSave', 'ocJoin']) $(id).disabled = !good.length;
  if (!good.length) note.textContent = 'Probá con una foto más de cerca, derecha y con buena luz.';
  $('ocCopy').onclick = async () => { try { await navigator.clipboard.writeText(all()); note.textContent = 'Copiado ✓'; } catch { note.textContent = 'No pude copiar'; } };
  const save = async (joined) => {
    const out = await ruedita.invoke('ocr-save', { joined, items: good.map((r) => ({ file: r.file, text: r.text })) });
    note.textContent = out.length === 1 ? `Guardado: ${out[0].split(/[\\/]/).pop()} ✓` : `Guardados ${out.length} .txt ✓`;
  };
  $('ocSave').onclick = () => save(false);
  $('ocJoin').onclick = () => save(true);
  $('ok').textContent = 'Listo';
  $('cancel').hidden = true;
  getResult = () => ({ done: true });
}

// ---------------- VIDEO + AUDIO ----------------
const mmss = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
function setupAvAdjust(data) {
  const v = data.video, a = data.audio;
  $('avInfo').textContent = `🎬 ${v.name} · ${mmss(v.duration)}\n🎵 ${a.name} · ${mmss(a.duration)}`;
  $('fileName').textContent = '';
  let mode = 'replace', length = 'video', fade = 1;
  const off = $('avOff');
  off.max = Math.max(0, Math.floor((a.duration || 0) - 1));
  const sync = () => {
    $('avNewVal').textContent = `${$('avNew').value}%`;
    $('avOrigVal').textContent = `${$('avOrig').value}%`;
    $('avOffVal').textContent = mmss(+off.value);
    $('avOrigWrap').hidden = mode !== 'mix';
  };
  ['avNew', 'avOrig', 'avOff'].forEach((id) => $(id).addEventListener('input', sync));
  chips($('avMode'), (d) => { mode = d.m; sync(); });
  chips($('avLen'), (d) => { length = d.l; });
  chips($('avFade'), (d) => { fade = +d.f; });
  sync();
  getResult = () => ({ mode, newVol: +$('avNew').value / 100, origVol: +$('avOrig').value / 100, offset: +off.value, length, fadeOut: fade });
}

// ---------------- DESCARGAR ----------------
const QUALS = {
  mp4: [['best', 'Máxima'], ['2160', '4K'], ['1440', '1440p'], ['1080', '1080p'], ['720', '720p'], ['480', '480p'], ['360', '360p']],
  mp3: [['320', '320 kbps'], ['256', '256'], ['192', '192'], ['128', '128']],
};
const FMT_NOTES = {
  mp3: 'MP3 funciona en todos lados. Ojo: si el original es de menor calidad, subir los kbps no la mejora.',
  m4a: 'M4A: el audio original de YouTube/YouTube Music sin recomprimir (la mejor calidad posible de esos sitios).',
  opus: 'OPUS: el audio original de YouTube sin recomprimir. Liviano, pero no lo abre todo (por ej. algunas CDJ).',
  flac: 'FLAC sin pérdida a partir del original (sirve si el original ya es de alta calidad, como Bandcamp).',
  wav: 'WAV: sin compresión, para DAWs y CDJ. No agrega calidad sobre el original.',
  mp4: '',
};
function setupDownload(data) {
  let format = 'mp4', quality = 'best', cookies = data.cookies || '', dir = data.dir, busy = false, lastFiles = [];
  let info = null, probeSeq = 0;
  const url = $('dlUrl');
  url.value = data.url || '';
  $('dlDir').textContent = dir; $('dlDir').title = dir;
  const pick = (box, attr, val) => box.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset[attr] === val));
  pick($('dlCookies'), 'c', cookies);

  function renderQual() {
    const q = QUALS[format];
    $('dlQualRow').hidden = !q;
    $('dlFmtNote').textContent = FMT_NOTES[format] || '';
    if (!q) return;
    quality = q[0][0];
    $('dlQual').innerHTML = q.map(([v, l], i) => `<button data-q="${v}" class="${i === 0 ? 'on' : ''}">${l}</button>`).join('');
  }
  chips($('dlFmt'), (d) => { format = d.f; renderQual(); });
  $('dlQual').addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    $('dlQual').querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
    quality = b.dataset.q;
  });
  chips($('dlCookies'), (d) => { cookies = d.c; analyze(); });
  renderQual();

  const fmtDur = (s) => (s ? `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')}` : '');
  const selected = () => [...$('dlItems').querySelectorAll('input')].filter((i) => i.checked).map((i) => +i.dataset.i);
  function updateCount() {
    if (!info?.playlist) return;
    const n = selected().length;
    $('dlCount').textContent = `${n} de ${info.entries.length} seleccionadas`;
    $('dlAll').checked = n === info.entries.length;
    $('ok').textContent = n ? `Descargar ${n}` : 'Elegí al menos una';
    $('ok').disabled = !n;
  }
  $('dlAll').addEventListener('change', (e) => { $('dlItems').querySelectorAll('input').forEach((i) => { i.checked = e.target.checked; }); updateCount(); });
  $('dlItems').addEventListener('change', updateCount);

  // al pegar un link, se fija qué es (canción, video, playlist) y muestra la lista
  async function analyze() {
    const u = url.value.trim();
    info = null; $('dlList').hidden = true; $('ok').disabled = false; $('ok').textContent = 'Descargar';
    if (!/^https?:\/\//i.test(u)) { $('dlInfo').hidden = true; return; }
    const my = ++probeSeq;
    $('dlInfo').hidden = false; $('dlInfo').textContent = /spotify\.com/i.test(u) ? 'Leyendo Spotify…' : 'Buscando…';
    $('dlFmt').querySelector('[data-f=mp4]').disabled = false;
    const r = await ruedita.invoke('dl-probe', u, cookies);
    if (my !== probeSeq) return;
    if (r.error) { $('dlInfo').textContent = `No pude leer el link: ${r.error}`; return; }
    info = r;
    // Spotify: solo audio (se busca cada tema en YouTube Music y se le ponen los datos de Spotify)
    const vbtn = $('dlFmt').querySelector('[data-f=mp4]');
    vbtn.disabled = !!r.spotify;
    if (r.spotify && format === 'mp4') $('dlFmt').querySelector('[data-f=mp3]').click();
    if (r.playlist) {
      $('dlInfo').innerHTML = `${r.spotify ? '🟢' : '📃'} <b></b> <span class="muted">· ${r.entries.length} ${r.spotify ? 'temas' : 'elementos'}</span>${r.partial ? ' <span class="muted">(Spotify solo dejó ver los primeros 100, probá de nuevo en un rato)</span>' : ''}`;
      $('dlInfo').querySelector('b').textContent = r.title + (r.uploader ? ` — ${r.uploader}` : '');
      $('dlItems').innerHTML = '';
      for (const e of r.entries) {
        const l = document.createElement('label');
        l.innerHTML = `<input type="checkbox" checked data-i="${e.index}"><span class="t"></span><span class="d">${fmtDur(e.duration)}</span>`;
        l.querySelector('.t').textContent = `${e.index}. ${e.title}`;
        $('dlItems').appendChild(l);
      }
      $('dlList').hidden = false;
      updateCount();
    } else {
      $('dlInfo').innerHTML = `${r.spotify ? '🟢' : '🎵'} <b></b> <span class="muted">${fmtDur(r.duration)}</span>`;
      $('dlInfo').querySelector('b').textContent = r.title + (r.uploader ? ` — ${r.uploader}` : '');
    }
  }
  let t;
  url.addEventListener('input', () => {
    if (ok.dataset.state === 'done') { ok.dataset.state = ''; ok.textContent = 'Descargar'; }
    clearTimeout(t); t = setTimeout(analyze, 450);
  });
  $('dlPaste').onclick = async () => { try { url.value = (await navigator.clipboard.readText()).trim(); } catch {} analyze(); url.focus(); };
  $('dlPick').onclick = async () => { const d = await ruedita.invoke('dl-pick-dir'); if (d) { dir = d; $('dlDir').textContent = d; $('dlDir').title = d; } };
  ruedita.on('dl-url', (u) => { if (!busy) { url.value = u; analyze(); } });
  ruedita.on('dl-progress', ({ p, title, n, total }) => {
    if (title) $('dlStatus').textContent = total > 1 ? `(${n}/${total}) ${title}` : `Bajando: ${title}`;
    if (p != null) $('dlBar').style.width = `${Math.round(p * 100)}%`;
  });
  const ok = $('ok');
  ok.textContent = 'Descargar';
  $('cancel').textContent = 'Cerrar';
  if (url.value) analyze(); else setTimeout(() => url.focus(), 100);

  getResult = () => {
    if (lastFiles.length && ok.dataset.state === 'done') { ruedita.send('dl-open', lastFiles[0]); return null; }
    if (busy) return null;
    const u = url.value.trim();
    if (!/^https?:\/\//i.test(u)) { url.focus(); $('dlProg').hidden = false; $('dlStatus').textContent = 'Pegá un link que empiece con https://'; return null; }
    const isList = !!info?.playlist;
    const items = isList ? selected() : [];
    if (isList && !items.length) return null;
    busy = true; ok.disabled = true; ok.textContent = 'Descargando…';
    $('dlProg').hidden = false; $('dlBar').style.width = '0%'; $('dlStatus').textContent = 'Arrancando…';
    const opts = { format, quality, cookies, dir, playlist: isList, items: isList && items.length < info.entries.length ? items : null, total: isList ? items.length : 1,
      ...(info?.spotify ? { tracks: info.tracks, listTitle: info.title, album: info.album } : {}) };
    ruedita.invoke('dl-start', { url: u, opts }).then((r) => {
      busy = false; ok.disabled = false;
      if (r.error) { $('dlStatus').textContent = `No se pudo: ${r.error}`; ok.textContent = 'Reintentar'; ok.dataset.state = ''; return; }
      lastFiles = r.files;
      $('dlBar').style.width = '100%';
      const missing = isList ? items.length - r.files.length : 0;
      $('dlStatus').textContent = `Listo: ${r.files.length === 1 ? r.files[0].split(/[\\/]/).pop() : `${r.files.length} archivos`}${missing > 0 ? ` (${missing} no se pudieron bajar)` : ''}`;
      ok.textContent = 'Abrir carpeta'; ok.dataset.state = 'done';
    });
    return null;
  };
}

// ---------------- FONDO ----------------
const GRADIENTS = [
  ['#ff5e62', '#ff9966'], ['#f857a6', '#ff5858'], ['#fc6767', '#ec008c'], ['#f7971e', '#ffd200'],
  ['#4facfe', '#00f2fe'], ['#43e97b', '#38f9d7'], ['#a18cd1', '#fbc2eb'], ['#667eea', '#764ba2'],
  ['#0f0c29', '#302b63'], ['#232526', '#414345'], ['#ffffff', '#ececec'], ['#000000', '#000000'],
];
function setupBackground() {
  const W = info.width, H = info.height;
  const canvas = $('bgCanvas'), img = $('bgImg'), stage = canvas.parentElement;
  let colors = GRADIENTS[0], fmt = 'png';
  const sw = $('swatches');
  GRADIENTS.forEach((g, i) => {
    const b = document.createElement('button');
    b.style.background = `linear-gradient(135deg, ${g[0]}, ${g[1]})`;
    if (i === 0) b.classList.add('on');
    b.dataset.i = i;
    sw.appendChild(b);
  });
  chips(sw, (d) => { colors = GRADIENTS[+d.i]; draw(); });
  chips($('bgFmt'), (d) => { fmt = d.f; });

  function draw() {
    const pad = +$('bgPad').value, radF = +$('bgRad').value;
    const p = Math.max(W, H) * pad;
    const CW = W + 2 * p, CH = H + 2 * p;
    const s = Math.min((stage.clientWidth - 40) / CW, (stage.clientHeight - 40) / CH, 1);
    canvas.style.background = `linear-gradient(135deg, ${colors[0]}, ${colors[1]})`;
    canvas.style.padding = `${p * s}px`;
    img.style.width = `${W * s}px`;
    img.style.height = `${H * s}px`;
    img.style.borderRadius = `${radF * Math.min(W, H) * s}px`;
    img.style.boxShadow = $('bgShadow').checked ? `0 ${Math.max(W, H) * 0.02 * s}px ${Math.max(W, H) * 0.06 * s}px rgba(0,0,0,.35)` : 'none';
  }
  ['bgPad', 'bgRad', 'bgShadow'].forEach((id) => $(id).addEventListener('input', draw));
  img.onload = draw;
  img.src = info.dataUrl;
  window.addEventListener('resize', draw);

  getResult = () => ({
    colors, angle: 135, padding: +$('bgPad').value,
    radius: Math.round(+$('bgRad').value * Math.min(W, H)),
    shadow: $('bgShadow').checked, format: fmt,
  });
}

// ---------------- RECORTAR VIDEO / AUDIO ----------------
function fmtT(t, dec = true) {
  t = Math.max(0, t || 0);
  const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), sec = t % 60;
  const ss = dec ? sec.toFixed(1).padStart(4, '0') : String(Math.floor(sec)).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${m}:${ss}`;
}
function parseT(str) {
  const parts = String(str).trim().replace(',', '.').split(':').map(Number);
  if (!parts.length || parts.some((x) => !Number.isFinite(x))) return null;
  return parts.reduce((a, x) => a * 60 + x, 0);
}
function setupVtrim(data) {
  const v = $('vtVideo'), tl = $('vtTl'), sel = $('vtSel'), head = $('vtHead');
  const isVideo = data.kind === 'video';
  document.body.classList.toggle('vt-audio', !isVideo);
  $('vtFrameRow').hidden = !isVideo;
  $('vtWave').hidden = isVideo;
  const D = data.media.duration || 0;
  let inT = 0, outT = D, fast = false, usedProxy = false, scrub = false;

  // ----- fuente (con copia liviana si el formato no se puede ver acá) -----
  const msg = (t) => { $('vtMsg').hidden = !t; $('vtMsg').textContent = t || ''; };
  async function proxy() {
    if (usedProxy) return;
    usedProxy = true;
    msg('Preparando la vista previa…');
    try { v.src = await ruedita.invoke('media-proxy', data.files[0]); } catch { msg('No se puede mostrar la vista previa, pero el recorte funciona igual.'); }
  }
  const loadTimer = setTimeout(() => { if (!v.duration) proxy(); }, 5000);
  v.addEventListener('error', proxy);
  v.addEventListener('loadeddata', () => {
    clearTimeout(loadTimer);
    if (isVideo && !v.videoWidth) return proxy();
    msg('');
    fit();
  });
  v.src = data.url;

  // ----- línea de tiempo -----
  const X = (t) => (D ? (t / D) * 100 : 0);
  function draw() {
    Object.assign(sel.style, { left: `${X(inT)}%`, width: `${X(outT - inT)}%` });
    $('vtDimL').style.width = `${X(inT)}%`;
    $('vtDimR').style.width = `${100 - X(outT)}%`;
    const now = want ?? v.currentTime ?? 0;
    head.style.left = `${X(now)}%`;
    $('vtNow').textContent = fmtT(now);
    if (document.activeElement !== $('vtIn')) $('vtIn').value = fmtT(inT);
    if (document.activeElement !== $('vtOut')) $('vtOut').value = fmtT(outT);
    $('vtDur').textContent = fmtT(outT - inT);
  }
  function tick() {
    if (!v.paused && v.currentTime >= outT - 0.02) { v.pause(); v.currentTime = outT; }
    draw();
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);

  // al arrastrar llegan muchos saltos seguidos: se pide el siguiente recién cuando el video terminó el anterior
  let want = null;
  const seek = (t) => {
    want = Math.max(0, Math.min(D, t));
    if (!v.seeking) { v.currentTime = want; }
  };
  v.addEventListener('seeked', () => { if (want != null && Math.abs(v.currentTime - want) > 0.01) v.currentTime = want; else want = null; });
  const tAt = (e) => { const b = tl.getBoundingClientRect(); return Math.max(0, Math.min(1, (e.clientX - b.left) / b.width)) * D; };
  const MIN = Math.min(0.1, D / 2);
  let drag = null;
  // tocar o arrastrar en cualquier parte de la línea (también adentro del recorte o sobre la barrita blanca) = moverse por el video
  // los bordes azules cambian inicio/fin y la pestañita de arriba mueve todo el recorte
  tl.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    tl.setPointerCapture(e.pointerId);
    const h = e.target.dataset.h;
    const t = tAt(e);
    if (h === 'in' || h === 'out') drag = { h };
    else if (h === 'move') drag = { h: 'move', off: t - inT, len: outT - inT };
    else { drag = { h: 'seek' }; seek(t); }
    v.pause();
    tl.classList.add('dragging');
  });
  const hov = $('vtHover');
  tl.addEventListener('pointermove', (e) => {
    const t = tAt(e);
    const b = tl.getBoundingClientRect();
    hov.style.left = `${X(t)}%`; $('vtHoverT').textContent = fmtT(t, true); hov.classList.toggle('flip', e.clientX - b.left > b.width - 60);
    if (!drag) return;
    if (drag.h === 'in') { inT = Math.min(t, outT - MIN); seek(inT); }
    else if (drag.h === 'out') { outT = Math.max(t, inT + MIN); seek(outT); }
    else if (drag.h === 'move') { inT = Math.max(0, Math.min(D - drag.len, t - drag.off)); outT = inT + drag.len; seek(inT); }
    else seek(t);
  });
  const end = () => { drag = null; tl.classList.remove('dragging'); };
  tl.addEventListener('pointerup', end);
  tl.addEventListener('pointercancel', end);

  // cuadritos (video) o forma de onda (audio)
  if (isVideo) {
    const n = Math.max(6, Math.min(20, Math.round(tl.clientWidth / 100)));
    ruedita.invoke('media-thumbs', data.files[0], n).then((list) => {
      const strip = $('vtStrip');
      for (const u of list || []) { const im = document.createElement('img'); if (u) im.src = u; strip.appendChild(im); }
    }).catch(() => {});
  } else {
    let pk = [];
    const cv = $('vtWave');
    const paint = () => {
      const w = cv.clientWidth, h = cv.clientHeight, dpr = devicePixelRatio || 1;
      cv.width = w * dpr; cv.height = h * dpr;
      const g = cv.getContext('2d');
      g.scale(dpr, dpr);
      g.fillStyle = getComputedStyle(document.body).getPropertyValue('--accent') || '#002FA7';
      if (!pk.length) return;
      const bars = Math.max(1, Math.floor(w / 3));
      for (let i = 0; i < bars; i++) {
        const a = Math.floor((i / bars) * pk.length), b = Math.max(a + 1, Math.floor(((i + 1) / bars) * pk.length));
        let m = 0; for (let j = a; j < b; j++) m = Math.max(m, pk[j]);
        const bh = Math.max(1, m * (h - 10) * 0.85);
        g.fillRect(i * 3, (h - bh) / 2, 2, bh);
      }
    };
    ruedita.invoke('media-peaks', data.files[0]).then((p) => { pk = p || []; paint(); }).catch(() => {});
    window.addEventListener('resize', paint);
  }

  // ----- reproducir, marcar, teclado -----
  const ico = (playing) => { $('vtPlayIco').setAttribute('d', playing ? 'M6 4h4v16H6zM14 4h4v16h-4z' : 'M7 4l13 8-13 8z'); };
  v.addEventListener('play', () => ico(true));
  v.addEventListener('pause', () => ico(false));
  function toggle() {
    if (!v.paused) return v.pause();
    if (v.currentTime < inT || v.currentTime >= outT - 0.05) v.currentTime = inT;
    v.play().catch(() => {});
  }
  $('vtPlay').onclick = (e) => { e.currentTarget.blur(); toggle(); };
  const markIn = () => { inT = Math.min(v.currentTime, outT - MIN); };
  const markOut = () => { outT = Math.max(v.currentTime, inT + MIN); };
  $('vtSetIn').onclick = (e) => { e.currentTarget.blur(); markIn(); };
  $('vtSetOut').onclick = (e) => { e.currentTarget.blur(); markOut(); };
  for (const [id, set] of [['vtIn', (t) => { inT = Math.max(0, Math.min(t, outT - MIN)); seek(inT); }], ['vtOut', (t) => { outT = Math.min(D, Math.max(t, inT + MIN)); seek(outT); }]]) {
    const el = $(id);
    const apply = () => { const t = parseT(el.value); if (t != null) set(t); el.value = fmtT(id === 'vtIn' ? inT : outT); };
    el.addEventListener('change', apply);
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); apply(); el.blur(); } });
  }
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT') return;
    const k = e.key.toLowerCase();
    if (k === ' ') { e.preventDefault(); toggle(); }
    else if (k === 'i') markIn();
    else if (k === 'o') markOut();
    else if (k === 'arrowleft' || k === 'arrowright') {
      e.preventDefault();
      v.pause();
      seek(v.currentTime + (k === 'arrowleft' ? -1 : 1) * (e.shiftKey ? 1 : 1 / 30));
    }
  });

  chips($('vtMode'), (d) => { fast = d.f === '1'; });

  // ----- encuadre (solo video) -----
  const box = $('vtBox'), stage = $('vtStage');
  let ratio = 'none';
  let r = { x: 0.1, y: 0.1, w: 0.8, h: 0.8 };
  const VW = () => v.videoWidth || 16, VH = () => v.videoHeight || 9;
  function fit() {
    if (!isVideo) return;
    v.style.maxWidth = `${stage.clientWidth - 40}px`;
    v.style.maxHeight = `${stage.clientHeight - 40}px`;
    drawBox();
  }
  function drawBox() {
    box.hidden = ratio === 'none';
    const dw = v.clientWidth, dh = v.clientHeight;
    const L = r.x * dw, T = r.y * dh, Wd = r.w * dw, Hd = r.h * dh;
    Object.assign(box.style, { left: `${L}px`, top: `${T}px`, width: `${Wd}px`, height: `${Hd}px` });
    // oscurece lo que queda afuera del encuadre
    const sh = document.querySelectorAll('.vtshade');
    const rects = [[0, 0, dw, T], [0, T + Hd, dw, dh - T - Hd], [0, T, L, Hd], [L + Wd, T, dw - L - Wd, Hd]];
    sh.forEach((el, i) => { el.hidden = box.hidden; const [x, y, w, h] = rects[i]; Object.assign(el.style, { left: `${x}px`, top: `${y}px`, width: `${Math.max(0, w)}px`, height: `${Math.max(0, h)}px` }); });
  }
  function applyRatio() {
    const rt = typeof ratio === 'number' ? ratio : null;
    if (rt) {
      const W = VW(), H = VH();
      let w = 1, h = (w * W) / rt / H;
      if (h > 1) { h = 1; w = (h * H * rt) / W; }
      r = { w, h, x: (1 - w) / 2, y: (1 - h) / 2 };
    }
    drawBox();
  }
  chips($('vtRatios'), (d) => {
    ratio = d.r === 'none' ? 'none' : d.r === 'free' ? 'free' : parseFloat(d.r);
    if (ratio === 'free') r = { x: 0.1, y: 0.1, w: 0.8, h: 0.8 };
    if (ratio !== 'none' && fast) $('vtMode').querySelector('[data-f="0"]').click();
    applyRatio();
  });
  $('vtMode').addEventListener('click', (e) => {
    if (ratio !== 'none' && e.target.dataset.f === '1') { $('vtMode').querySelector('[data-f="0"]').click(); msg('Con encuadre el corte siempre es exacto (hay que recomprimir).'); setTimeout(() => msg(''), 2500); }
  });
  let bd = null;
  box.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    box.setPointerCapture(e.pointerId);
    bd = { h: e.target.dataset.h || 'move', sx: e.clientX, sy: e.clientY, r0: { ...r } };
  });
  box.addEventListener('pointermove', (e) => {
    if (!bd) return;
    const dw = v.clientWidth, dh = v.clientHeight, W = VW(), H = VH();
    const dx = (e.clientX - bd.sx) / dw, dy = (e.clientY - bd.sy) / dh, o = bd.r0, M = 0.05;
    const rt = typeof ratio === 'number' ? ratio : null;
    if (bd.h === 'move') {
      r.x = Math.min(Math.max(0, o.x + dx), 1 - o.w);
      r.y = Math.min(Math.max(0, o.y + dy), 1 - o.h);
    } else {
      let x0 = o.x, y0 = o.y, x1 = o.x + o.w, y1 = o.y + o.h;
      if (bd.h.includes('w')) x0 = Math.min(Math.max(0, o.x + dx), x1 - M);
      if (bd.h.includes('e')) x1 = Math.max(Math.min(1, x1 + dx), x0 + M);
      if (bd.h.includes('n')) y0 = Math.min(Math.max(0, o.y + dy), y1 - M);
      if (bd.h.includes('s')) y1 = Math.max(Math.min(1, y1 + dy), y0 + M);
      if (rt) {
        const w = x1 - x0;
        let h = (w * W) / rt / H;
        if (bd.h.includes('n')) { y0 = y1 - h; if (y0 < 0) { y0 = 0; h = y1; } }
        else { y1 = y0 + h; if (y1 > 1) { y1 = 1; h = 1 - y0; } }
        const w2 = (h * H * rt) / W;
        if (bd.h.includes('w')) x0 = x1 - w2; else x1 = x0 + w2;
      }
      r = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
    }
    drawBox();
  });
  box.addEventListener('pointerup', () => { bd = null; });
  box.addEventListener('pointercancel', () => { bd = null; });
  window.addEventListener('resize', fit);

  getResult = () => ({
    start: +inT.toFixed(3), end: +outT.toFixed(3), fast: fast && ratio === 'none',
    crop: isVideo && ratio !== 'none' ? { x: r.x, y: r.y, w: r.w, h: r.h } : null,
  });
}

// ---------------- A TEXTO ----------------
function setupTranscribe(data) {
  const m = data.media || {};
  const dur = m.duration || 0;
  const len = dur < 90 ? `${Math.round(dur)} s` : `${Math.floor(dur / 60)}:${String(Math.round(dur % 60)).padStart(2, '0')} min`;
  $('trInfo').textContent = `${data.name} · ${len}`;
  let lang = 'auto', out = 'both', voc = 0, ready = !!(data.tr && data.tr.available);
  const tr = data.tr || {};
  const srcDir = (data.files[0] || '').replace(/[\\/][^\\/]*$/, '');
  let outDir = null;
  try { outDir = localStorage.getItem('trOutDir') || null; } catch {}
  function showOut() {
    $('trSave').querySelectorAll('button').forEach((b) => b.classList.toggle('on', (b.dataset.s === 'folder') === !!outDir));
    $('trOutPath').textContent = outDir ? `→ ${outDir}` : `→ ${srcDir}`;
  }
  $('trSave').addEventListener('click', async (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.s === 'beside') { outDir = null; try { localStorage.removeItem('trOutDir'); } catch {} }
    else {
      const d = await ruedita.invoke('pick-folder', { title: 'Dónde guardar el texto y los subtítulos', defaultPath: outDir || srcDir });
      if (d) { outDir = d; try { localStorage.setItem('trOutDir', d); } catch {} }
    }
    showOut();
  });
  function showPack(info) {
    $('trDest').textContent = info.dest || '';
    $('trHave').hidden = !info.available;
    $('trWhere').textContent = info.where || '';
  }
  $('trDestBtn').onclick = async () => { const info = await ruedita.invoke('transcribe-pick-dir'); showPack(info); };
  $('trOpen').onclick = () => ruedita.send('open-folder', $('trWhere').textContent);
  showPack(tr);
  showOut();
  chips($('trLang'), (d) => { lang = d.l; });
  chips($('trOut'), (d) => { out = d.o; note(); });
  chips($('trVoc'), (d) => { voc = +d.v; note(); });
  function note() {
    const what = out === 'both' ? 'un .txt con el texto y un .srt con subtítulos' : out === 'txt' ? 'un .txt con el texto' : 'un .srt con subtítulos (Premiere, CapCut, YouTube…)';
    $('trNote').textContent = `Queda ${what} en la carpeta de arriba. Tarda más o menos lo que dura el audio (a veces menos)${voc ? ', un poco más si saca la voz primero' : ''}.`;
  }
  function setReady(r) {
    ready = r;
    $('trMissing').hidden = r;
    $('ok').disabled = !r;
  }
  $('trGet').onclick = async () => {
    $('trGet').disabled = true; $('trDestBtn').disabled = true; $('trGet').textContent = 'Bajando…';
    ruedita.on('transcribe-install-progress', (p) => { $('trBar').style.width = `${Math.round(p * 100)}%`; $('trPct').textContent = p >= 0.99 ? 'Instalando…' : `${Math.round(p * 100)}%`; });
    const r = await ruedita.invoke('transcribe-install');
    if (r && r.ok) { setReady(true); showPack(await ruedita.invoke('transcribe-info')); }
    else { $('trGet').disabled = false; $('trDestBtn').disabled = false; $('trGet').textContent = 'Reintentar'; $('trPct').textContent = (r && r.error) || 'No se pudo bajar'; }
  };
  setReady(ready);
  note();
  getResult = () => (ready ? { language: lang, output: out, vocals: !!voc, outDir } : null);
}


// ---------------- orden para unir en un PDF ----------------
function setupOrder(data) {
  const start = data.items || data.files.map((f) => ({ path: f, name: f.split(/[\\/]/).pop() }));
  let items = start.slice();
  const list = $('ordList');
  let dragFrom = -1;
  function move(from, to) {
    if (to < 0 || to >= items.length || from === to) return;
    const [it] = items.splice(from, 1);
    items.splice(to, 0, it);
    render();
  }
  function render() {
    list.innerHTML = '';
    items.forEach((it, i) => {
      const li = document.createElement('li');
      li.className = 'ord-card'; li.draggable = true; li.dataset.i = i;
      const num = document.createElement('span'); num.className = 'ord-num'; num.textContent = i + 1;
      const th = document.createElement('div'); th.className = 'ord-thumb';
      if (it.thumb) { const im = document.createElement('img'); im.src = it.thumb; im.alt = ''; th.appendChild(im); }
      else { const ph = document.createElement('span'); ph.className = 'ph'; ph.textContent = it.kind === 'pdf' ? 'PDF' : 'IMG'; th.appendChild(ph); }
      const nm = document.createElement('div'); nm.className = 'ord-name'; nm.textContent = it.name; nm.title = it.name;
      const meta = document.createElement('div'); meta.className = 'ord-meta';
      meta.textContent = it.kind === 'pdf' ? (it.pages ? `PDF · ${it.pages} ${it.pages === 1 ? 'página' : 'páginas'}` : 'PDF') : 'Imagen · 1 página';
      const ar = document.createElement('div'); ar.className = 'ord-arrows';
      const l = document.createElement('button'); l.textContent = '←'; l.setAttribute('aria-label', `Mover ${it.name} antes`); l.disabled = i === 0; l.onclick = () => move(i, i - 1);
      const r = document.createElement('button'); r.textContent = '→'; r.setAttribute('aria-label', `Mover ${it.name} después`); r.disabled = i === items.length - 1; r.onclick = () => move(i, i + 1);
      ar.append(l, r);
      li.append(num, th, nm, meta, ar);
      li.addEventListener('dragstart', (e) => { dragFrom = i; li.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', String(i)); } catch {} });
      li.addEventListener('dragend', () => { dragFrom = -1; li.classList.remove('dragging'); document.querySelectorAll('.ord-card.over').forEach((x) => x.classList.remove('over')); });
      li.addEventListener('dragover', (e) => { if (dragFrom < 0) return; e.preventDefault(); e.dataTransfer.dropEffect = 'move'; li.classList.add('over'); });
      li.addEventListener('dragleave', () => li.classList.remove('over'));
      li.addEventListener('drop', (e) => { e.preventDefault(); li.classList.remove('over'); if (dragFrom >= 0) move(dragFrom, i); });
      list.appendChild(li);
    });
    const pages = items.reduce((n, it) => n + (it.kind === 'pdf' ? (it.pages || 0) : 1), 0);
    const unknown = items.some((it) => it.kind === 'pdf' && !it.pages);
    $('fileName').textContent = `${items.length} archivos${pages && !unknown ? ` · ${pages} páginas` : ''}`;
  }
  const coll = new Intl.Collator('es', { numeric: true, sensitivity: 'base' });
  $('ordName').onclick = () => { items.sort((a, b) => coll.compare(a.name, b.name)); render(); };
  $('ordRev').onclick = () => { items.reverse(); render(); };
  $('ordReset').onclick = () => { items = start.slice(); render(); };
  render();
  getResult = () => ({ order: items.map((it) => it.path) });
}


// ---------------- renombrar ----------------
function setupRename(data) {
  const R = window.MXRename;
  const rules = JSON.parse(JSON.stringify(R.DEFAULT_RULES));
  try { Object.assign(rules, JSON.parse(localStorage.getItem('rnRules') || '{}')); } catch {}
  const base = data.items.slice();
  let items = base.slice();
  const hasTags = items.some((it) => it.tags && (it.tags.title || it.tags.artist));
  $('fileName').textContent = `${items.length} ${items.length === 1 ? 'archivo' : 'archivos'}`;
  if (!hasTags) $('rnTagsRule').hidden = true;
  const get = (k) => k.split('.').reduce((o, p) => o[p], rules);
  const set = (k, v) => { const [a, b] = k.split('.'); rules[a][b] = v; };
  const root = $('rnRules');
  // controles ← reglas
  root.querySelectorAll('[data-k]').forEach((el) => {
    const k = el.dataset.k, v = get(k);
    if (el.classList.contains('chips')) el.querySelectorAll('button').forEach((b) => b.classList.toggle('on', String(v) === b.dataset.v));
    else if (el.type === 'checkbox') el.checked = !!v;
    else el.value = v ?? '';
  });
  rules.list.text = rules.list.text || ''; // la lista no se guarda entre usos (es para esta tanda)
  const paintOn = () => root.querySelectorAll('.rn-rule').forEach((r) => r.classList.toggle('on', !!rules[r.dataset.r].on));
  root.addEventListener('input', (e) => {
    const el = e.target; const k = el.dataset.k; if (!k) return;
    set(k, el.type === 'checkbox' ? el.checked : el.type === 'number' ? Number(el.value || 0) : el.value);
    paintOn(); render();
  });
  root.addEventListener('click', (e) => {
    const b = e.target.closest('.chips button'); if (!b) return;
    const c = b.closest('.chips'); c.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
    const v = b.dataset.v; set(c.dataset.k, /^\d+$/.test(v) ? Number(v) : v); render();
  });
  // orden
  const coll = new Intl.Collator('es', { numeric: true, sensitivity: 'base' });
  $('rnOrder').onclick = (e) => {
    const b = e.target.closest('button'); if (!b) return;
    $('rnOrder').querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
    if (b.dataset.o === 'given') items = base.slice();
    if (b.dataset.o === 'name') items.sort((a, c) => coll.compare(a.name, c.name));
    if (b.dataset.o === 'date') items.sort((a, c) => (a.mtime || 0) - (c.mtime || 0));
    render();
  };
  const list = $('rnList');
  let dragFrom = -1, out = [];
  function render() {
    try { localStorage.setItem('rnRules', JSON.stringify({ ...rules, list: { on: false, text: '' } })); } catch {}
    out = R.computeNames(items, rules, data.existing);
    const shown = Math.min(items.length, 400);
    list.innerHTML = '';
    for (let i = 0; i < shown; i++) {
      const it = items[i], o = out[i];
      const row = document.createElement('div');
      row.className = `rn-row${o.clash ? ' clash' : ''}${o.same ? ' same' : ''}`; row.draggable = true; row.dataset.i = i;
      row.innerHTML = '<span class="rn-grip" aria-hidden="true">⋮⋮</span><span class="n"></span><span class="from"></span><span class="ar" aria-hidden="true">→</span><span class="to"></span>';
      row.querySelector('.n').textContent = i + 1;
      row.querySelector('.from').textContent = it.name; row.querySelector('.from').title = it.name;
      const to = row.querySelector('.to');
      to.textContent = o.name; to.title = 'Tocá para escribir el nombre a mano'; if (o.fixed) to.classList.add('fixed');
      to.addEventListener('click', () => {
        const [b0, ext] = R.splitName(o.name);
        const inp = document.createElement('input'); inp.className = 'to-in'; inp.value = it.manual ?? b0; inp.setAttribute('aria-label', `Nombre nuevo de ${it.name}`);
        to.replaceWith(inp); inp.focus(); inp.select();
        let done = false;
        const save = (keep) => { if (done) return; done = true; if (keep) it.manual = inp.value.trim() || null; render(); if (keep && next) { const nx = list.querySelectorAll('.rn-row .to')[i + 1]; if (nx) nx.click(); } };
        let next = false;
        inp.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); e.stopPropagation(); next = true; save(true); }
          if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); save(false); }
        });
        inp.addEventListener('blur', () => save(true));
        void ext;
      });
      if (it.manual) { const c = document.createElement('button'); c.className = 'clr'; c.textContent = '×'; c.title = 'Volver a las reglas'; c.setAttribute('aria-label', 'Sacar el nombre puesto a mano'); c.onclick = () => { it.manual = null; render(); }; row.appendChild(c); } else row.appendChild(document.createElement('span'));
      row.addEventListener('dragstart', (e) => { dragFrom = i; row.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', String(i)); } catch {} });
      row.addEventListener('dragend', () => { dragFrom = -1; row.classList.remove('dragging'); });
      row.addEventListener('dragover', (e) => { if (dragFrom < 0) return; e.preventDefault(); row.classList.add('over'); });
      row.addEventListener('dragleave', () => row.classList.remove('over'));
      row.addEventListener('drop', (e) => {
        e.preventDefault(); row.classList.remove('over'); if (dragFrom < 0 || dragFrom === i) return;
        const [m] = items.splice(dragFrom, 1); items.splice(i, 0, m); render();
      });
      list.appendChild(row);
    }
    const changed = out.filter((o) => !o.same).length, clashes = out.filter((o) => o.clash).length;
    $('rnSum').innerHTML = '';
    const pill = (t, bad) => { const sp = document.createElement('span'); sp.textContent = t; if (bad) sp.className = 'bad'; $('rnSum').appendChild(sp); };
    pill(changed === 1 ? '1 cambia' : `${changed} cambian`);
    if (items.length - changed) pill(`${items.length - changed} quedan igual`);
    const hand = out.filter((o) => o.fixed).length; if (hand) pill(hand === 1 ? '1 con nombre propio' : `${hand} con nombre propio`);
    if (clashes) pill(clashes === 1 ? '1 nombre repetido → le agrego «(2)»' : `${clashes} nombres repetidos → les agrego «(2)», «(3)»…`, true);
    $('ok').textContent = changed ? `Renombrar ${changed}` : 'Renombrar';
    $('ok').disabled = !changed;
  }
  paintOn(); render();
  getResult = () => ({ renames: items.map((it, i) => ({ from: it.path, to: out[i].name })).filter((r, i) => !out[i].same) });
}

// ---------------- init ----------------
(async () => {
  const data = await ruedita.invoke(`editor-init-${WIN}`);
  info = data.preview;
  $('title').textContent = TITLES[MODE] || 'MIXTAPE';
  $('fileName').textContent = data.files.length > 1 ? `${data.name} y ${data.files.length - 1} más` : data.name;
  $(MODE).hidden = false;
  if (MODE === 'crop') { setupCrop(); $('ok').textContent = 'Recortar'; }
  if (MODE === 'resize') { setupResize(data.files); $('ok').textContent = 'Cambiar tamaño'; }
  if (MODE === 'background') { setupBackground(); $('ok').textContent = 'Guardar'; }
  if (MODE === 'upscale') { setupUpscale(data.files); $('ok').textContent = 'Mejorar'; }
  if (MODE === 'rotate') { setupRotate(data.kind); $('ok').textContent = 'Rotar'; }
  if (MODE === 'compress') { setupCompress(data); $('ok').textContent = 'Comprimir'; }
  if (MODE === 'stems') { setupStems(data); }
  if (MODE === 'midi') { setupMidi(data); }
  if (MODE === 'keybpm') { setupKeyBpm(data); }
  if (MODE === 'av_adjust') { setupAvAdjust(data); $('ok').textContent = 'Crear video'; }
  if (MODE === 'download') { setupDownload(data); }
  if (MODE === 'blur') { setupBlur(data.files[0]); }
  if (MODE === 'vtrim') { setupVtrim(data); $('ok').textContent = 'Recortar'; }
  if (MODE === 'transcribe') { setupTranscribe(data); $('ok').textContent = 'Transcribir'; }
  if (MODE === 'order') { setupOrder(data); $('ok').textContent = 'Unir'; }
  if (MODE === 'rename') { setupRename(data); }
  if (MODE === 'ocr') { setupOcr(data); }
  if (MODE === 'vedit') { setupVedit(data); }
})();
