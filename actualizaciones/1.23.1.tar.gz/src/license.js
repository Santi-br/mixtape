// Licencias de MIXTAPE (edición "venta"). La de amigos no usa esto: trae todo.
//
// Clave: "MXT1-" + base32 (Crockford) de [datos 14 bytes | firma Ed25519 64 bytes].
//   datos: versión de formato (1) · plan (1) · compus (1) · versión máxima (1, 0 = todas) · id (8) · emitida (2, días desde 2026-01-01)
//   Solo quien tiene la clave privada (el servidor de activación / Santi) puede fabricar claves: no se pueden inventar.
// Activación: una sola vez online (servidor en ACTIVATE_URL: cuenta compus por clave y devuelve un comprobante
//   firmado para esta compu). Después anda sin internet. Mientras no haya servidor, se acepta la clave firmada sola
//   y queda atada a esta compu.
// Devoluciones: el feed de actualizaciones (version.json) puede traer "revoked": [ids]; si la clave está, vuelve a Gratis.
// Prueba: 7 días de Premium, una vez por compu (guardada en dos lugares, con control de reloj atrasado).
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const plans = require('./plans');

const PUBLIC_KEY = 'MCowBQYDK2VwAyEAhto/YivIV810kYxLAOML0GdCKjjj0ZPSft9FSSVXU54='; // cambiada el 22/11 (la anterior se compartió por error)
const ACTIVATE_URL = ''; // se completa cuando esté el servidor (Paddle → activación)
const TRIAL_DAYS = 7;
const PLAN_CODE = { 1: 'pro', 2: 'premium', 3: 'studio' };
const CODE_OF = { pro: 1, premium: 2, studio: 3 };
const EPOCH = Date.UTC(2026, 0, 1);

// ---------- base32 Crockford ----------
const A = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
function b32enc(buf) {
  let bits = 0, val = 0, out = '';
  for (const b of buf) { val = (val << 8) | b; bits += 8; while (bits >= 5) { out += A[(val >>> (bits - 5)) & 31]; bits -= 5; } }
  if (bits > 0) out += A[(val << (5 - bits)) & 31];
  return out;
}
function b32dec(str) {
  const s = str.toUpperCase().replace(/[^0-9A-Z]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
  let bits = 0, val = 0; const out = [];
  for (const ch of s) { const v = A.indexOf(ch); if (v < 0) return null; val = (val << 5) | v; bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(out);
}

let pub = null;
const pubKey = () => (pub ||= crypto.createPublicKey({ key: Buffer.from(PUBLIC_KEY, 'base64'), format: 'der', type: 'spki' }));
const verifySig = (data, sig) => { try { return crypto.verify(null, data, pubKey(), sig); } catch { return false; } };

// Lee una clave. Devuelve { id, plan, seats, maxMajor, issued } o null si no es válida.
function parseKey(key) {
  const m = /^\s*MXT1-?([0-9A-Za-z\- ]+)\s*$/.exec(String(key || ''));
  if (!m) return null;
  const raw = b32dec(m[1]);
  if (!raw || raw.length < 78) return null;
  const data = raw.subarray(0, 14), sig = raw.subarray(14, 78);
  if (data[0] !== 1 || !verifySig(data, sig)) return null;
  const plan = PLAN_CODE[data[1]];
  if (!plan) return null;
  return { id: data.subarray(4, 12).toString('hex'), plan, seats: data[2], maxMajor: data[3], issued: new Date(EPOCH + data.readUInt16BE(12) * 864e5) };
}

// Solo para el generador de claves (tools/keygen.js), con la clave privada
function makeKey(privatePem, { plan, seats, maxMajor = 0, id } = {}) {
  const data = Buffer.alloc(14);
  data[0] = 1; data[1] = CODE_OF[plan]; data[2] = seats ?? plans.SEATS[plan]; data[3] = maxMajor;
  (id ? Buffer.from(id, 'hex') : crypto.randomBytes(8)).copy(data, 4);
  data.writeUInt16BE(Math.max(0, Math.floor((Date.now() - EPOCH) / 864e5)), 12);
  const sig = crypto.sign(null, data, crypto.createPrivateKey(privatePem));
  return `MXT1-${b32enc(Buffer.concat([data, sig]))}`;
}

// ---------- esta compu ----------
let machine = null;
function machineId() {
  if (machine) return machine;
  let hw = '';
  try {
    const { execFileSync } = require('child_process');
    if (process.platform === 'win32') {
      const out = execFileSync('reg', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'], { encoding: 'utf8', windowsHide: true });
      hw = (/MachineGuid\s+REG_SZ\s+(\S+)/.exec(out) || [])[1] || '';
    } else if (process.platform === 'darwin') {
      const out = execFileSync('ioreg', ['-rd1', '-c', 'IOPlatformExpertDevice'], { encoding: 'utf8' });
      hw = (/"IOPlatformUUID" = "([^"]+)"/.exec(out) || [])[1] || '';
    }
  } catch {}
  machine = crypto.createHash('sha256').update(`mixtape|${hw}|${os.hostname()}|${os.platform()}`).digest('hex').slice(0, 24);
  return machine;
}

// ---------- estado guardado ----------
let dir = null, state = null;
const file = () => path.join(dir, 'licencia.json');
// segundo lugar para la prueba (así borrar licencia.json no la reinicia)
const trialMark = () => path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), '.local', 'share'), '.mxt-t');
function seal(o) { return crypto.createHmac('sha256', `mxt|${machineId()}`).update(JSON.stringify(o)).digest('hex').slice(0, 32); }

function load(userData) {
  dir = userData;
  try { state = JSON.parse(fs.readFileSync(file(), 'utf8')); } catch { state = {}; }
  // el sello se calcula sobre todo menos el sello: si alguien edita el archivo a mano, no vale
  const { sealv, ...rest } = state;
  if (sealv !== seal(rest)) state = {}; // editado a mano o no existe: de cero (la prueba sigue marcada en el otro lugar)
  try { const t = +fs.readFileSync(trialMark(), 'utf8'); if (t && (!state.trialStart || t < state.trialStart)) state.trialStart = t; } catch {}
  // reloj atrasado: si la hora de ahora es anterior a la última vez que se usó, la prueba se da por terminada
  const now = Date.now();
  if (state.lastSeen && now < state.lastSeen - 36e5) state.clockBack = true;
  state.lastSeen = Math.max(state.lastSeen || 0, now);
  save();
  return status();
}
function save() {
  if (!dir) return;
  const { sealv, ...rest } = state;
  try { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(file(), JSON.stringify({ ...rest, sealv: seal(rest) })); } catch {}
}

function currentMajor() {
  try { return +String((global.MX && global.MX.version) || require('../package.json').version).split('.')[0] || 1; } catch { return 1; }
}

// ---------- qué versión tiene ahora ----------
function status() {
  const s = state || {};
  const out = { plan: 'free', name: plans.NAMES.free, key: null, trial: null, note: null };
  if (s.key && s.machine === machineId() && !s.revoked) {
    const k = parseKey(s.key);
    if (k) {
      if (k.maxMajor && currentMajor() > k.maxMajor) {
        out.note = `Tu clave de ${plans.NAMES[k.plan]} es para la versión ${k.maxMajor}. Esta es la ${currentMajor()}.`;
      } else {
        Object.assign(out, { plan: k.plan, name: plans.NAMES[k.plan], key: { id: k.id, plan: k.plan, seats: k.seats, maxMajor: k.maxMajor, masked: mask(s.key) } });
        return out;
      }
    }
  }
  if (s.revoked) out.note = 'La clave de esta compu quedó desactivada (devolución). Volvió a Gratis.';
  if (s.trialStart) {
    const left = Math.ceil((s.trialStart + TRIAL_DAYS * 864e5 - Date.now()) / 864e5);
    const active = left > 0 && !s.clockBack;
    out.trial = { used: true, active, daysLeft: Math.max(0, left) };
    if (active) { out.plan = 'trial'; out.name = plans.NAMES.trial; }
  } else out.trial = { used: false, active: false, daysLeft: TRIAL_DAYS };
  return out;
}
const mask = (k) => `${k.slice(0, 9)}…${k.slice(-4)}`;

function startTrial() {
  if (state.trialStart) return status();
  state.trialStart = Date.now();
  try { fs.mkdirSync(path.dirname(trialMark()), { recursive: true }); fs.writeFileSync(trialMark(), String(state.trialStart)); } catch {}
  save();
  return status();
}

// Activa una clave en esta compu. Devuelve { ok, status } o { ok: false, error }
async function activate(key) {
  key = String(key || '').trim();
  const k = parseKey(key);
  if (!k) return { ok: false, error: 'Esa clave no es válida. Copiala entera del mail de compra (empieza con MXT1-).' };
  if (k.maxMajor && currentMajor() > k.maxMajor) return { ok: false, error: `Esa clave de ${plans.NAMES[k.plan]} es para la versión ${k.maxMajor} de MIXTAPE.` };
  let receipt = null;
  if (ACTIVATE_URL) {
    try {
      const { net } = require('electron');
      const r = await net.fetch(ACTIVATE_URL, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ key, machine: machineId(), app: currentMajor() }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) return { ok: false, error: j.error || 'No se pudo activar. Revisá la conexión y probá de nuevo.' };
      receipt = j.receipt || null;
    } catch { return { ok: false, error: 'Para activar hace falta internet una sola vez. Conectate y probá de nuevo.' }; }
  }
  Object.assign(state, { key, machine: machineId(), activatedAt: Date.now(), receipt, revoked: false });
  save();
  return { ok: true, status: status() };
}

function deactivate() {
  delete state.key; delete state.machine; delete state.receipt; delete state.revoked;
  save();
  return status();
}

// desde el feed de actualizaciones: claves devueltas
function applyRevoked(ids) {
  if (!state?.key || !Array.isArray(ids)) return false;
  const k = parseKey(state.key);
  if (!k || !ids.includes(k.id) || state.revoked) return false;
  state.revoked = true; save();
  return true;
}

const plan = () => status().plan;

module.exports = { load, status, plan, activate, deactivate, startTrial, applyRevoked, parseKey, makeKey, machineId, TRIAL_DAYS, b32enc, b32dec };
