/* global ruedita, $, MODE, getResult:writable, fmtT */
// Editor de video básico (diseño E3): pistas de video (la de arriba tapa a la de abajo) y de audio (se mezclan).
// Clip = { id, file, kind: video|image|audio, track, start, in, out, volume, mute, fadeIn, fadeOut, box }
// La vista previa se arma en un canvas con un <video>/<audio>/<img> por clip, sincronizados con un reloj propio.
function setupVedit(data) {
  const IMG_DEFAULT = 4, MIN_LEN = 0.1, SNAP_PX = 8, HEAD_W = 116;
  const media = new Map(); // file → { url, dur, w, h, hasAudio, kind, thumbs, peaks }
  for (const it of data.items || []) media.set(it.file, { ...it, thumbs: null, peaks: null });
  let uid = 1;
  const P = {
    format: 'first',
    tracks: [{ id: 'v1', kind: 'v', name: 'Video' }, { id: 'v2', kind: 'v', name: 'Encima' }, { id: 'a1', kind: 'a', name: 'Música' }],
    clips: [],
  };
  let sel = null, t = 0, playing = false, pps = 20, clock = { t0: 0, at: 0 };
  const undo = [], redo = [];

  // ---------- elementos ----------
  const cv = $('veCanvas'), ctx = cv.getContext('2d');
  const lanes = $('veLanes'), heads = $('veHeads'), ruler = $('veRuler'), head = $('veHead'), side = $('veSide');

  // ---------- modelo ----------
  const len = (c) => c.out - c.in;
  const end = (c) => c.start + len(c);
  const total = () => Math.max(0, ...P.clips.map(end));
  const trackOf = (id) => P.tracks.find((x) => x.id === id);
  const kindOk = (c, tr) => (c.kind === 'audio') === (tr.kind === 'a');
  const vTracks = () => P.tracks.filter((x) => x.kind === 'v');
  const aTracks = () => P.tracks.filter((x) => x.kind === 'a');
  const rows = () => [...vTracks().slice().reverse(), ...aTracks()];
  const nameOf = (f) => f.split(/[\\/]/).pop();
  const snap = () => JSON.stringify({ format: P.format, tracks: P.tracks, clips: P.clips });
  function commit() { undo.push(snap()); if (undo.length > 80) undo.shift(); redo.length = 0; }
  function restore(s) { const o = JSON.parse(s); P.format = o.format; P.tracks = o.tracks; P.clips = o.clips; if (sel && !P.clips.find((c) => c.id === sel)) sel = null; syncEls(); render(); }

  function addFiles(items, at) {
    for (const it of items) if (!media.has(it.file)) media.set(it.file, { ...it, thumbs: null, peaks: null });
    let tv = at ?? Math.max(0, ...P.clips.filter((c) => c.track === 'v1').map(end));
    let ta = Math.max(0, ...P.clips.filter((c) => c.track === aTracks()[0].id).map(end));
    for (const it of items) {
      const m = media.get(it.file);
      if (m.kind === 'audio') {
        P.clips.push({ id: uid++, file: it.file, kind: 'audio', track: aTracks()[0].id, start: ta, in: 0, out: m.dur, volume: 1, mute: false, fadeIn: false, fadeOut: false });
        ta += m.dur;
      } else {
        const d = m.kind === 'image' ? IMG_DEFAULT : m.dur;
        P.clips.push({ id: uid++, file: it.file, kind: m.kind, track: 'v1', start: tv, in: 0, out: d, volume: 1, mute: false, fadeIn: false, fadeOut: false, box: 'full' });
        tv += d;
      }
      loadExtras(it.file);
    }
  }
  async function loadExtras(file) {
    const m = media.get(file);
    if (m.kind === 'video' && !m.thumbs) { m.thumbs = []; ruedita.invoke('media-thumbs', file, 14).then((th) => { m.thumbs = th || []; render(); }).catch(() => {}); }
    if (m.kind === 'image' && !m.thumbs) m.thumbs = [m.url];
    if ((m.kind === 'audio' || m.hasAudio) && !m.peaks) { m.peaks = []; ruedita.invoke('media-peaks', file).then((pk) => { m.peaks = pk || []; render(); }).catch(() => {}); }
  }

  // lugar libre más cercano en una pista (no se pisan clips en la misma pista)
  function freeStart(c, track, want) {
    const others = P.clips.filter((o) => o.track === track && o.id !== c.id).sort((a, b) => a.start - b.start);
    const L = len(c);
    const fits = (s) => s >= 0 && others.every((o) => s + L <= o.start + 1e-6 || s >= end(o) - 1e-6);
    if (fits(want)) return want;
    const cands = [0, ...others.map(end), ...others.map((o) => o.start - L)].filter((s) => s >= 0 && fits(s));
    cands.sort((a, b) => Math.abs(a - want) - Math.abs(b - want));
    return cands.length ? cands[0] : Math.max(0, ...others.map(end));
  }

  // ---------- vista previa ----------
  const els = new Map(); // clip id → elemento
  function outSize() {
    if (P.format === '16:9') return [1920, 1080];
    if (P.format === '9:16') return [1080, 1920];
    if (P.format === '1:1') return [1080, 1080];
    const vt = vTracks().map((x) => x.id);
    const f = P.clips.filter((c) => c.kind !== 'audio').sort((a, b) => vt.indexOf(a.track) - vt.indexOf(b.track) || a.start - b.start)[0];
    const m = f && media.get(f.file);
    return m && m.w ? [m.w, m.h] : [1920, 1080];
  }
  function fitCanvas() {
    const [W, H] = outSize();
    const box = $('veScreen');
    const k = Math.min(box.clientWidth / W, box.clientHeight / H);
    cv.style.width = `${Math.floor(W * k)}px`; cv.style.height = `${Math.floor(H * k)}px`;
    const s = Math.min(1, 1280 / Math.max(W, H));
    cv.width = Math.round(W * s); cv.height = Math.round(H * s);
    draw();
  }
  function mkEl(c) {
    const m = media.get(c.file);
    let el;
    if (c.kind === 'image') { el = new Image(); el.src = m.url; el.onload = draw; }
    else {
      el = document.createElement(c.kind === 'audio' ? 'audio' : 'video');
      el.preload = 'auto'; el.playsInline = true; el.src = m.proxy || m.url;
      el.addEventListener('seeked', () => { if (!playing) draw(); });
      el.addEventListener('loadeddata', () => { if (!playing) { seekAll(); draw(); } });
      el.addEventListener('error', () => useProxy(c.file));
    }
    els.set(c.id, el);
    return el;
  }
  async function useProxy(file) {
    const m = media.get(file);
    if (m.proxyTried) return;
    m.proxyTried = true;
    msg('Preparando la vista previa de ' + nameOf(file) + '…');
    try {
      m.proxy = await ruedita.invoke('media-proxy', file);
      for (const c of P.clips.filter((x) => x.file === file)) { const el = els.get(c.id); if (el && el.tagName !== 'IMG') { el.src = m.proxy; } }
      msg('');
    } catch { msg('No se puede ver ' + nameOf(file) + ' acá, pero se exporta igual.'); }
  }
  function syncEls() {
    for (const [id, el] of els) if (!P.clips.find((c) => c.id === id)) { if (el.pause) el.pause(); el.removeAttribute('src'); els.delete(id); }
    for (const c of P.clips) if (!els.has(c.id)) mkEl(c);
  }
  const active = (c, at) => at >= c.start && at < end(c);
  const fadeK = (c, at) => {
    const d = Math.min(0.6, len(c) / 3), x = at - c.start;
    let k = 1;
    if (c.fadeIn && x < d) k = Math.min(k, x / d);
    if (c.fadeOut && len(c) - x < d) k = Math.min(k, (len(c) - x) / d);
    return Math.max(0, Math.min(1, k));
  };
  function placement(c, W, H) {
    const m = media.get(c.file);
    const ar = m && m.w && m.h ? m.w / m.h : W / H;
    if (!c.box || c.box === 'full') { let w = W, h = W / ar; if (h > H) { h = H; w = H * ar; } return { w, h, x: (W - w) / 2, y: (H - h) / 2 }; }
    const mg = Math.min(W, H) * 0.04;
    let w = W * 0.34, h = w / ar; if (h > H * 0.45) { h = H * 0.45; w = h * ar; }
    return { w, h, x: c.box.endsWith('l') ? mg : W - w - mg, y: c.box.startsWith('t') ? mg : H - h - mg };
  }
  function draw() {
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, cv.width, cv.height);
    for (const tr of vTracks()) {
      if (tr.hidden) continue;
      const c = P.clips.find((x) => x.track === tr.id && active(x, t));
      if (!c) continue;
      const el = els.get(c.id);
      if (!el) continue;
      const ready = el.tagName === 'IMG' ? el.complete && el.naturalWidth : el.readyState >= 2;
      if (!ready) continue;
      const p = placement(c, cv.width, cv.height);
      ctx.globalAlpha = fadeK(c, t);
      try { ctx.drawImage(el, p.x, p.y, p.w, p.h); } catch {}
      ctx.globalAlpha = 1;
    }
    $('veNow').textContent = fmtT(t);
    head.style.left = `${t * pps}px`;
  }
  // pone cada medio en su lugar para el tiempo t (parado) o lo sigue (reproduciendo)
  function seekAll() {
    for (const c of P.clips) {
      const el = els.get(c.id);
      if (!el || el.tagName === 'IMG') continue;
      const tr = trackOf(c.track);
      if (active(c, t)) {
        const want = c.in + (t - c.start);
        if (playing) {
          if (el.paused) { el.currentTime = want; el.play().catch(() => {}); }
          else if (Math.abs(el.currentTime - want) > 0.3) el.currentTime = want;
        } else if (Math.abs(el.currentTime - want) > 0.02) el.currentTime = want;
        el.muted = !!(c.mute || tr.muted || (c.kind === 'video' && tr.hidden));
        el.volume = Math.max(0, Math.min(1, (c.volume ?? 1) * fadeK(c, t)));
      } else if (!el.paused) el.pause();
    }
  }
  function tick() {
    if (!playing) return;
    t = clock.t0 + (performance.now() - clock.at) / 1000;
    if (t >= total()) { t = total(); pause(); }
    seekAll(); draw(); autoScroll();
    requestAnimationFrame(tick);
  }
  function play() { if (!P.clips.length) return; if (t >= total() - 0.05) t = 0; playing = true; clock = { t0: t, at: performance.now() }; $('vePlayIco').setAttribute('d', 'M6 4h4v16H6zM14 4h4v16h-4z'); tick(); }
  function pause() { playing = false; for (const el of els.values()) if (el.pause) el.pause(); $('vePlayIco').setAttribute('d', 'M7 4l13 8-13 8z'); seekAll(); draw(); }
  function seek(x) { t = Math.max(0, Math.min(total(), x)); if (playing) clock = { t0: t, at: performance.now() }; seekAll(); draw(); }
  function autoScroll() { const x = t * pps; if (x < lanes.scrollLeft || x > lanes.scrollLeft + lanes.clientWidth - 30) lanes.scrollLeft = Math.max(0, x - 60); }
  $('vePlay').onclick = () => (playing ? pause() : play());
  const msg = (s) => { const m = $('veMsg'); m.textContent = s; m.hidden = !s; };

  // ---------- línea de tiempo ----------
  const ICO = {
    eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
    eyeOff: 'M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6 0 10 7 10 7a17 17 0 0 1-3.2 3.9M6.6 6.6A17 17 0 0 0 2 12s4 7 10 7a9.6 9.6 0 0 0 4.3-1',
    vol: 'M11 5 6 9H3v6h3l5 4zM15.5 8.5a5 5 0 0 1 0 7',
    volOff: 'M11 5 6 9H3v6h3l5 4zM22 9l-6 6M16 9l6 6',
    x: 'M6 6l12 12M18 6 6 18',
  };
  const svg = (d, s = 14) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${d}"/></svg>`;
  function render() {
    const T = total();
    const width = Math.max(lanes.clientWidth, (T + 20) * pps);
    // regla
    let r = '';
    const step = [1, 2, 5, 10, 15, 30, 60, 120, 300].find((s) => s * pps >= 56) || 600;
    for (let s = 0; s * pps < width; s += step) r += `<span style="left:${s * pps}px">${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}</span>`;
    ruler.innerHTML = r; ruler.style.width = `${width}px`;
    // cabeceras y carriles
    const R = rows();
    heads.innerHTML = R.map((tr) => {
      const code = (tr.kind === 'v' ? 'V' : 'A') + (tr.kind === 'v' ? vTracks().indexOf(tr) + 1 : aTracks().indexOf(tr) + 1);
      const off = tr.kind === 'v' ? tr.hidden : tr.muted;
      const ico = tr.kind === 'v' ? (off ? ICO.eyeOff : ICO.eye) : (off ? ICO.volOff : ICO.vol);
      const canDel = !P.clips.some((c) => c.track === tr.id) && (tr.kind === 'v' ? vTracks().length > 1 : aTracks().length > 1);
      return `<div class="ve-th ${tr.kind}${off ? ' off' : ''}" data-tr="${tr.id}"><b>${code}</b><span>${tr.name}</span>`
        + `<button class="ve-ib" data-tog="${tr.id}" title="${tr.kind === 'v' ? (off ? 'Mostrar pista' : 'Ocultar pista') : (off ? 'Activar sonido' : 'Silenciar pista')}" aria-label="${tr.kind === 'v' ? 'Ver u ocultar' : 'Sonido'} ${code}">${svg(ico)}</button>`
        + (canDel ? `<button class="ve-ib" data-deltr="${tr.id}" title="Sacar pista vacía" aria-label="Sacar pista ${code}">${svg(ICO.x, 12)}</button>` : '') + '</div>';
    }).join('');
    $('veContent').style.width = `${width}px`;
    $('veRows').innerHTML = R.map((tr) => `<div class="ve-lane ${tr.kind}${(tr.kind === 'v' ? tr.hidden : tr.muted) ? ' off' : ''}" data-tr="${tr.id}">${P.clips.filter((c) => c.track === tr.id).map(clipHtml).join('')}</div>`).join('');
    for (const c of P.clips) drawWave(c);
    head.style.left = `${t * pps}px`;
    $('veInfo').textContent = P.clips.length ? `${P.clips.length} ${P.clips.length === 1 ? 'clip' : 'clips'} · queda de ${fmtT(T, false)}` : 'Agregá videos, fotos o música';
    $('fileName').textContent = $('veInfo').textContent;
    $('veEnd').textContent = fmtT(T);
    $('ok').disabled = !P.clips.length;
    renderSide();
  }
  function clipHtml(c) {
    const m = media.get(c.file);
    const w = Math.max(4, len(c) * pps);
    const isSel = c.id === sel;
    let inner = '';
    if (c.kind !== 'audio') {
      const th = (m.thumbs || []).filter(Boolean);
      if (c.kind === 'image') inner = `<div class="ve-img" style="background-image:url('${m.url}')"></div>`;
      else if (th.length) {
        const fw = (m.dur * pps) / th.length;
        inner = `<div class="ve-strip" style="left:${-c.in * pps}px;width:${m.dur * pps}px">${th.map((u) => `<img src="${u}" style="width:${fw}px" alt="">`).join('')}</div>`;
      }
      if (m.hasAudio) inner += `<canvas class="ve-wv small${c.mute ? ' muted' : ''}" data-wv="${c.id}"></canvas>`;
    } else inner = `<canvas class="ve-wv${c.mute ? ' muted' : ''}" data-wv="${c.id}"></canvas>`;
    const tags = [c.box && c.box !== 'full' ? 'Recuadro' : '', c.mute ? 'Sin sonido' : ''].filter(Boolean).map((x) => `<i>${x}</i>`).join('');
    const fades = (c.fadeIn ? '<span class="ve-fi"></span>' : '') + (c.fadeOut ? '<span class="ve-fo"></span>' : '');
    return `<div class="ve-clip ${c.kind}${isSel ? ' sel' : ''}" data-id="${c.id}" style="left:${c.start * pps}px;width:${w}px" title="${nameOf(c.file)}">${inner}${fades}`
      + `<span class="ve-nm">${nameOf(c.file)}</span><span class="ve-dur">${len(c).toFixed(1)} s</span>${tags ? `<span class="ve-tags">${tags}</span>` : ''}`
      + `<span class="ve-h l" data-edge="l"></span><span class="ve-h r" data-edge="r"></span></div>`;
  }
  function drawWave(c) {
    const can = $('veRows').querySelector(`canvas[data-wv="${c.id}"]`);
    const m = media.get(c.file);
    if (!can || !m.peaks || !m.peaks.length) return;
    const w = can.clientWidth, h = can.clientHeight;
    if (!w || !h) return;
    can.width = w * devicePixelRatio; can.height = h * devicePixelRatio;
    const g = can.getContext('2d'); g.scale(devicePixelRatio, devicePixelRatio);
    g.fillStyle = 'rgba(255,255,255,0.85)';
    const pk = m.peaks, n = pk.length, d = m.dur || 1;
    for (let x = 0; x < w; x += 2) {
      const tt = c.in + (x / w) * len(c);
      const v = pk[Math.min(n - 1, Math.floor((tt / d) * n))] || 0;
      const bh = Math.max(1, v * (h - 2) * (c.volume ?? 1));
      g.fillRect(x, (h - bh) / 2, 1.4, bh);
    }
  }

  // ---------- panel de la derecha ----------
  function renderSide() {
    const c = P.clips.find((x) => x.id === sel);
    const fmt = `<div class="ve-sec">VIDEO FINAL</div><div class="chips small" id="veFmt">${[['first', 'Como el 1.º'], ['16:9', '16:9'], ['9:16', '9:16'], ['1:1', '1:1']].map(([k, l]) => `<button data-fmt="${k}" class="${P.format === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    if (!c) {
      side.innerHTML = `<div class="ve-sec">CÓMO SE USA</div><ul class="ve-help"><li>Tocá un clip para elegirlo; arrastralo para moverlo de lugar o de pista.</li><li>Los bordes de cada clip lo acortan.</li><li>Lo de las pistas de arriba tapa a lo de abajo; los sonidos se mezclan.</li><li>Tocá la regla o la línea para moverte por el video.</li><li>Al exportar sale un MP4 al lado del primer video. Los originales no se tocan.</li></ul><div class="ve-keys">Espacio: play · S: cortar · Supr: sacar · Ctrl+Z: deshacer</div><div class="ve-sp"></div>${fmt}`;
      return;
    }
    const m = media.get(c.file), tr = trackOf(c.track);
    const code = (tr.kind === 'v' ? 'V' : 'A') + (tr.kind === 'v' ? vTracks().indexOf(tr) + 1 : aTracks().indexOf(tr) + 1);
    const hasSound = c.kind === 'audio' || m.hasAudio;
    const upper = c.kind !== 'audio' && vTracks().indexOf(tr) > 0;
    side.innerHTML = `<div class="ve-sec">PISTA ${code} · ${tr.name.toUpperCase()}</div><div class="ve-name" title="${nameOf(c.file)}">${nameOf(c.file)}</div>`
      + `<div class="ve-grid"><span class="muted">${c.kind === 'image' ? 'Dura' : 'Desde'}</span><b>${c.kind === 'image' ? `${len(c).toFixed(1)} s` : `${fmtT(c.in)} <span class="muted">del original</span>`}</b>`
      + (c.kind === 'image' ? '' : `<span class="muted">Hasta</span><b>${fmtT(c.out)}</b><span class="muted">Queda</span><b>${len(c).toFixed(1)} s <span class="muted">de ${Math.round(m.dur)} s</span></b>`)
      + `<span class="muted">En el video</span><b>${fmtT(c.start)} → ${fmtT(end(c))}</b></div>`
      + (hasSound ? `<label class="ve-vol"><span class="muted">Volumen</span><input type="range" id="veVol" min="0" max="1" step="0.05" value="${c.volume ?? 1}"><b id="veVolT">${Math.round((c.volume ?? 1) * 100)} %</b></label>` : '')
      + `<div class="ve-row"><span class="muted">Fundido</span><div class="chips small"><button data-fade="fadeIn" class="${c.fadeIn ? 'on' : ''}">Al entrar</button><button data-fade="fadeOut" class="${c.fadeOut ? 'on' : ''}">Al salir</button></div></div>`
      + (upper ? `<div class="ve-row"><span class="muted">Tamaño</span><div class="chips small" id="veBox">${[['full', 'Completo'], ['tl', '↖'], ['tr', '↗'], ['bl', '↙'], ['br', '↘']].map(([k, l]) => `<button data-box="${k}" class="${(c.box || 'full') === k ? 'on' : ''}" title="${k === 'full' ? 'Pantalla completa' : 'Recuadro en esa esquina'}">${l}</button>`).join('')}</div></div>` : '')
      + `<div class="ve-tools"><button data-act="split" title="S">Cortar acá</button>${hasSound ? `<button data-act="mute">${c.mute ? 'Con sonido' : 'Silenciar'}</button>` : ''}<button data-act="dup">Duplicar</button><button data-act="del" class="danger" title="Supr">Sacar</button></div>`
      + `<div class="ve-sp"></div>${fmt}`;
    const vol = $('veVol');
    if (vol) {
      vol.onpointerdown = () => commit();
      vol.oninput = () => { c.volume = +vol.value; $('veVolT').textContent = `${Math.round(c.volume * 100)} %`; drawWave(c); seekAll(); };
    }
  }
  side.addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    const c = P.clips.find((x) => x.id === sel);
    if (b.dataset.fmt) { commit(); P.format = b.dataset.fmt; fitCanvas(); render(); return; }
    if (!c) return;
    if (b.dataset.fade) { commit(); c[b.dataset.fade] = !c[b.dataset.fade]; render(); draw(); }
    if (b.dataset.box) { commit(); c.box = b.dataset.box; render(); draw(); }
    if (b.dataset.act === 'split') split();
    if (b.dataset.act === 'mute') { commit(); c.mute = !c.mute; render(); seekAll(); }
    if (b.dataset.act === 'dup') dup();
    if (b.dataset.act === 'del') del();
  });

  function split() {
    const c = P.clips.find((x) => x.id === sel && active(x, t)) || P.clips.find((x) => active(x, t) && x.track === (P.clips.find((y) => y.id === sel) || {}).track);
    if (!c || t - c.start < MIN_LEN || end(c) - t < MIN_LEN) return;
    commit();
    const cut = c.in + (t - c.start);
    const b = { ...c, id: uid++, start: t, in: cut, fadeIn: false };
    c.out = cut; c.fadeOut = false;
    P.clips.push(b); sel = b.id; syncEls(); render(); seekAll(); draw();
  }
  function dup() {
    const c = P.clips.find((x) => x.id === sel); if (!c) return;
    commit();
    const b = { ...c, id: uid++ };
    b.start = freeStart(b, c.track, end(c));
    P.clips.push(b); sel = b.id; syncEls(); render();
  }
  function del() {
    const c = P.clips.find((x) => x.id === sel); if (!c) return;
    commit();
    P.clips = P.clips.filter((x) => x.id !== sel); sel = null;
    syncEls(); if (t > total()) t = total(); render(); seekAll(); draw();
  }

  // ---------- arrastrar ----------
  let drag = null;
  const tAt = (e) => (e.clientX - lanes.getBoundingClientRect().left + lanes.scrollLeft) / pps;
  const laneAt = (e) => { const el = document.elementFromPoint(e.clientX, e.clientY); const l = el && el.closest('.ve-lane'); return l ? l.dataset.tr : null; };
  function snapT(x, c, edges) {
    const pts = [0, t, ...P.clips.filter((o) => o.id !== c.id).flatMap((o) => [o.start, end(o)])];
    let best = x, bd = SNAP_PX / pps;
    for (const e of edges) for (const p of pts) { const d = Math.abs(x + e - p); if (d < bd) { bd = d; best = p - e; } }
    return best;
  }
  $('veTimeline').addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || e.target.closest('.ve-th') || e.target.closest('.ve-bar')) return;
    const clipEl = e.target.closest('.ve-clip');
    $('veTimeline').setPointerCapture(e.pointerId);
    if (clipEl) {
      const c = P.clips.find((x) => x.id === +clipEl.dataset.id);
      sel = c.id;
      const edge = e.target.dataset.edge;
      drag = { c, edge, x0: e.clientX, start: c.start, in: c.in, out: c.out, track: c.track, moved: false, snap: snap() };
      if (playing) pause();
      render();
    } else {
      sel = null; render();
      drag = { seek: true }; seek(tAt(e));
    }
    e.preventDefault();
  });
  window.addEventListener('pointermove', (e) => {
    if (!drag) return;
    if (drag.seek) { seek(tAt(e)); return; }
    const c = drag.c, dt = (e.clientX - drag.x0) / pps;
    if (!drag.moved && Math.abs(e.clientX - drag.x0) < 4 && !drag.edge) return;
    drag.moved = true;
    const m = media.get(c.file);
    const maxOut = c.kind === 'image' ? Infinity : m.dur;
    const sameTrack = P.clips.filter((o) => o.track === c.track && o.id !== c.id);
    if (drag.edge === 'l') {
      const prevEnd = Math.max(0, ...sameTrack.filter((o) => end(o) <= drag.start + 1e-6).map(end));
      let ns = snapT(drag.start + dt, c, [0]);
      ns = Math.max(ns, prevEnd, drag.start - (c.kind === 'image' ? Infinity : drag.in));
      ns = Math.min(ns, drag.start + (drag.out - drag.in) - MIN_LEN);
      c.start = ns; c.in = c.kind === 'image' ? 0 : drag.in + (ns - drag.start);
      if (c.kind === 'image') c.out = drag.out - (ns - drag.start);
    } else if (drag.edge === 'r') {
      const nextStart = Math.min(Infinity, ...sameTrack.filter((o) => o.start >= drag.start + (drag.out - drag.in) - 1e-6).map((o) => o.start));
      let ne = snapT(drag.start + (drag.out - drag.in) + dt, c, [0]);
      ne = Math.min(ne, nextStart, drag.start + (maxOut - drag.in));
      ne = Math.max(ne, drag.start + MIN_LEN);
      c.out = drag.in + (ne - drag.start);
    } else {
      const tr = laneAt(e);
      if (tr && kindOk(c, trackOf(tr))) c.track = tr;
      c.start = Math.max(0, snapT(drag.start + dt, c, [0, len(c)]));
    }
    render();
  });
  const endDrag = () => {
    if (drag && drag.c && drag.moved) {
      const c = drag.c;
      if (!drag.edge) c.start = freeStart(c, c.track, c.start);
      undo.push(drag.snap); redo.length = 0;
      render(); seekAll(); draw();
    }
    drag = null;
  };
  // el arrastre sigue aunque el mouse salga de la línea de tiempo (mientras esté en la ventana)
  window.addEventListener('pointerup', endDrag);
  window.addEventListener('pointercancel', endDrag);
  window.addEventListener('blur', endDrag);
  heads.addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.tog) { const tr = trackOf(b.dataset.tog); commit(); if (tr.kind === 'v') tr.hidden = !tr.hidden; else tr.muted = !tr.muted; render(); seekAll(); draw(); }
    if (b.dataset.deltr) { commit(); P.tracks = P.tracks.filter((x) => x.id !== b.dataset.deltr); render(); }
  });
  $('veAddV').onclick = () => { commit(); const n = vTracks().length + 1; P.tracks.splice(P.tracks.indexOf(vTracks().slice(-1)[0]) + 1, 0, { id: `v${Date.now()}`, kind: 'v', name: n === 2 ? 'Encima' : `Encima ${n - 1}` }); render(); };
  $('veAddA').onclick = () => { commit(); const n = aTracks().length + 1; P.tracks.push({ id: `a${Date.now()}`, kind: 'a', name: n === 1 ? 'Música' : `Audio ${n}` }); render(); };
  $('veAddF').onclick = async () => {
    const items = await ruedita.invoke('vedit-pick');
    if (!items || !items.length) return;
    commit(); addFiles(items); syncEls(); render(); seekAll(); draw();
  };
  $('veZoom').oninput = () => { const mid = (lanes.scrollLeft + lanes.clientWidth / 2) / pps; pps = +$('veZoom').value; render(); lanes.scrollLeft = mid * pps - lanes.clientWidth / 2; draw(); };
  // Ctrl + rueda (o pellizcar el trackpad) = zoom, centrado donde está el mouse
  $('veTimeline').addEventListener('wheel', (e) => {
    if (!e.ctrlKey && !e.metaKey) return;
    e.preventDefault();
    const at = tAt(e), x = e.clientX - lanes.getBoundingClientRect().left;
    pps = Math.max(3, Math.min(160, pps * Math.exp(-e.deltaY * 0.0025)));
    $('veZoom').value = pps;
    render();
    lanes.scrollLeft = Math.max(0, at * pps - x);
    draw();
  }, { passive: false });
  lanes.addEventListener('scroll', () => { $('veRulerWrap').scrollLeft = lanes.scrollLeft; heads.style.transform = `translateY(${-lanes.scrollTop}px)`; });
  heads.parentElement.addEventListener('wheel', (e) => { lanes.scrollTop += e.deltaY; }, { passive: true });

  // ---------- teclado ----------
  window.addEventListener('keydown', (e) => {
    if (MODE !== 'vedit' || e.target.tagName === 'INPUT' && e.target.type !== 'range') return;
    const k = e.key;
    if (k === 'Enter') { e.preventDefault(); return; } // Enter no exporta sin querer
    if (k === ' ') { e.preventDefault(); playing ? pause() : play(); }
    else if (k === 's' || k === 'S') { e.preventDefault(); split(); }
    else if (k === 'Delete' || k === 'Backspace') { e.preventDefault(); del(); }
    else if (k === 'ArrowLeft' || k === 'ArrowRight') { e.preventDefault(); seek(t + (k === 'ArrowLeft' ? -1 : 1) * (e.shiftKey ? 1 : 1 / 30)); }
    else if (k === 'Home') { e.preventDefault(); seek(0); }
    else if (k === 'End') { e.preventDefault(); seek(total()); }
    else if ((e.ctrlKey || e.metaKey) && (k === 'z' || k === 'Z')) {
      e.preventDefault();
      if (e.shiftKey) { if (redo.length) { undo.push(snap()); restore(redo.pop()); } }
      else if (undo.length) { redo.push(snap()); restore(undo.pop()); }
    } else if ((e.ctrlKey || e.metaKey) && (k === 'y' || k === 'Y')) { e.preventDefault(); if (redo.length) { undo.push(snap()); restore(redo.pop()); } }
  }, true);

  // ---------- arranque ----------
  addFiles(data.items || [], 0);
  syncEls();
  const T0 = total();
  requestAnimationFrame(() => {
    pps = Math.max(4, Math.min(120, (lanes.clientWidth - 120) / Math.max(10, T0)));
    $('veZoom').value = pps;
    render(); fitCanvas(); seekAll();
  });
  window.addEventListener('resize', () => { fitCanvas(); render(); });
  $('ok').textContent = 'Exportar video';
  getResult = () => {
    if (!P.clips.length) return null;
    pause();
    return {
      project: {
        format: P.format,
        tracks: P.tracks.map((x) => ({ id: x.id, kind: x.kind, hidden: !!x.hidden, muted: !!x.muted })),
        clips: P.clips.map((c) => {
          const m = media.get(c.file);
          return { file: c.file, kind: c.kind, track: c.track, start: c.start, in: c.in, out: c.out, volume: c.volume ?? 1, mute: !!c.mute, fadeIn: !!c.fadeIn, fadeOut: !!c.fadeOut, box: c.box || 'full', w: m.w, h: m.h, hasAudio: c.kind === 'audio' || !!m.hasAudio };
        }),
      },
    };
  };
  // para las pruebas
  window.__ve = { P, els, get t() { return t; }, seek, split, del, dup, render, select: (id) => { sel = id; render(); }, get pps() { return pps; }, total };
}
